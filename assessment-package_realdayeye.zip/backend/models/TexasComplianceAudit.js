const mongoose = require('mongoose');

/**
 * Texas Compliance Audit schema
 *
 * This schema is designed to track Texas Affordable Housing Compliance Audits
 * with a focus on:
 * - Texas program types (LIHTC, Section 8, state programs)
 * - Findings & violations (income, rent, set-asides, utility allowances, etc.)
 * - Compliance status over time (historical audit trail)
 * - References to regulatory documents and buildings/units/tenants
 *
 * How this supports Texas compliance requirements:
 * - `texasPrograms`, `primaryProgram` and `programConfig.setAsideRequirements` model
 *   Texas-specific set-aside configurations at the time of the audit.
 * - `findings` and `correctiveActions` capture detailed violations (e.g. over-income,
 *   rent above limit, set-aside shortfalls) and the remediation steps taken.
 * - `regulatoryReferences` allows each audit/finding to be tied back to TDHCA/HUD/IRS
 *   guidance used during the review.
 * - `history`, `periodStart`, and `periodEnd` allow downstream services to answer
 *   questions like "was this building compliant for LIHTC requirements on a given date?"
 *
 * Design notes (embedded vs referenced):
 * - We reference `Building` / `Unit` / `Tenant` / `User` to avoid duplicating large
 *   documents and to support efficient querying by those entities.
 * - We embed small subdocuments (`findings`, `correctiveActions`, `regulatoryReferences`,
 *   `history`) because they are tightly coupled to a single audit and typically loaded
 *   together in one query.
 *
 * Indexing strategy (see indexes below):
 * - (building, auditDate) for "all audits for a building in 2024".
 * - primaryProgram / overallStatus for dashboard-style filters.
 * - hasCriticalFindings and findings.severity for quickly locating high-risk audits
 *   and critical violations.
 */

// Embedded subdocument for regulatory references (Texas-specific guidance, TDHCA docs, etc.)
const regulatoryReferenceSchema = new mongoose.Schema({
  source: {
    type: String,
    enum: ['TDHCA', 'HUD', 'IRS', 'StateProgram', 'Other'],
    default: 'Other',
  },
  citation: {
    type: String,
    required: true,
    trim: true,
  }, // e.g. "TDHCA LIHTC Compliance Manual §10.612"
  description: {
    type: String,
    trim: true,
  },
  document: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Document',
  }, // Link to uploaded regulatory agreement / guide
});

// Embedded subdocument for individual findings within an audit
const auditFindingSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      trim: true,
    }, // Internal finding code, e.g. "LIHTC-OVER-INCOME"
    title: {
      type: String,
      required: true,
      trim: true,
    },
    severity: {
      type: String,
      enum: ['low', 'moderate', 'high', 'critical'],
      required: true,
      default: 'low',
      index: true,
    },
    category: {
      type: String,
      enum: [
        'income',
        'rent',
        'set_aside',
        'utility_allowance',
        'tenant_file',
        'physical',
        'other',
      ],
      default: 'other',
    },
    description: {
      type: String,
      required: true,
      trim: true,
    },
    texasProgram: {
      type: String,
      enum: ['LIHTC', 'SECTION_8', 'STATE_PROGRAM', 'OTHER'],
      default: 'LIHTC',
    },
    // Optional linkage to specific property context
    building: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Building',
    },
    unit: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Unit',
    },
    tenant: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Tenant',
    },
    // Dates & status
    identifiedAt: {
      type: Date,
      required: true,
      default: Date.now,
    },
    correctedAt: {
      type: Date,
    },
    status: {
      type: String,
      enum: ['open', 'in_progress', 'resolved', 'waived'],
      default: 'open',
    },
    notes: {
      type: String,
      trim: true,
    },
    regulatoryReferences: [regulatoryReferenceSchema],
  },
  { _id: true }
);

// Embedded subdocument for corrective actions tied to the audit
const correctiveActionSchema = new mongoose.Schema(
  {
    findingId: {
      type: mongoose.Schema.Types.ObjectId,
    }, // Reference to a finding within this audit.findings array
    actionDescription: {
      type: String,
      required: true,
      trim: true,
    },
    responsibleParty: {
      type: String,
      trim: true,
    }, // e.g. "Property Manager", "Compliance Officer"
    dueDate: {
      type: Date,
    },
    completedAt: {
      type: Date,
    },
    status: {
      type: String,
      enum: ['pending', 'in_progress', 'completed', 'not_applicable'],
      default: 'pending',
    },
    notes: {
      type: String,
      trim: true,
    },
  },
  { _id: true }
);

// Embedded subdocument for historical status tracking of the audit
const auditHistorySchema = new mongoose.Schema(
  {
    status: {
      type: String,
      enum: ['draft', 'in_review', 'non_compliant', 'compliant', 'closed'],
      required: true,
    },
    effectiveDate: {
      type: Date,
      required: true,
      default: Date.now,
    },
    changedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    notes: {
      type: String,
      trim: true,
    },
  },
  { _id: false }
);

const texasComplianceAuditSchema = new mongoose.Schema(
  {
    // Core audit metadata
    auditDate: {
      type: Date,
      required: true,
      index: true, // Common filter: audits in a given time range
    },
    auditType: {
      type: String,
      enum: ['desk_review', 'on_site', 'file_audit', 'follow_up', 'other'],
      default: 'on_site',
    },
    auditorName: {
      type: String,
      required: true,
      trim: true,
    },
    auditorOrganization: {
      type: String,
      trim: true,
    },

    // Property context
    building: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Building',
      required: true,
      index: true,
    },
    unitsAudited: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Unit',
      },
    ],
    tenantsAudited: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Tenant',
      },
    ],

    // Texas-specific program information
    texasPrograms: [
      {
        type: String,
        enum: ['LIHTC', 'SECTION_8', 'STATE_PROGRAM', 'HOME', 'OTHER'],
        required: true,
      },
    ],
    primaryProgram: {
      type: String,
      enum: ['LIHTC', 'SECTION_8', 'STATE_PROGRAM', 'HOME', 'OTHER'],
      required: true,
      index: true,
    },
    // Program configuration snapshot (at time of audit)
    programConfig: {
      // Snapshot of key Texas compliance parameters as of audit date
      setAsideRequirements: {
        // e.g. { "30": 5, "60": 40 } meaning 5 units at 30% AMI, 40 units at 60% AMI
        // Note: Each AMI level has independent requirements that must be met separately
        type: mongoose.Schema.Types.Mixed,
        // No validation - flexible structure allows different program requirements
      },
      // Store total units separately for set-aside calculations
      totalUnitsAtAudit: {
        type: Number,
        // This is redundant since we can get it from Building, but stored for performance
      },
      incomeLimitSource: {
        type: String,
        trim: true,
      }, // e.g. "TDHCA 2024 LIHTC limits"
      rentLimitSource: {
        type: String,
        trim: true,
      }, // e.g. "HUD MTSP 2024"
      // AMI geographic area - stored at audit level since buildings have fixed locations
      // Note: This is the building's permanent AMI area. Buildings don't change geographic areas.
      amiGeographicArea: {
        type: String,
        trim: true,
        // e.g. "Travis County", "Austin-Round Rock MSA"
      },
      // Also store at top level for easier querying (denormalization for performance)
      buildingAmiArea: {
        type: String,
        trim: true,
        index: true,
      }, // Duplicate of amiGeographicArea but at root level for queries
    },

    // Findings & violations
    findings: [auditFindingSchema],

    // Corrective actions
    correctiveActions: [correctiveActionSchema],

    // Overall compliance status
    overallStatus: {
      type: String,
      enum: ['compliant', 'non_compliant', 'pending_correction', 'under_review'],
      required: true,
      default: 'under_review',
      index: true,
    },
    // Summary flags to support quick queries like "find all critical violations"
    hasCriticalFindings: {
      type: Boolean,
      default: false,
      index: true,
    },
    totalFindingsCount: {
      type: Number,
      default: 0,
    },
    openFindingsCount: {
      type: Number,
      default: 0,
    },

    // References to regulatory documents used in this audit
    regulatoryReferences: [regulatoryReferenceSchema],

    // Historical tracking of compliance status over time
    history: [auditHistorySchema],

    // Audit window for historical compliance checks
    periodStart: {
      type: Date,
    },
    periodEnd: {
      type: Date,
    },
    // Compliance period duration in years (for LIHTC typically 15 years)
    compliancePeriodYears: {
      type: Number,
      default: 15,
      // Hard-coded default assumes all programs use 15-year periods
    },

    // Metadata
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
  },
  {
    timestamps: true,
  }
);

/**
 * Indexing strategy:
 * - (building, auditDate) supports "find all audits for a building in 2024"
 * - primaryProgram and overallStatus for dashboard-style filters
 * - hasCriticalFindings for quickly finding high-risk audits
 * - findings.severity for queries of critical violations within a building
 */
texasComplianceAuditSchema.index({ building: 1, auditDate: -1 });
texasComplianceAuditSchema.index({ primaryProgram: 1, auditDate: -1 });
texasComplianceAuditSchema.index({ overallStatus: 1, auditDate: -1 });
texasComplianceAuditSchema.index({ hasCriticalFindings: 1 });
texasComplianceAuditSchema.index({ 'findings.severity': 1 });

/**
 * Pre-save hook to maintain derived summary fields:
 * - hasCriticalFindings
 * - totalFindingsCount
 * - openFindingsCount
 */
texasComplianceAuditSchema.pre('save', function preSave(next) {
  if (Array.isArray(this.findings)) {
    this.totalFindingsCount = this.findings.length;
    this.hasCriticalFindings = this.findings.some(
      (f) => f.severity === 'critical'
    );
    this.openFindingsCount = this.findings.filter(
      (f) => f.status === 'open' || f.status === 'in_progress'
    ).length;
  }
  next();
});

module.exports = mongoose.model(
  'TexasComplianceAudit',
  texasComplianceAuditSchema
);


