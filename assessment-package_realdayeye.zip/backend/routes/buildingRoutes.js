const express = require('express');
const router = express.Router();

const buildingController = require('../controllers/buildingController');

/**
 * Texas-specific compliance validation endpoint.
 *
 * POST /api/buildings/:buildingId/validate-texas-compliance
 *
 * Body:
 *   {
 *     "checkDate": "2024-01-31", // optional
 *     "programType": "LIHTC" | "SECTION_8" | "STATE_PROGRAM"
 *   }
 *
 * For the purposes of this assessment, only LIHTC is implemented in the
 * underlying texasComplianceService.
 */
router.post(
  '/:buildingId/validate-texas-compliance',
  buildingController.validateTexasCompliance
);

module.exports = router;


