/**
 * Compliance Routes
 * 
 * API routes for compliance-related operations,
 * specifically Texas compliance document extraction.
 */

const express = require('express');
const router = express.Router();
const multer = require('multer');
const complianceController = require('../controllers/complianceController');

// Configure multer for file uploads - use memory storage
const upload = multer({
    storage: multer.memoryStorage(),
    limits: {
        fileSize: 50 * 1024 * 1024 // 50MB limit per file
    },
    fileFilter: (req, file, cb) => {
        // Only accept PDF files
        if (file.mimetype === 'application/pdf') {
            cb(null, true);
        } else {
            cb(new Error('Only PDF files are allowed'), false);
        }
    }
});

/**
 * Extract Texas compliance requirements from uploaded PDF document
 * 
 * POST /api/compliance/extract-texas-requirements
 * 
 * Request:
 * - Content-Type: multipart/form-data
 * - Field name: 'file'
 * - File type: PDF only
 * 
 * Response:
 * {
 *   "success": true,
 *   "message": "Texas compliance requirements extracted successfully",
 *   "fileName": "document.pdf",
 *   "extractedAt": "2024-01-15T10:30:00.000Z",
 *   "data": {
 *     "programType": { "value": "LIHTC", "confidence": 0.95, "notes": "..." },
 *     "setAsideRequirements": { "value": {...}, "confidence": 0.85, "notes": "..." },
 *     "incomeLimits": { "value": {...}, "confidence": 0.90, "notes": "..." },
 *     "rentLimits": { "value": {...}, "confidence": 0.80, "notes": "..." },
 *     "effectiveDates": { "value": {...}, "confidence": 0.75, "notes": "..." },
 *     "geographicArea": { "value": {...}, "confidence": 0.90, "notes": "..." },
 *     "utilityAllowances": { "value": {...}, "confidence": 0.70, "notes": "..." },
 *     "requiresManualReview": [...]
 *   },
 *   "metadata": {
 *     "textLength": 12345,
 *     "extractionMethod": "azure_openai",
 *     "documentType": "LIHTC"
 *   }
 * }
 * 
 * Error Response:
 * {
 *   "success": false,
 *   "error": "Error message",
 *   "details": "..." // Only in development mode
 * }
 */
router.post('/extract-texas-requirements',
    upload.single('file'),
    (req, res, next) => {
        // Handle multer errors
        if (req.fileValidationError) {
            return res.status(400).json({
                success: false,
                error: req.fileValidationError
            });
        }
        next();
    },
    complianceController.extractTexasRequirements
);

module.exports = router;

