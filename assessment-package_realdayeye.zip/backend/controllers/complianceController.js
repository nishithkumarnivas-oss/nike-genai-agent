/**
 * Compliance Controller
 * 
 * Handles HTTP requests for compliance-related operations,
 * specifically Texas compliance document extraction.
 */

const texasComplianceDocumentExtractionService = require('../services/texasComplianceDocumentExtractionService');

/**
 * Extracts Texas compliance requirements from uploaded PDF document
 * 
 * POST /api/compliance/extract-texas-requirements
 * 
 * Request:
 * - multipart/form-data with 'file' field containing PDF
 * 
 * Response:
 * {
 *   "success": true,
 *   "data": { ... extracted compliance requirements ... },
 *   "metadata": { ... }
 * }
 */
async function extractTexasRequirements(req, res) {
    try {
        // Validate file upload
        if (!req.file) {
            return res.status(400).json({
                success: false,
                error: 'No file uploaded. Please provide a PDF file in the "file" field.'
            });
        }

        const fileBuffer = req.file.buffer;
        const fileName = req.file.originalname || 'document.pdf';
        const mimeType = req.file.mimetype || 'application/pdf';

        // Validate file type
        if (mimeType !== 'application/pdf') {
            return res.status(400).json({
                success: false,
                error: `Unsupported file type: ${mimeType}. Only PDF files are supported.`
            });
        }

        // Validate file size (optional - 50MB limit)
        const maxFileSize = 50 * 1024 * 1024; // 50MB
        if (fileBuffer.length > maxFileSize) {
            return res.status(400).json({
                success: false,
                error: `File too large: ${(fileBuffer.length / 1024 / 1024).toFixed(2)}MB. Maximum size is 50MB.`
            });
        }

        console.log(`[Compliance Controller] Extracting Texas requirements from: ${fileName} (${(fileBuffer.length / 1024).toFixed(2)}KB)`);

        // Extract Texas compliance requirements
        const result = await texasComplianceDocumentExtractionService.extractTexasComplianceRequirements(
            fileBuffer,
            fileName,
            mimeType
        );

        // Return success response
        return res.status(200).json({
            success: true,
            message: 'Texas compliance requirements extracted successfully',
            ...result
        });
    } catch (error) {
        console.error('[Compliance Controller] Error extracting Texas requirements:', error);

        // Provide meaningful error messages
        let statusCode = 500;
        let errorMessage = 'An error occurred while extracting Texas compliance requirements.';

        if (error.message.includes('Unsupported file type')) {
            statusCode = 400;
            errorMessage = error.message;
        } else if (error.message.includes('No text could be extracted')) {
            statusCode = 400;
            errorMessage = error.message;
        } else if (error.message.includes('Failed to analyze document')) {
            statusCode = 503;
            errorMessage = 'Azure Document Intelligence service is temporarily unavailable. Please try again later.';
        } else if (error.message.includes('Failed to extract compliance data')) {
            statusCode = 503;
            errorMessage = 'AI extraction service is temporarily unavailable. Please try again later.';
        } else if (error.message.includes('must be implemented')) {
            statusCode = 501;
            errorMessage = 'AI extraction services are not yet configured. Please contact system administrator.';
        }

        return res.status(statusCode).json({
            success: false,
            error: errorMessage,
            details: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
}

module.exports = {
    extractTexasRequirements
};

