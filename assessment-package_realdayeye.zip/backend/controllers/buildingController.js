const texasComplianceService = require('../services/texasComplianceService');

/**
 * Controller for Texas-specific compliance validation.
 *
 * Route:
 *   POST /api/buildings/:buildingId/validate-texas-compliance
 *
 * Request body:
 *   {
 *     "checkDate": "2024-01-31", // optional ISO date string
 *     "programType": "LIHTC" | "SECTION_8" | "STATE_PROGRAM"
 *   }
 *
 * For this assessment we focus on LIHTC; other program types can be
 * extended later as needed.
 */
async function validateTexasCompliance(req, res) {
  try {
    const { buildingId } = req.params;
    const { checkDate = null, programType = 'LIHTC' } = req.body || {};

    if (!buildingId) {
      return res.status(400).json({
        success: false,
        message: 'buildingId is required in route parameters',
      });
    }

    if (programType !== 'LIHTC') {
      return res.status(400).json({
        success: false,
        message:
          'Only LIHTC programType is supported in this assessment implementation.',
      });
    }

    const report =
      await texasComplianceService.validateTexasLIHTCCompliance(
        buildingId,
        checkDate
      );

    return res.status(200).json({
      success: true,
      programType,
      report,
    });
  } catch (error) {
    console.error('Error validating Texas compliance:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to validate Texas compliance',
      error: error.message,
    });
  }
}

module.exports = {
  validateTexasCompliance,
};


