/**
 * Texas Compliance Service
 *
 * This service implements Texas-specific LIHTC compliance checks using the
 * formulas and thresholds defined in TEXAS_COMPLIANCE_QUICK_REFERENCE.md.
 *
 * Design notes:
 * - We reuse the building-level compliance machinery (executeBuildingLevelFormula)
 *   from the Building model to avoid duplicating AMI lookups and bucket logic.
 * - We interpret the hierarchical AMI buckets (≤80%, ≤60%, ≤30%) returned from
 *   the building formula to calculate Texas LIHTC set-aside thresholds.
 * - Unit-level income and rent violations are derived from the detailed
 *   unitResults produced by executeBuildingLevelFormula.
 */

const Building = require('../models/Building'); // In the full app, this would be the real Building model

/**
 * Normalizes an optional checkDate value into a valid Date instance.
 *
 * @param {string|Date|null|undefined} checkDate
 * @returns {Date} normalized date (defaults to current date if not provided)
 */
function normalizeCheckDate(checkDate) {
  if (!checkDate) {
    return new Date();
  }
  if (checkDate instanceof Date) {
    return isNaN(checkDate.getTime()) ? new Date() : checkDate;
  }
  const parsed = new Date(checkDate);
  return isNaN(parsed.getTime()) ? new Date() : parsed;
}

/**
 * Helper to parse a percentage value like "60%" into a number (60).
 *
 * @param {string|number|null|undefined} value
 * @returns {number|null}
 */
function parsePercentage(value) {
  if (value == null) return null;
  if (typeof value === 'number') return value;
  const str = value.toString().trim();
  if (!str) return null;
  const num = parseFloat(str.replace('%', ''));
  return Number.isNaN(num) ? null : num;
}

/**
 * Calculates the Texas LIHTC set-aside thresholds and actual counts from
 * AMI bucket distribution.
 *
 * Thresholds (from quick reference):
 * - ≤80% AMI: at least 50% of total units (Low Income Units)
 * - ≤60% AMI: at least 10% of LIUs
 * - ≤30% AMI: at least 2% of LIUs
 *
 * @param {number} totalUnits
 * @param {Array<Object>} amiBuckets - buckets from hierarchicalDistribution.amiBuckets
 * @returns {{
 *   totalUnits: number;
 *   lowIncomeUnits: number;
 *   required: { ami80: number; ami60: number; ami30: number };
 *   actual: { ami80: number; ami60: number; ami30: number };
 *   compliant: boolean;
 * }}
 */
function evaluateTexasLIHTCSetAsides(totalUnits, amiBuckets) {
  const getBucketByPercentage = (target) =>
    amiBuckets.find((bucket) => parsePercentage(bucket.percentage) === target) ||
    null;

  const bucket80 = getBucketByPercentage(80);
  const bucket60 = getBucketByPercentage(60);
  const bucket30 = getBucketByPercentage(30);

  const lowIncomeUnits = bucket80 ? bucket80.numberOfUnits || 0 : 0;

  const required80 = Math.ceil(totalUnits * 0.5); // 50% of total units
  const required60 = Math.ceil(lowIncomeUnits * 0.1); // 10% of LIUs
  const required30 = Math.ceil(lowIncomeUnits * 0.02); // 2% of LIUs

  const actual80 = lowIncomeUnits;
  const actual60 = bucket60 ? bucket60.numberOfUnits || 0 : 0;
  const actual30 = bucket30 ? bucket30.numberOfUnits || 0 : 0;

  const passes80 = actual80 >= required80;
  const passes60 = actual60 >= required60;
  const passes30 = actual30 >= required30;

  return {
    totalUnits,
    lowIncomeUnits,
    required: {
      ami80: required80,
      ami60: required60,
      ami30: required30,
    },
    actual: {
      ami80: actual80,
      ami60: actual60,
      ami30: actual30,
    },
    compliant: passes80 && passes60 && passes30,
  };
}

/**
 * Calculates the maximum allowed rent for a specific household/unit under
 * Texas rules (quick reference).
 *
 * Two methods are considered:
 * 1) AMI-based regulatory limit (35% rule)
 *    MaxRent_AMI = 0.35 × (IncomeLimit / 12)
 *    using imputed household size = max(1, bedrooms + 1)
 * 2) Tenant income-based limit (30% rule)
 *    MaxRent_Income = 30% of monthly tenant income
 *
 * Final Texas rent limit:
 *   MaxRent_Texas = min(MaxRent_Income, MaxRent_AMI + utilityAllowance)
 *
 * @param {number} tenantAnnualIncome
 * @param {number} householdSize
 * @param {Array<Object>} amiData - AMI levels with householdIncomeLimits
 * @param {number} unitBedrooms
 * @param {number} [utilityAllowance=0]
 * @returns {{ maxRent: number|null; method: 'income'|'ami'|'both'|'insufficient_data'; details: Object }}
 */
function calculateTexasRentLimit(
  tenantAnnualIncome,
  householdSize,
  amiData,
  unitBedrooms,
  utilityAllowance = 0
) {
  if (
    !tenantAnnualIncome ||
    !householdSize ||
    !Array.isArray(amiData) ||
    amiData.length === 0
  ) {
    return {
      maxRent: null,
      method: 'insufficient_data',
      details: {},
    };
  }

  const monthlyIncome = tenantAnnualIncome / 12;
  const thirtyPercentOfIncome = monthlyIncome * 0.3;

  // Determine AMI qualification level for this household (30% / 60% / 80%)
  const amiByPercentage = new Map();
  for (const level of amiData) {
    if (typeof level.incomePercentage === 'number') {
      amiByPercentage.set(level.incomePercentage, level);
    }
  }

  const getIncomeLimit = (percentage) => {
    const level = amiByPercentage.get(percentage);
    if (!level || !level.householdIncomeLimits) return null;
    const limit =
      level.householdIncomeLimits[householdSize] ??
      level.householdIncomeLimits[String(householdSize)] ??
      null;
    return typeof limit === 'number' ? limit : null;
  };

  const ami30Limit = getIncomeLimit(30);
  const ami60Limit = getIncomeLimit(60);
  const ami80Limit = getIncomeLimit(80);

  let qualifiedAmiPercentage = null;
  if (ami30Limit && tenantAnnualIncome <= ami30Limit) {
    qualifiedAmiPercentage = 30;
  } else if (ami60Limit && tenantAnnualIncome <= ami60Limit) {
    qualifiedAmiPercentage = 60;
  } else if (ami80Limit && tenantAnnualIncome <= ami80Limit) {
    qualifiedAmiPercentage = 80;
  }

  let amiRentLimit = null;
  if (qualifiedAmiPercentage !== null) {
    const level = amiByPercentage.get(qualifiedAmiPercentage);
    if (level && level.householdIncomeLimits) {
      const imputedSize = Math.max(1, (unitBedrooms || 0) + 1); // bedrooms + 1
      const incomeLimit =
        level.householdIncomeLimits[imputedSize] ??
        level.householdIncomeLimits[String(imputedSize)] ??
        null;
      if (typeof incomeLimit === 'number') {
        amiRentLimit = 0.35 * (incomeLimit / 12);
      }
    }
  }

  const candidates = [];
  if (typeof thirtyPercentOfIncome === 'number' && !Number.isNaN(thirtyPercentOfIncome)) {
    candidates.push(thirtyPercentOfIncome);
  }
  if (typeof amiRentLimit === 'number' && !Number.isNaN(amiRentLimit)) {
    candidates.push(amiRentLimit + (utilityAllowance || 0));
  }

  if (candidates.length === 0) {
    return {
      maxRent: null,
      method: 'insufficient_data',
      details: {
        thirtyPercentOfIncome,
        amiRentLimit,
      },
    };
  }

  const maxRent = Math.min(...candidates);
  let method = 'both';
  if (candidates.length === 1) {
    method = amiRentLimit != null ? 'ami' : 'income';
  }

  return {
    maxRent,
    method,
    details: {
      monthlyIncome,
      thirtyPercentOfIncome,
      amiRentLimit,
      qualifiedAmiPercentage,
      utilityAllowance,
    },
  };
}

/**
 * Validates Texas LIHTC compliance for a building.
 *
 * Checks:
 * - Texas LIHTC set-aside thresholds (hierarchical ≤80/60/30% AMI)
 * - Income limit violations per unit (tenantIncome > incomeLimit)
 * - Rent limit violations per unit using Texas rent limit formula
 *
 * @param {string} buildingId
 * @param {string|Date|null} [checkDate=null]
 * @returns {Promise<Object>} Texas LIHTC compliance report
 */
async function validateTexasLIHTCCompliance(buildingId, checkDate = null) {
  const parsedDate = normalizeCheckDate(checkDate);

  const building = await Building.findById(buildingId);
  if (!building) {
    throw new Error('Building not found');
  }

  // Reuse building-level formula which already calculates AMI buckets and unitResults
  const formulaResult = await building.executeBuildingLevelFormula(parsedDate);

  const totalUnits = formulaResult.totalUnits || (Array.isArray(formulaResult.unitResults) ? formulaResult.unitResults.length : 0);
  const amiBuckets =
    formulaResult.hierarchicalDistribution?.amiBuckets || [];
  const unitResults = Array.isArray(formulaResult.unitResults)
    ? formulaResult.unitResults
    : [];

  const setAside = evaluateTexasLIHTCSetAsides(totalUnits, amiBuckets);

  // Income limit violations (tenantIncome > incomeLimit)
  const incomeViolations = unitResults.filter((unit) => {
    if (
      typeof unit.tenantIncome !== 'number' ||
      typeof unit.incomeLimit !== 'number'
    ) {
      return false;
    }
    return unit.tenantIncome > unit.incomeLimit;
  });

  // Rent limit violations using Texas rent limit formula where possible
  const rentViolations = [];
  for (const unit of unitResults) {
    const tenantIncome =
      typeof unit.tenantIncome === 'number' ? unit.tenantIncome : null;
    const householdSize =
      typeof unit.householdCount === 'number' ? unit.householdCount : null;
    const currentRent =
      typeof unit.currentRent === 'number' ? unit.currentRent : null;

    if (!tenantIncome || !householdSize || !currentRent) {
      continue;
    }

    const bedrooms =
      typeof unit.bedrooms === 'number' ? unit.bedrooms : null;

    // In the full app, AMI data is already baked into unitResults / formulaResult.
    // Here we assume formulaResult.amiData exists; if not, we fall back to maxAllowedRent.
    const amiData = Array.isArray(formulaResult.amiData)
      ? formulaResult.amiData
      : null;

    let texasLimit = null;
    if (amiData) {
      const texasRent = calculateTexasRentLimit(
        tenantIncome,
        householdSize,
        amiData,
        bedrooms || 0,
        0 // utilityAllowance placeholder; could be extended
      );
      texasLimit = texasRent.maxRent;
    }

    const fallbackLimit =
      typeof unit.maxAllowedRent === 'number'
        ? unit.maxAllowedRent
        : null;

    const effectiveLimit =
      typeof texasLimit === 'number' && !Number.isNaN(texasLimit)
        ? texasLimit
        : fallbackLimit;

    if (
      typeof effectiveLimit === 'number' &&
      !Number.isNaN(effectiveLimit) &&
      currentRent > effectiveLimit
    ) {
      rentViolations.push({
        unitId: unit.unitId,
        unitNumber: unit.unitNumber,
        currentRent,
        effectiveLimit,
      });
    }
  }

  const incomeCompliant = incomeViolations.length === 0;
  const rentCompliant = rentViolations.length === 0;

  const overallCompliant =
    setAside.compliant && incomeCompliant && rentCompliant;

  return {
    buildingId: building._id.toString(),
    buildingName: building.name,
    checkDate: parsedDate.toISOString().split('T')[0],
    overallStatus: overallCompliant ? 'Compliant' : 'Non-Compliant',
    setAside,
    incomeCompliance: {
      compliant: incomeCompliant,
      violationCount: incomeViolations.length,
      violations: incomeViolations.map((u) => ({
        unitId: u.unitId,
        unitNumber: u.unitNumber,
        tenantIncome: u.tenantIncome,
        incomeLimit: u.incomeLimit,
      })),
    },
    rentCompliance: {
      compliant: rentCompliant,
      violationCount: rentViolations.length,
      violations: rentViolations,
    },
  };
}

/**
 * Optional helper to validate Texas set-aside requirements given a simple
 * buildingData + regulatoryAgreement snapshot. This is not wired into the
 * main API but demonstrates how the logic can be reused for other callers.
 *
 * @param {{ totalUnits: number; unitsByAmi: Record<number, number> }} buildingData
 * @param {{ lowIncomeThreshold80?: number; lowIncomeThreshold60?: number; lowIncomeThreshold30?: number }} regulatoryAgreement
 * @returns {{ compliant: boolean; details: any }}
 */
function validateTexasSetAside(buildingData, regulatoryAgreement = {}) {
  const totalUnits = buildingData.totalUnits || 0;
  const unitsByAmi = buildingData.unitsByAmi || {};
  const lowIncomeUnits = unitsByAmi[80] || 0;

  const required80 =
    regulatoryAgreement.lowIncomeThreshold80 ??
    Math.ceil(totalUnits * 0.5);
  const required60 =
    regulatoryAgreement.lowIncomeThreshold60 ??
    Math.ceil(lowIncomeUnits * 0.1);
  const required30 =
    regulatoryAgreement.lowIncomeThreshold30 ??
    Math.ceil(lowIncomeUnits * 0.02);

  const actual80 = lowIncomeUnits;
  const actual60 = unitsByAmi[60] || 0;
  const actual30 = unitsByAmi[30] || 0;

  const compliant =
    actual80 >= required80 &&
    actual60 >= required60 &&
    actual30 >= required30;

  return {
    compliant,
    details: {
      totalUnits,
      lowIncomeUnits,
      required: {
        ami80: required80,
        ami60: required60,
        ami30: required30,
      },
      actual: {
        ami80: actual80,
        ami60: actual60,
        ami30: actual30,
      },
    },
  };
}

module.exports = {
  validateTexasLIHTCCompliance,
  calculateTexasRentLimit,
  validateTexasSetAside,
};


