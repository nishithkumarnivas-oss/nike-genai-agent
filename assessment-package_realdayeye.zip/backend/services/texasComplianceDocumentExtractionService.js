/**
 * Texas Compliance Document Extraction Service
 * 
 * Extracts Texas-specific compliance requirements from regulatory documents
 * using Azure Document Intelligence and Azure OpenAI.
 * 
 * This service follows the pattern established in regulatoryDocumentService.js
 * and focuses specifically on Texas affordable housing compliance requirements.
 */

// Note: In a real implementation, these would be imported from actual service modules
// For this assessment, we'll assume they follow the same pattern as regulatoryDocumentService.js
// const AzureFormRecognizerService = require('./azureFormRecognizerService');
// const { callAzureOpenAI } = require('./azureOpenAIService');

// Mock/stub implementations for assessment (would use real services in production)
const AzureFormRecognizerService = {
    async analyzeDocument(fileBuffer, mimeType) {
        // In production, this would call Azure Document Intelligence API
        // For assessment, we'll throw an error indicating this needs real implementation
        throw new Error('AzureFormRecognizerService.analyzeDocument must be implemented with actual Azure Document Intelligence SDK');
    }
};

const callAzureOpenAI = async (prompt, maxTokens = 2000, temperature = 0.3, systemMessage = null) => {
    // In production, this would call Azure OpenAI API
    // For assessment, we'll throw an error indicating this needs real implementation
    throw new Error('callAzureOpenAI must be implemented with actual Azure OpenAI SDK');
};

class TexasComplianceDocumentExtractionService {
    constructor() {
        this.formRecognizer = AzureFormRecognizerService;
        this.maxRetries = 2;
        this.retryDelay = 1000; // 1 second
    }

    /**
     * Extracts Texas compliance requirements from a regulatory document
     * 
     * @param {Buffer} fileBuffer - PDF file buffer
     * @param {string} fileName - Original file name
     * @param {string} mimeType - MIME type (should be 'application/pdf')
     * @returns {Promise<Object>} Extracted Texas compliance requirements with confidence scores
     */
    async extractTexasComplianceRequirements(fileBuffer, fileName, mimeType) {
        try {
            // Validate file type
            if (mimeType !== 'application/pdf') {
                throw new Error(`Unsupported file type: ${mimeType}. Only PDF files are supported.`);
            }

            console.log(`[Texas Compliance Extraction] Starting extraction for file: ${fileName}`);

            // Step 1: Extract text and structure using Azure Document Intelligence
            const analyzeResult = await this.analyzeDocumentWithRetry(fileBuffer, mimeType);

            // Step 2: Extract all text content from the document
            const extractedText = this.extractTextFromAnalyzeResult(analyzeResult);

            if (!extractedText || extractedText.trim().length === 0) {
                throw new Error('No text could be extracted from the document. The PDF may be image-based or corrupted.');
            }

            console.log(`[Texas Compliance Extraction] Extracted ${extractedText.length} characters of text`);

            // Step 3: Use Azure OpenAI to extract structured Texas compliance requirements
            const extractedData = await this.extractComplianceDataWithRetry(extractedText, fileName);

            // Step 4: Validate and add confidence scores
            const validatedData = this.validateAndScoreExtraction(extractedData);

            // Step 5: Return structured result
            return {
                success: true,
                fileName: fileName,
                extractedAt: new Date().toISOString(),
                data: validatedData,
                metadata: {
                    textLength: extractedText.length,
                    extractionMethod: 'azure_openai',
                    documentType: validatedData.programType?.value || 'Unknown'
                }
            };
        } catch (error) {
            console.error('[Texas Compliance Extraction] Error:', error);
            throw error;
        }
    }

    /**
     * Analyzes document with retry logic for Azure service failures
     * 
     * @param {Buffer} fileBuffer - PDF file buffer
     * @param {string} mimeType - MIME type
     * @returns {Promise<Object>} Azure Document Intelligence analyze result
     */
    async analyzeDocumentWithRetry(fileBuffer, mimeType) {
        let lastError;
        
        for (let attempt = 0; attempt <= this.maxRetries; attempt++) {
            try {
                return await this.formRecognizer.analyzeDocument(fileBuffer, mimeType);
            } catch (error) {
                lastError = error;
                if (attempt < this.maxRetries) {
                    console.log(`[Texas Compliance Extraction] Retry attempt ${attempt + 1}/${this.maxRetries} for document analysis`);
                    await this.delay(this.retryDelay * (attempt + 1)); // Exponential backoff
                }
            }
        }
        
        throw new Error(`Failed to analyze document after ${this.maxRetries + 1} attempts: ${lastError.message}`);
    }

    /**
     * Extracts text content from Azure Document Intelligence analyze result
     * Follows the same pattern as regulatoryDocumentService.js
     * 
     * @param {Object} analyzeResult - Result from Azure Document Intelligence
     * @returns {string} Extracted text content
     */
    extractTextFromAnalyzeResult(analyzeResult) {
        let extractedText = '';

        // Extract text from paragraphs
        if (analyzeResult.paragraphs && Array.isArray(analyzeResult.paragraphs)) {
            analyzeResult.paragraphs.forEach(paragraph => {
                if (paragraph.content) {
                    extractedText += paragraph.content + '\n\n';
                }
            });
        }

        // Extract text from tables (important for income limits, set-asides, etc.)
        if (analyzeResult.tables && Array.isArray(analyzeResult.tables)) {
            analyzeResult.tables.forEach((table, tableIndex) => {
                extractedText += `\n--- Table ${tableIndex + 1} ---\n`;

                // Group cells by row
                const rows = {};
                if (table.cells && Array.isArray(table.cells)) {
                    table.cells.forEach(cell => {
                        if (!rows[cell.rowIndex]) {
                            rows[cell.rowIndex] = [];
                        }
                        rows[cell.rowIndex][cell.columnIndex] = cell.content || '';
                    });
                }

                // Convert rows to text
                Object.keys(rows).sort((a, b) => parseInt(a) - parseInt(b)).forEach(rowIndex => {
                    const row = rows[rowIndex];
                    const rowText = row.map(cell => cell || '').join(' | ');
                    extractedText += rowText + '\n';
                });
                extractedText += '\n';
            });
        }

        return extractedText.trim();
    }

    /**
     * Extracts Texas compliance data using Azure OpenAI with retry logic
     * 
     * @param {string} extractedText - Text extracted from document
     * @param {string} fileName - Original file name
     * @returns {Promise<Object>} Extracted compliance data
     */
    async extractComplianceDataWithRetry(extractedText, fileName) {
        let lastError;

        for (let attempt = 0; attempt <= this.maxRetries; attempt++) {
            try {
                const prompt = this.buildExtractionPrompt(extractedText, fileName);
                const systemMessage = this.buildSystemMessage();
                
                const response = await callAzureOpenAI(prompt, 3000, 0.2, systemMessage);
                
                // Parse JSON response
                const parsedResponse = JSON.parse(response.trim());
                return parsedResponse;
            } catch (error) {
                lastError = error;
                if (attempt < this.maxRetries) {
                    console.log(`[Texas Compliance Extraction] Retry attempt ${attempt + 1}/${this.maxRetries} for AI extraction`);
                    await this.delay(this.retryDelay * (attempt + 1));
                }
            }
        }

        throw new Error(`Failed to extract compliance data after ${this.maxRetries + 1} attempts: ${lastError.message}`);
    }

    /**
     * Builds the extraction prompt for Azure OpenAI
     * 
     * PROMPT STRATEGY EXPLANATION:
     * 
     * This prompt is structured to maximize extraction accuracy for Texas compliance documents:
     * 
     * 1. **Role Definition**: Establishes the AI as an expert in Texas affordable housing compliance,
     *    which helps it understand domain-specific terminology and context.
     * 
     * 2. **Explicit JSON Schema**: Provides a complete, detailed JSON structure with all required fields.
     *    This reduces ambiguity and ensures consistent output format. Each field includes:
     *    - Expected data types
     *    - Allowed enum values (for programType, etc.)
     *    - Null handling instructions
     * 
     * 3. **Confidence Scoring**: Requires confidence scores (0.0-1.0) for each field, enabling
     *    downstream systems to flag low-confidence extractions for manual review.
     * 
     * 4. **Texas-Specific Context**: Includes key Texas compliance knowledge:
     *    - Common LIHTC set-aside patterns (20% at 50% AMI OR 40% at 60% AMI)
     *    - Typical rent limit calculations (30% of income OR 35% of AMI limit)
     *    - Texas regulatory bodies (TDHCA, HUD)
     *    - Geographic area formats (counties, MSAs)
     * 
     * 5. **Concrete Examples**: Provides 4 detailed examples showing:
     *    - How to extract set-asides from percentage-based language
     *    - How to parse income limits from tables or text
     *    - How to identify rent limit calculation methods
     *    - How to extract geographic areas with exact text preservation
     * 
     * 6. **Edge Case Handling**: Explicitly instructs the AI to:
     *    - Use null for missing data (not empty strings or placeholders)
     *    - Provide confidence scores based on data certainty
     *    - Include explanatory notes for ambiguous cases
     *    - Handle partial matches (e.g., percentages without unit counts)
     * 
     * 7. **Structured Extraction Guidelines**: For each field type, provides:
     *    - Keywords to search for
     *    - Common phrases and patterns
     *    - Table extraction strategies (for income limits)
     * 
     * 8. **Output Format Enforcement**: Multiple reminders to return ONLY valid JSON,
     *    which helps prevent formatting errors that would break parsing.
     * 
     * This strategy balances specificity (to get accurate extractions) with flexibility
     * (to handle varied document formats) while maintaining structured, parseable output.
     * 
     * @param {string} extractedText - Text extracted from document
     * @param {string} fileName - Original file name
     * @returns {string} Formatted prompt
     */
    buildExtractionPrompt(extractedText, fileName) {
        // Limit text length to avoid token limits (keep ~6000 chars for context)
        const textPreview = extractedText.length > 6000 
            ? extractedText.substring(0, 6000) + '\n\n[... document continues ...]'
            : extractedText;

        return `You are an expert in Texas affordable housing compliance regulations, specializing in LIHTC (Low-Income Housing Tax Credit), Section 8, and Texas state housing programs.

Your task is to extract Texas-specific compliance requirements from the regulatory document provided below.

**CRITICAL: Return ONLY valid JSON. No additional text, explanations, or markdown formatting.**

**Required JSON Structure:**
{
  "programType": {
    "value": "LIHTC" | "SECTION_8" | "STATE_PROGRAM" | "HOME" | "OTHER" | null,
    "confidence": 0.0-1.0,
    "notes": "Brief explanation if ambiguous"
  },
  "setAsideRequirements": {
    "value": {
      "30": <number of units required at 30% AMI or null>,
      "60": <number of units required at 60% AMI or null>,
      "80": <number of units required at 80% AMI or null>,
      "description": "Text description of set-aside requirements"
    },
    "confidence": 0.0-1.0,
    "notes": "Any relevant details about set-aside calculations"
  },
  "incomeLimits": {
    "value": {
      "source": "TDHCA" | "HUD" | "State Program" | "Other" | null,
      "fiscalYear": "YYYY" | null,
      "limitsByHouseholdSize": {
        "1": <income limit for 1-person household> | null,
        "2": <income limit for 2-person household> | null,
        "3": <income limit for 3-person household> | null,
        "4": <income limit for 4-person household> | null,
        "5": <income limit for 5-person household> | null,
        "6": <income limit for 6-person household> | null,
        "7": <income limit for 7-person household> | null,
        "8": <income limit for 8-person household> | null
      },
      "amiPercentages": ["30", "60", "80"] | null
    },
    "confidence": 0.0-1.0,
    "notes": "Details about income limit source or calculations"
  },
  "rentLimits": {
    "value": {
      "calculationMethod": "35% of income limit" | "30% of tenant income" | "AMI-based" | "Other" | null,
      "affordabilityPercentage": <number 0-100> | null,
      "utilityAllowanceIncluded": true | false | null,
      "description": "Text description of rent limit calculation"
    },
    "confidence": 0.0-1.0,
    "notes": "Details about rent limit calculations or formulas"
  },
  "effectiveDates": {
    "value": {
      "startDate": "YYYY-MM-DD" | null,
      "endDate": "YYYY-MM-DD" | null,
      "compliancePeriod": <number of years> | null
    },
    "confidence": 0.0-1.0,
    "notes": "Any relevant date information"
  },
  "geographicArea": {
    "value": {
      "county": "<county name>" | null,
      "msa": "<MSA name>" | null,
      "city": "<city name>" | null,
      "fipsCode": "<FIPS code>" | null,
      "rawText": "<exact text from document>"
    },
    "confidence": 0.0-1.0,
    "notes": "Geographic area for AMI calculations"
  },
  "utilityAllowances": {
    "value": {
      "amount": <dollar amount> | null,
      "perUnit": true | false | null,
      "perBedroom": true | false | null,
      "description": "Text description of utility allowance"
    },
    "confidence": 0.0-1.0,
    "notes": "Utility allowance details"
  }
}

**Texas Compliance Context:**
- **LIHTC**: Typically requires 20% at 50% AMI OR 40% at 60% AMI set-asides
- **Set-Asides**: Often expressed as percentages (e.g., "40% of units at 60% AMI")
- **Income Limits**: Usually from TDHCA (Texas Department of Housing and Community Affairs) or HUD
- **Rent Limits**: Typically 30% of adjusted income OR 35% of AMI-based income limit (whichever is lower)
- **Geographic Areas**: Texas counties (e.g., "Travis County"), MSAs (e.g., "Austin-Round Rock MSA"), or cities
- **Utility Allowances**: May be specified per unit, per bedroom, or as a flat amount

**Extraction Guidelines:**
1. **Program Type**: Look for keywords like "LIHTC", "Low-Income Housing Tax Credit", "Section 8", "HUD", "TDHCA", "Texas Department of Housing"
2. **Set-Asides**: Search for phrases like "X% at Y% AMI", "minimum units", "set-aside", "reservation requirements"
3. **Income Limits**: Look for tables with household size and income limits, or references to "AMI", "Area Median Income"
4. **Rent Limits**: Search for "rent limit", "maximum rent", "affordability", "30% of income", "35% of income limit"
5. **Effective Dates**: Look for "effective date", "compliance period", "term", dates in YYYY-MM-DD format
6. **Geographic Area**: Extract exact text mentioning county, MSA, city, or FIPS codes
7. **Utility Allowances**: Look for "utility allowance", "utility reimbursement", dollar amounts for utilities

**Handling Missing/Ambiguous Data:**
- If a field cannot be determined, set value to null and confidence to 0.0
- If partially determined, provide best estimate with lower confidence (0.5-0.7)
- If clearly stated, use high confidence (0.8-1.0)
- Always include notes explaining your reasoning for ambiguous cases
- For set-asides, if only percentages are given, note that actual unit counts depend on total building units

**Examples of Texas Compliance Requirements:**

Example 1 - LIHTC Set-Aside:
"At least 40% of the units must be occupied by households at or below 60% of Area Median Income (AMI)."
→ setAsideRequirements.value.60 = null (percentage only, not unit count), description = "40% of units at 60% AMI"

Example 2 - Income Limits:
"Household income limits for 4-person household at 60% AMI: $56,760 (TDHCA 2024)"
→ incomeLimits.value.limitsByHouseholdSize.4 = 56760, source = "TDHCA", fiscalYear = "2024"

Example 3 - Rent Limits:
"Maximum rent shall not exceed 30% of the household's adjusted monthly income or the HUD-determined rent limit, whichever is lower."
→ rentLimits.value.calculationMethod = "30% of tenant income", utilityAllowanceIncluded = false

Example 4 - Geographic Area:
"This property is located in Travis County, Texas, within the Austin-Round Rock Metropolitan Statistical Area."
→ geographicArea.value.county = "Travis County", msa = "Austin-Round Rock", rawText = "Travis County, Texas, within the Austin-Round Rock Metropolitan Statistical Area"

**Document Information:**
- File Name: ${fileName}
- Text Length: ${extractedText.length} characters

**Document Content:**
${textPreview}

**Remember:**
- Return ONLY valid JSON
- Use null for missing data
- Provide confidence scores (0.0-1.0) for each field
- Include notes for ambiguous or partially extracted data
- Focus on Texas-specific compliance requirements`;
    }

    /**
     * Builds the system message for Azure OpenAI
     * 
     * @returns {string} System message
     */
    buildSystemMessage() {
        return `You are an expert legal document analyst specializing in Texas affordable housing compliance regulations. You extract structured data from regulatory documents with high accuracy. You always return valid JSON in the exact format specified, with appropriate confidence scores and explanatory notes.`;
    }

    /**
     * Validates extracted data structure and adds confidence scores
     * Flags low-confidence extractions (< 0.7) for manual review
     * 
     * @param {Object} extractedData - Raw extracted data from AI
     * @returns {Object} Validated data with confidence scores
     */
    validateAndScoreExtraction(extractedData) {
        const validated = {
            programType: this.validateField(extractedData.programType, ['LIHTC', 'SECTION_8', 'STATE_PROGRAM', 'HOME', 'OTHER']),
            setAsideRequirements: this.validateField(extractedData.setAsideRequirements, null, (val) => {
                if (val && typeof val === 'object') {
                    // Validate set-aside structure
                    if (val.value && typeof val.value === 'object') {
                        const validKeys = ['30', '60', '80', 'description'];
                        const cleaned = {};
                        validKeys.forEach(key => {
                            if (key in val.value) {
                                cleaned[key] = val.value[key];
                            }
                        });
                        return { ...val, value: cleaned };
                    }
                }
                return val;
            }),
            incomeLimits: this.validateField(extractedData.incomeLimits),
            rentLimits: this.validateField(extractedData.rentLimits),
            effectiveDates: this.validateField(extractedData.effectiveDates),
            geographicArea: this.validateField(extractedData.geographicArea),
            utilityAllowances: this.validateField(extractedData.utilityAllowances)
        };

        // Flag low-confidence fields for manual review
        validated.requiresManualReview = [];
        Object.keys(validated).forEach(key => {
            if (key !== 'requiresManualReview' && validated[key] && validated[key].confidence !== undefined) {
                if (validated[key].confidence < 0.7) {
                    validated.requiresManualReview.push({
                        field: key,
                        confidence: validated[key].confidence,
                        reason: validated[key].notes || 'Low confidence extraction'
                    });
                }
            }
        });

        return validated;
    }

    /**
     * Validates a single field structure
     * 
     * @param {Object} field - Field to validate
     * @param {Array|null} allowedValues - Allowed values for enum fields
     * @param {Function|null} customValidator - Custom validation function
     * @returns {Object} Validated field
     */
    validateField(field, allowedValues = null, customValidator = null) {
        if (!field || typeof field !== 'object') {
            return {
                value: null,
                confidence: 0.0,
                notes: 'Field not found in extraction'
            };
        }

        // Apply custom validator if provided
        if (customValidator) {
            field = customValidator(field);
        }

        // Validate enum values if provided
        if (allowedValues && field.value && !allowedValues.includes(field.value)) {
            return {
                ...field,
                value: null,
                confidence: Math.min(field.confidence || 0.0, 0.5),
                notes: (field.notes || '') + ' Invalid enum value.'
            };
        }

        // Ensure confidence is a number between 0 and 1
        if (field.confidence === undefined || field.confidence === null) {
            field.confidence = 0.5; // Default to medium confidence if not provided
        } else {
            field.confidence = Math.max(0.0, Math.min(1.0, parseFloat(field.confidence)));
        }

        return field;
    }

    /**
     * Simple delay utility for retry logic
     * 
     * @param {number} ms - Milliseconds to delay
     * @returns {Promise<void>}
     */
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

module.exports = new TexasComplianceDocumentExtractionService();

