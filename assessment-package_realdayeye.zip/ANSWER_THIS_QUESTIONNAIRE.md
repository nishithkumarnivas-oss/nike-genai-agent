# Candidate Review Questionnaire - RealComply Technical Assessment

## Context

We are hiring for a **Fullstack Developer** position at RealComply. As part of our technical assessment process, we sent a full-stack development assessment to a candidate named **John McClane**. The assessment involved building a Texas Affordable Housing Compliance system with database design, TypeScript architecture, and AI-powered document extraction capabilities.

John McClane has completed the assessment and submitted his work, which includes:
- A completed codebase (backend and TypeScript services)
- A detailed submission document (`ASSESSMENT_SUBMISSION.md`) explaining his approach and decisions

## Your Task

As a technical reviewer, you need to evaluate John McClane's submission and provide feedback to the hiring manager, **Hans Gruber**. Your review will help determine whether this candidate should proceed to the next stage of the hiring process.

**Please review the provided assessment submission and codebase, then answer the following questions to provide comprehensive feedback.**

## Instructions

**Important:** 
- You **cannot ask questions** about the requirements, code, or business logic
- Work with the information provided in the documentation and codebase
- Make your own reasonable assumptions where information is unclear or missing
- Document any assumptions you make in your answers
- Base your analysis on what you can observe in the code and documentation provided
- Your answers will be shared with the hiring manager (Hans Gruber), so be thorough and professional

**Time Estimate:** 2-3 hours

---

## Part 1: Business Problem Comprehension

### Question 1.1: Texas Compliance Requirements Understanding

The assessment involves Texas Affordable Housing Compliance. Based on your review of the code and the `TEXAS_COMPLIANCE_QUICK_REFERENCE.md` documentation:

**a)** According to the documentation, what are Texas LIHTC set-aside requirements? What does it mean for a building to be "compliant" with set-aside requirements? Pay special attention to the note about hierarchical thresholds.

**b)** The code stores set-aside requirements as `{ "30": 5, "60": 40 }` meaning 5 units at 30% AMI and 40 units at 60% AMI. The code comment says "Each AMI level has independent requirements that must be met separately." Based on the documentation you reviewed, is this comment accurate? Why or why not?

**c)** The documentation mentions "Geographic Areas: AMI data varies by Texas county/MSA (FIPS codes)" and "Effective Dates: Compliance rules may change over time." The schema code includes a comment stating "buildings don't change geographic areas" and stores AMI area data. Based on what the documentation says about effective dates and changing compliance rules, do you see any potential issues with how AMI geographic area is handled in the schema?

---

### Question 1.2: Effective Dates & Time-Based Tracking

**a)** The `TEXAS_COMPLIANCE_QUICK_REFERENCE.md` mentions "Effective Dates: Compliance rules may change over time - use date-based lookups." The schema includes `periodStart` and `periodEnd` fields. How should these dates be used to track compliance over time?

**b)** The schema also includes a `compliancePeriodYears` field with a default value. Based on the code and comments, what does this field represent? Do you see any issues with how it's implemented?

**c)** What considerations are important when tracking compliance requirements that may change over time?

---

### Question 1.3: Rent Limit Calculations

**a)** The submission mentions two methods for calculating rent limits:
   - Method 1: 30% of monthly tenant income
   - Method 2: 35% of AMI-based income limit

   How should these two methods be combined? Which one takes precedence?

**b)** What role do utility allowances play in rent limit calculations?

**c)** If a tenant qualifies for 60% AMI, do they also qualify for 80% AMI limits? Why or why not?

---

## Part 2: Code Review & Correctness

### Question 2.1: Design Pattern Claims

The submission claims the implementation uses five design patterns: Strategy, Repository, Factory, Façade, and Result/Either.

**a)** Review the TypeScript service code (`typescript-services/src/services/TexasComplianceService.ts`). Which design patterns do you observe being used in this service? Explain your reasoning and provide evidence from the code.

**b)** Review the error handling in the codebase. Is a Result/Either pattern actually implemented? Provide evidence from the code.

**c)** Compare your findings from (a) and (b) with the patterns claimed in the submission. Are there any discrepancies? If so, what pattern(s) would you say are actually being used instead?

---

### Question 2.2: MongoDB Schema Review

Review the `TexasComplianceAudit` schema (`backend/models/TexasComplianceAudit.js`):

**a)** How is AMI (Area Median Income) geographic area data implemented in the schema? Review the fields related to AMI area tracking and explain how this data is stored and used.

**b)** The `setAsideRequirements` field uses `mongoose.Schema.Types.Mixed` with no validation. What risks does this pose?

**After answering the above questions, do you think the schema was well designed? What improvements would you suggest?**

---

### Question 2.3: Business Logic Implementation

Review the Texas compliance service (`backend/services/texasComplianceService.js`):

**a)** The `evaluateTexasLIHTCSetAsides` function calculates required units. Review the calculation logic - is it correct according to Texas compliance rules?

**b)** The `calculateTexasRentLimit` function determines which AMI level a tenant qualifies for. Does it correctly handle the hierarchical nature of AMI qualification (30% → 60% → 80%)?

**c)** Are there any business logic errors in the compliance calculations? If so, describe them.

---

## Part 3: Technical Risks & Architecture

### Question 3.1: Technical Risks

**a)** What are the main technical risks you identify in this codebase? Consider:
   - Data integrity risks
   - Performance risks
   - Maintainability risks
   - Scalability risks

**b)** Rank these risks by severity (High/Medium/Low) and explain your reasoning.

**c)** For the highest-priority risk, propose a mitigation strategy.

---

### Question 3.2: Code Quality Issues

**a)** Identify code smells in the codebase. Examples to consider:
   - Duplicate code
   - Magic numbers/strings
   - Missing validation
   - Inconsistent patterns
   - Poor naming

**b)** For each code smell identified, explain:
   - Why it's a problem
   - What impact it has
   - How you would fix it

---

## Part 4: Testing Strategy

### Question 4.1: Testing Approach

**a)** What testing strategy would you recommend for this codebase? Consider:
   - Unit tests
   - Integration tests
   - End-to-end tests
   - Compliance calculation tests

**b)** What testing frameworks and tools would you use? Why?

**c)** How would you test the Texas compliance calculations to ensure they're correct?

**d)** How would you test the MongoDB schema? What aspects need testing?

---

### Question 4.2: Test Data & Scenarios

**a)** What test data would you need to thoroughly test the compliance calculations? Consider:
   - Different AMI levels (30%, 60%, 80%)
   - Different household sizes
   - Edge cases (boundary conditions)
   - Invalid inputs

**b)** What specific test scenarios are critical for Texas compliance? List at least 5 scenarios.

**c)** How would you handle testing with real AMI data? Would you use fixtures, mocks, or real data?

---

### Question 4.3: Write Two Tests

**Test 1: Set-Aside Compliance Calculation**

Write a test (using your preferred testing framework) that verifies the set-aside compliance calculation is correct. The test should:
- Set up a building with a known number of units
- Set up units with known AMI qualifications
- Verify that the set-aside calculation correctly identifies compliance/non-compliance
- Test the hierarchical nature of AMI buckets (30% units count toward 60% and 80%)

**Provide your test code below:**

```javascript
// Your Test 1 code here
```

---

**Test 2: Rent Limit Calculation**

Write a test that verifies the Texas rent limit calculation. The test should:
- Test both calculation methods (30% of income vs 35% of AMI limit)
- Verify the correct method is used (minimum of the two)
- Test with different household sizes and AMI levels
- Test edge cases (boundary conditions)

**Provide your test code below:**

```javascript
// Your Test 2 code here
```

---

## Part 5: AI System Design

### Question 5.1: Regulatory Document Processing System

You need to design a system that processes handwritten regulatory documents. The system should:

1. **Read handwritten documents** that define housing compliance regulations
2. **Classify the document** to determine what type of regulatory agreement it is (e.g., Texas LIHTC, Section 8, HOME, State Program, or other)
3. **If the regulatory agreement is Texas type**, extract the different AMI percentage requirements (30%, 50%, 60%, 80%, etc.) dynamically to create compliance calculation formulas

**a)** Design a process flow for this system. Describe each step from document upload to formula generation. Include:
   - Document processing steps
   - Classification logic
   - Data extraction requirements
   - Formula generation approach

**b)** What technologies would you use to implement this system? Explain your technology choices and how each component fits into your process flow.

**c)** How would you structure the prompts for the LLM components? Specifically:
   - How would you prompt the LLM to classify the regulatory agreement type?
   - How would you prompt the LLM to extract AMI percentage requirements?
   - Would you ask the LLM to return JSON? Why or why not?
   - What output format would you use and how would you ensure structured, parseable results?

**d)** What challenges do you anticipate with handwritten documents, and how would you address them?

**e)** How would you validate and verify the accuracy of the extracted data and generated formulas?

---

## Submission Instructions

Please provide your answers in a clear, well-organized format suitable for sharing with Hans Gruber (hiring manager). You may use:
- Code blocks for code examples
- Bullet points for lists
- Diagrams if helpful (ASCII art or descriptions)

**Important Reminders:**
- **Do not ask questions** - make reasonable assumptions based on the provided materials
- If information is unclear, state your assumptions clearly
- Base all answers on the code and documentation provided in the assessment folder
- Focus on what you can observe and analyze, not external knowledge
- Remember: Your feedback will be used by Hans Gruber (hiring manager) to evaluate John McClane's candidacy for the Front-End Developer position
- Be professional, constructive, and specific in your feedback

**Focus Areas:**
- Demonstrate understanding of business requirements (based on provided documentation)
- Identify issues accurately (by comparing code to documentation and best practices)
- Provide constructive, actionable feedback that will help Hans Gruber (hiring manager) make an informed decision
- Show technical depth in your analysis
- Evaluate the candidate's technical skills, code quality, and problem-solving approach

**Evaluation Criteria:**
- Business comprehension (25%) - Understanding based on provided documentation
- Code review accuracy (30%) - Identifying issues by comparing code to docs/patterns
- Technical analysis (20%) - Identifying risks and code smells
- Testing approach (10%) - Proposing appropriate tests
- AI system design (10%) - Process flow, technology choices, prompting strategy
- Communication & clarity (5%) - Clear explanations and documented assumptions

---

**Your review is critical for the hiring decision. Take your time and be thorough in your evaluation.**
