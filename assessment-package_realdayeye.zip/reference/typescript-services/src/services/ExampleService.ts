/**
 * Example TypeScript Service
 * 
 * This file demonstrates TypeScript service patterns including:
 * - Service class structure
 * - Interface usage
 * - Dependency injection
 * - Type safety
 * 
 * Use this as a reference for Task 2 - create your implementation in typescript-services/
 */

// Interface for service dependencies
interface IRepository {
  findById(id: string): Promise<any>;
  save(data: any): Promise<any>;
}

// Interface for the service itself
interface IExampleService {
  processData(id: string): Promise<ProcessResult>;
}

// Type definitions
interface ProcessResult {
  success: boolean;
  data?: any;
  error?: string;
}

/**
 * Example service class demonstrating TypeScript patterns
 */
export class ExampleService implements IExampleService {
  private repository: IRepository;

  /**
   * Constructor with dependency injection
   * @param repository - Repository instance for data access
   */
  constructor(repository: IRepository) {
    this.repository = repository;
  }

  /**
   * Process data with proper error handling
   * @param id - Identifier for the data to process
   * @returns Promise resolving to process result
   */
  async processData(id: string): Promise<ProcessResult> {
    try {
      if (!id || id.trim().length === 0) {
        return {
          success: false,
          error: 'Invalid ID provided'
        };
      }

      const data = await this.repository.findById(id);
      
      if (!data) {
        return {
          success: false,
          error: 'Data not found'
        };
      }

      // Process the data
      const processed = this.transformData(data);

      return {
        success: true,
        data: processed
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred'
      };
    }
  }

  /**
   * Private method for data transformation
   * @param data - Raw data to transform
   * @returns Transformed data
   */
  private transformData(data: any): any {
    // Example transformation logic
    return {
      ...data,
      processedAt: new Date().toISOString()
    };
  }
}
