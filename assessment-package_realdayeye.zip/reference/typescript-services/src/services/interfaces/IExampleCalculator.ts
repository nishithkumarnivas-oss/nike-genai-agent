/**
 * Example Interface for Calculator Pattern
 * 
 * This demonstrates:
 * - Interface definition for strategy pattern
 * - Type definitions
 * - Method signatures
 * 
 * Use this pattern for your IComplianceCalculator interface in Task 2
 */

// Type definitions
interface CalculationInput {
  value: number;
  multiplier?: number;
}

interface CalculationResult {
  result: number;
  isValid: boolean;
  errors?: string[];
}

/**
 * Interface for calculator implementations
 * This follows the Strategy Pattern - different implementations can be swapped
 */
export interface IExampleCalculator {
  /**
   * Perform calculation
   * @param input - Input data for calculation
   * @returns Calculation result with validation
   */
  calculate(input: CalculationInput): CalculationResult;

  /**
   * Validate input before calculation
   * @param input - Input to validate
   * @returns True if input is valid
   */
  validate(input: CalculationInput): boolean;
}
