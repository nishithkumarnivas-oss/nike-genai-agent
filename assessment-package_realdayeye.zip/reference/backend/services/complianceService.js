/**
 * Compliance Service
 * 
 * Centralizes compliance-related business logic including:
 * - Date validation
 * - Compliance data extraction (with priority system)
 * - Building compliance status calculation
 * - Bucket compliance details
 * - Compliance export data
 * - Bucket filtering
 */

const Building = require('../models/Building');
const Unit = require('../models/Unit');
const Lease = require('../models/Lease');
const Household = require('../models/Household');
const { getAMIDataForBuilding } = require('../utils/amiDataHelper');
const buildingHelpers = require('../utils/buildingHelpers');

/**
 * Validates and parses a date value from query parameters
 * @param {string|Array} dateValue - Date value from query (may be array)
 * @param {boolean} allowNull - If true, returns null for missing dates instead of current date
 * @returns {Date} Parsed date object
 * @throws {Error} If date format is invalid
 */
function validateAndParseDate(dateValue, allowNull = false) {
    if (!dateValue) {
        if (allowNull) return null;
        return new Date();
    }

    // Handle array parameters (take first element)
    const value = Array.isArray(dateValue) ? dateValue[0] : dateValue;

    // Trim whitespace and validate it's a string
    if (typeof value !== 'string' || value.trim() === '') {
        throw new Error('Invalid date format. Use YYYY-MM-DD');
    }

    const trimmedDate = value.trim();

    // Validate date format (YYYY-MM-DD)
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRegex.test(trimmedDate)) {
        throw new Error('Invalid date format. Use YYYY-MM-DD');
    }

    const checkDate = new Date(trimmedDate + 'T00:00:00.000Z'); // Set to midnight UTC

    // Validate that date is valid
    if (isNaN(checkDate.getTime())) {
        throw new Error('Invalid date value');
    }

    return checkDate;
}

/**
 * Gets compliance data for a unit using the priority system:
 * Priority 1: Household data (current household data from active lease)
 * Priority 2: Lease snapshot data (householdAnnualIncomeAtMoveIn, householdSizeAtMoveIn)
 * Priority 3: Current tenant data (backward compatibility)
 * 
 * @param {Object} unit - Unit document (may be lean)
 * @param {Date|null} checkDate - Date to check compliance for (null = current active leases)
 * @param {Object} options - Additional options
 * @param {Object} options.formulaExecutor - Formula executor for bucket calculation
 * @param {Array} options.amiData - AMI data array
 * @returns {Promise<Object>} Compliance data object
 */
async function getComplianceDataForUnit(unit, checkDate, options = {}) {
    const { formulaExecutor, amiData } = options;

    let activeLeases = [];
    
    if (checkDate) {
        // Query leases active on the target date
        const targetDate = new Date(checkDate);
        targetDate.setHours(0, 0, 0, 0);
        const checkDateEnd = new Date(targetDate);
        checkDateEnd.setHours(23, 59, 59, 999);

        console.log(`🔍 Compliance Export: Looking for leases active on ${checkDate} (${targetDate.toISOString()})`);

        activeLeases = await Lease.find({
            unit: unit._id,
            startDate: { $lte: checkDateEnd },
            $or: [
                { endDate: { $gte: targetDate } },
                { endDate: null }
            ]
        })
        .populate({
            path: 'household',
            select: 'currentTotalAnnualIncome householdSize primaryTenant',
            populate: {
                path: 'primaryTenant',
                select: 'firstName lastName _id'
            }
        })
        .sort({ startDate: -1 })
        .limit(1)
        .lean();
    } else {
        // Query currently active leases
        activeLeases = await Lease.find({
            unit: unit._id,
            status: 'Active'
        })
        .populate({
            path: 'household',
            select: 'currentTotalAnnualIncome householdSize primaryTenant',
            populate: {
                path: 'primaryTenant',
                select: 'firstName lastName _id'
            }
        })
        .sort({ startDate: -1 })
        .limit(1)
        .lean();
    }

    // Check if unit is vacant
    const occupancyStatus = (unit.currentOccupancyStatus || '').toLowerCase();
    const hasActiveLease = activeLeases.length > 0;
    const hasCurrentTenant = unit.currentTenant && unit.currentTenantName;
    const isVacant = occupancyStatus.includes('vacant') || 
                    (!hasActiveLease && !hasCurrentTenant);

    if (isVacant && !hasActiveLease) {
        return {
            unitId: unit._id,
            unitNumber: unit.unitNumber,
            tenantId: '',
            tenantName: '',
            householdSize: null,
            monthlyIncome: null,
            tenantIncome: null,
            bucket: 'Vacant',
            amiBucket: 'Vacant',
            leaseStartDate: null,
            leaseEndDate: null
        };
    }

    // Get compliance data using priority system
    let tenantIncome = null;
    let householdSize = null;
    let tenantName = '';
    let tenantId = '';
    let leaseStartDate = null;
    let leaseEndDate = null;

    if (activeLeases.length > 0) {
        const activeLease = activeLeases[0];
        leaseStartDate = activeLease.startDate ? new Date(activeLease.startDate).toISOString().split('T')[0] : null;
        leaseEndDate = activeLease.endDate ? new Date(activeLease.endDate).toISOString().split('T')[0] : null;

        // Priority 1: Query household data first (current household data)
        if (activeLease.household) {
            const household = activeLease.household;
            if (household.currentTotalAnnualIncome !== null && household.currentTotalAnnualIncome !== undefined) {
                tenantIncome = household.currentTotalAnnualIncome;
            }
            if (household.householdSize !== null && household.householdSize !== undefined) {
                householdSize = household.householdSize;
            }
            // Get tenant name from populated primaryTenant
            if (household.primaryTenant) {
                const primaryTenant = household.primaryTenant;
                if (primaryTenant.firstName || primaryTenant.lastName) {
                    tenantName = [primaryTenant.firstName, primaryTenant.lastName].filter(Boolean).join(' ').trim();
                }
                if (primaryTenant._id) {
                    tenantId = primaryTenant._id.toString();
                }
            }
        }

        // Priority 2: If household data is incomplete, use lease compliance data (snapshot at move-in)
        if (tenantIncome === null && activeLease.householdAnnualIncomeAtMoveIn !== null && activeLease.householdAnnualIncomeAtMoveIn !== undefined) {
            tenantIncome = activeLease.householdAnnualIncomeAtMoveIn;
        }
        if (householdSize === null && activeLease.householdSizeAtMoveIn !== null && activeLease.householdSizeAtMoveIn !== undefined) {
            householdSize = activeLease.householdSizeAtMoveIn;
        }
    }

    // Priority 3: Fallback to currentTenant (backward compatibility for units without leases)
    if (tenantIncome === null) {
        const tenant = unit.currentTenant || {};
        if (typeof tenant.currentMonthlyIncome === 'number') {
            tenantIncome = tenant.currentMonthlyIncome * 12;
        } else if (typeof tenant.currentAnnualIncome === 'number') {
            tenantIncome = tenant.currentAnnualIncome;
        }
    }
    if (householdSize === null) {
        const tenant = unit.currentTenant || {};
        householdSize = tenant.householdSize ??
                      tenant.currentHouseholdCount ??
                      unit.currentHouseholdCount ??
                      null;
    }
    if (!tenantName) {
        tenantName = unit.currentTenantName ||
                    [unit.currentTenant?.firstName, unit.currentTenant?.lastName].filter(Boolean).join(' ').trim() ||
                    '';
    }
    if (!tenantId && unit.currentTenant?._id) {
        tenantId = unit.currentTenant._id.toString();
    }

    // Calculate monthly income from annual
    const monthlyIncome = tenantIncome ? Number((tenantIncome / 12).toFixed(2)) : null;

    // Get AMI bucket from lease or calculate it
    let amiBucket = '';
    if (activeLeases.length > 0) {
        amiBucket = activeLeases[0].amiBucketAtMoveIn || '';
    }
    if (!amiBucket) {
        amiBucket = unit.unitAmiQualification?.regulatoryBucket ??
                  unit.currentAmiBucket ??
                  '';
    }
    if (!amiBucket && formulaExecutor && amiData && amiData.length > 0 && tenantIncome) {
        const mockTenant = {
            currentAnnualIncome: tenantIncome,
            currentMonthlyIncome: monthlyIncome,
            householdSize: householdSize,
            currentHouseholdCount: householdSize
        };
        const mockUnit = {
            ...unit,
            currentTenant: mockTenant,
            currentHouseholdCount: householdSize
        };
        const calculatedBucket = buildingHelpers.evaluateRegulatoryBucket(mockUnit, formulaExecutor, amiData);
        if (calculatedBucket) {
            amiBucket = calculatedBucket;
        }
    }

    // Extract percentage from AMI bucket for export
    const bucketPercentage = buildingHelpers.extractBucketPercentage(amiBucket);
    // Keep the full bucket name for the Bucket column
    const bucketName = amiBucket || '';

    return {
        unitId: unit._id,
        unitNumber: unit.unitNumber,
        tenantId: tenantId || '',
        tenantName: tenantName || '',
        householdSize,
        monthlyIncome,
        tenantIncome,
        bucket: bucketName,
        amiBucket: bucketPercentage,
        leaseStartDate,
        leaseEndDate
    };
}

/**
 * Gets building compliance status (basic and bucket compliance)
 * @param {string} buildingId - Building ID
 * @param {Date} checkDate - Date to check compliance for
 * @returns {Promise<Object>} Compliance data object
 */
async function getBuildingComplianceStatus(buildingId, checkDate) {
    const building = await Building.findById(buildingId);
    
    if (!building) {
        throw new Error('Building not found');
    }

    // Get basic regulatory compliance status
    const compliance = building.checkRegulatoryCompliance(checkDate);

    // Get detailed bucket compliance by executing building-level formula
    let bucketCompliance = null;
    let bucketComplianceError = null;
    try {
        if (building.regulatoryAgreement && building.regulatoryAgreement.buildingLevelFormula) {
            bucketCompliance = await building.executeBuildingLevelFormula(checkDate);
        }
    } catch (error) {
        console.error('Error calculating bucket compliance:', error);
        console.error('Error stack:', error.stack);
        bucketComplianceError = error.message;
    }

    const regulatorySummary = building.getRegulatorySummary();

    return {
        compliance,
        bucketCompliance: bucketCompliance ? {
            status: bucketCompliance.hierarchicalDistribution?.summary?.complianceStatus || 'Unknown',
            amiBuckets: bucketCompliance.hierarchicalDistribution?.amiBuckets || [],
            summary: bucketCompliance.hierarchicalDistribution?.summary || {},
            unitResults: bucketCompliance.unitResults || []
        } : null,
        bucketComplianceError: bucketComplianceError,
        regulatorySummary,
        checkDate: checkDate.toISOString().split('T')[0],
        note: checkDate ? 'Compliance checked for specified date. Bucket compliance uses active leases and AMI data for that date.' : null
    };
}

/**
 * Filters units by bucket using hierarchical matching (≤)
 * @param {Array} unitResults - Array of unit result objects
 * @param {number|null} targetPercentage - Target AMI percentage
 * @param {string|null} bucketName - Target bucket name (normalized)
 * @returns {Array} Filtered units
 */
function filterUnitsByBucket(unitResults, targetPercentage, bucketName) {
    const normalizedBucketName = bucketName ? bucketName.toString().trim().toLowerCase() : null;

    return unitResults.filter(unit => {
        if (!unit || !unit.regulatoryBucket) return false;
        if (unit.regulatoryBucket === 'Vacant' || unit.regulatoryBucket === 'Market  0%') return false;

        const unitPercentage = unit.bucketPercentage ?? buildingHelpers.parsePercentageValue(
            unit.regulatoryBucket.split('  ')[1] || null
        );

        if (targetPercentage !== null && unitPercentage !== null) {
            // Use hierarchical matching (≤) to match overview calculation
            // For ≤80% AMI: show units at 30%, 60%, or 80% AMI
            // For ≤60% AMI: show units at 30% or 60% AMI
            // For ≤30% AMI: show units at 30% AMI only
            return unitPercentage <= targetPercentage;
        }

        if (normalizedBucketName) {
            const label = (unit.bucketName || unit.regulatoryBucket || '').toString().toLowerCase();
            return label.includes(normalizedBucketName);
        }

        return false;
    });
}

/**
 * Calculates aggregations for filtered units
 * @param {Array} filteredUnits - Filtered unit results
 * @returns {Object} Aggregation results
 */
function calculateBucketAggregations(filteredUnits) {
    const average = (values = []) => {
        if (!Array.isArray(values) || values.length === 0) return 0;
        const sum = values.reduce((acc, val) => acc + val, 0);
        return sum / values.length;
    };

    const averageIncome = (() => {
        const incomes = filteredUnits
            .map(unit => (typeof unit.tenantIncome === 'number' && !Number.isNaN(unit.tenantIncome)) ? unit.tenantIncome : null)
            .filter(value => value !== null);
        return incomes.length ? Number(average(incomes).toFixed(2)) : 0;
    })();

    const averageRent = (() => {
        const rents = filteredUnits
            .map(unit => (typeof unit.currentRent === 'number' && !Number.isNaN(unit.currentRent)) ? unit.currentRent : null)
            .filter(value => value !== null);
        return rents.length ? Number(average(rents).toFixed(2)) : 0;
    })();

    const delinquencyCount = filteredUnits.filter(unit => (unit.delinquencyAmount || 0) > 0).length;

    const maxAllowedRentValue = (() => {
        const rents = filteredUnits
            .map(unit => (typeof unit.maxAllowedRent === 'number' && !Number.isNaN(unit.maxAllowedRent)) ? unit.maxAllowedRent : null)
            .filter(value => value !== null);
        if (!rents.length) return 0;
        return Number(Math.max(...rents).toFixed(2));
    })();

    const rentGapTotal = Number(filteredUnits.reduce((sum, unit) => {
        if (typeof unit.potentialRentGap === 'number' && !Number.isNaN(unit.potentialRentGap)) {
            return sum + unit.potentialRentGap;
        }
        return sum;
    }, 0).toFixed(2));

    const averageIncomeUtilization = (() => {
        const utilization = filteredUnits
            .map(unit => (typeof unit.incomeUtilizationPercent === 'number' && !Number.isNaN(unit.incomeUtilizationPercent))
                ? unit.incomeUtilizationPercent
                : null)
            .filter(value => value !== null);
        return utilization.length ? Number(average(utilization).toFixed(2)) : null;
    })();

    const riskBreakdown = filteredUnits.reduce((acc, unit) => {
        const status = unit.eligibilityStatus || 'Unknown';
        acc[status] = (acc[status] || 0) + 1;
        return acc;
    }, {});

    return {
        averageIncome,
        averageRent,
        delinquencyCount,
        maxAllowedRent: maxAllowedRentValue,
        leftOnTable: rentGapTotal,
        averageIncomeUtilization,
        riskBreakdown
    };
}

/**
 * Formats compliance data for CSV export
 * @param {Array} filteredUnits - Filtered unit results
 * @returns {string} CSV content
 */
function formatComplianceDataForCSV(filteredUnits) {
    const csvHeaders = [
        'Unit Number',
        'Tenant Name',
        'Bucket',
        'Household Size',
        'Household Income',
        'Income Limit',
        'Income Utilization (%)',
        'Eligibility Status',
        'Current Rent',
        'Max Allowed Rent',
        'Rent Gap',
        'Delinquency Amount',
        'Lease ID'
    ];

    const csvRows = filteredUnits.map(unit => ([
        unit.unitNumber || '',
        unit.tenantName || '',
        unit.regulatoryBucket || '',
        unit.householdCount ?? '',
        unit.tenantIncome ?? '',
        unit.incomeLimit ?? '',
        unit.incomeUtilizationPercent ?? '',
        unit.eligibilityStatus || '',
        unit.currentRent ?? '',
        unit.maxAllowedRent ?? '',
        unit.potentialRentGap ?? '',
        unit.delinquencyAmount ?? '',
        unit.leaseId || ''
    ]));

    const csvContent = [
        csvHeaders.join(','),
        ...csvRows.map(row => row.map(value => {
            if (value === null || value === undefined) return '';
            const stringValue = value.toString().replace(/"/g, '""');
            if (stringValue.includes(',') || stringValue.includes('"') || stringValue.includes('\n')) {
                return `"${stringValue}"`;
            }
            return stringValue;
        }).join(','))
    ].join('\n');

    return csvContent;
}

/**
 * Gets bucket compliance details for a specific bucket
 * @param {string} buildingId - Building ID
 * @param {Object} bucketIdentifier - Bucket identifier { percentage?: number, bucketName?: string }
 * @param {Date|null} checkDate - Date to check compliance for
 * @param {Object} options - Additional options
 * @param {string} options.format - Response format ('json' or 'csv')
 * @returns {Promise<Object>} Bucket compliance details
 */
async function getBucketComplianceDetails(buildingId, bucketIdentifier, checkDate, options = {}) {
    const { format = 'json' } = options;
    const { percentage, bucketName } = bucketIdentifier;

    if (!percentage && !bucketName) {
        throw new Error('Bucket identifier (percentage or bucketName) is required');
    }

    const building = await Building.findById(buildingId);
    if (!building) {
        throw new Error('Building not found');
    }

    const bucketResult = await building.executeBuildingLevelFormula(checkDate);
    if (!bucketResult) {
        throw new Error('Unable to calculate bucket compliance for this building');
    }

    const unitResults = Array.isArray(bucketResult.unitResults) ? bucketResult.unitResults : [];
    const hierarchicalDistribution = bucketResult.hierarchicalDistribution || {};
    const bucketEntries = Array.isArray(hierarchicalDistribution.amiBuckets) ? hierarchicalDistribution.amiBuckets : [];
    const summary = hierarchicalDistribution.summary || {};
    const totalUnits = summary.totalUnits || bucketResult.totalUnits || unitResults.length;

    const normalizedBucketName = bucketName ? bucketName.toString().trim().toLowerCase() : null;
    const requestedPercentage = percentage ? parseFloat(percentage) : null;

    let matchingBucket = null;
    if (requestedPercentage !== null && !Number.isNaN(requestedPercentage)) {
        matchingBucket = bucketEntries.find(entry => {
            const entryPercentage = buildingHelpers.parsePercentageValue(entry?.percentage);
            return entryPercentage !== null && entryPercentage === requestedPercentage;
        });
    }
    if (!matchingBucket && normalizedBucketName) {
        matchingBucket = bucketEntries.find(entry => {
            if (!entry) return false;
            const entryName = entry.name ? entry.name.toString().trim().toLowerCase() : '';
            const entryRawName = entry.rawName ? entry.rawName.toString().trim().toLowerCase() : '';
            return entryName.includes(normalizedBucketName) || entryRawName.includes(normalizedBucketName);
        });
    }

    const targetPercentage = requestedPercentage !== null && !Number.isNaN(requestedPercentage)
        ? requestedPercentage
        : buildingHelpers.parsePercentageValue(matchingBucket?.percentage);

    if (targetPercentage === null && !normalizedBucketName) {
        throw new Error('Unable to determine which bucket to load');
    }

    const filteredUnits = filterUnitsByBucket(unitResults, targetPercentage, normalizedBucketName);

    const aggregations = calculateBucketAggregations(filteredUnits);

    const limitPercentage = buildingHelpers.parsePercentageValue(matchingBucket?.limitInPercentage);
    const unitsRequired = limitPercentage !== null && totalUnits
        ? Math.ceil((totalUnits * limitPercentage) / 100)
        : null;
    const unitsInBucket = filteredUnits.length;
    const unitsDelta = unitsRequired !== null ? unitsInBucket - unitsRequired : null;

    // Get affordability percentage from regulatory agreement (default to 35% if not set)
    const affordabilityPercentage = (building.regulatoryAgreement?.affordabilityPercentage !== null &&
                                    building.regulatoryAgreement?.affordabilityPercentage !== undefined)
        ? building.regulatoryAgreement.affordabilityPercentage
        : 35; // Default to 35% for backward compatibility

    const effectiveBucket = matchingBucket || {
        name: bucketName || (targetPercentage !== null ? `${targetPercentage}% AMI` : 'Income Bucket'),
        percentage: targetPercentage !== null ? `${targetPercentage}%` : null,
        unitsPercentage: null,
        limitInPercentage: limitPercentage !== null ? `${limitPercentage}%` : null,
        complianceStatus: null
    };

    const safeBucketLabel = effectiveBucket.name || 'bucket';

    if (format === 'csv') {
        const csvContent = formatComplianceDataForCSV(filteredUnits);
        return {
            csvContent,
            filename: `${safeBucketLabel.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'bucket'}-details.csv`
        };
    }

    return {
        filters: {
            requestedPercentage: requestedPercentage ?? null,
            bucketPercentage: targetPercentage,
            bucketName: safeBucketLabel,
            date: checkDate ? checkDate.toISOString().split('T')[0] : null
        },
        bucket: {
            ...effectiveBucket,
            parsedPercentage: buildingHelpers.parsePercentageValue(effectiveBucket.percentage),
            parsedLimitPercentage: limitPercentage,
            unitsRequired,
            totalUnits
        },
        summary: {
            unitsInBucket,
            unitsRequired,
            unitsDelta,
            unitsPercentage: effectiveBucket.unitsPercentage || null,
            ...aggregations,
            affordabilityPercentage
        },
        tenants: filteredUnits,
        generatedAt: new Date().toISOString()
    };
}

/**
 * Gets compliance export data for a building
 * @param {string} buildingId - Building ID
 * @param {Date|null} checkDate - Date to check compliance for (null = current active leases)
 * @param {string|null} bucketFilter - Bucket filter ('all', 'vacant', or percentage like '30', '60', '80')
 * @returns {Promise<Array>} Array of compliance unit data
 */
async function getComplianceExportData(buildingId, checkDate, bucketFilter = null) {
    const building = await Building.findById(buildingId);
    if (!building) {
        throw new Error('Building not found');
    }

    const unitFormula = building.regulatoryAgreement?.unitFormula || null;
    let amiData = null;
    if (unitFormula) {
        try {
            amiData = await getAMIDataForBuilding(building);
        } catch (amiError) {
            console.error('Error fetching AMI data for compliance export:', amiError);
        }
    }
    const formulaExecutor = buildingHelpers.buildFormulaExecutor(unitFormula);

    // Fetch all units
    const units = await Unit.find({ building: buildingId })
        .populate({
            path: 'currentTenant',
            select: '_id firstName lastName currentAnnualIncome currentMonthlyIncome householdSize currentHouseholdCount'
        })
        .sort({ unitNumber: 1 })
        .lean();

    // Process units to get compliance data
    const unitPromises = units.map(async (unit) => {
        const complianceData = await getComplianceDataForUnit(unit, checkDate, {
            formulaExecutor,
            amiData
        });

        // For date-based queries, filter out null results (units without active leases)
        if (checkDate && !complianceData.leaseStartDate) {
            return null;
        }

        return complianceData;
    });

    let complianceUnits = await Promise.all(unitPromises);
    
    // Filter out null results for date-based queries
    if (checkDate) {
        complianceUnits = complianceUnits.filter(unit => unit !== null);
        console.log(`✅ Compliance Export: Found ${complianceUnits.length} units with active leases on ${checkDate.toISOString().split('T')[0]} out of ${units.length} total units`);
    }

    // Apply bucket filter if provided
    if (bucketFilter && bucketFilter !== 'all') {
        const selectedBucket = bucketFilter.toString().replace('%', '').toLowerCase();

        // Special handling for "vacant" bucket
        if (selectedBucket === 'vacant') {
            complianceUnits = complianceUnits.filter(unit => {
                const normalizedUnitBucket = (unit.amiBucket || '').toLowerCase().trim();
                return normalizedUnitBucket === 'vacant';
            });
        } else {
            // Filter by percentage (30, 50, 60, 80, etc.) using hierarchical matching
            const selectedBucketNum = parseInt(selectedBucket);
            if (!isNaN(selectedBucketNum)) {
                complianceUnits = complianceUnits.filter(unit => {
                    const unitBucket = (unit.amiBucket || '').trim();
                    if (unitBucket === 'Vacant' || unitBucket === '') return false;
                    // Extract percentage from unit bucket and compare hierarchically
                    const unitPercentage = parseInt(unitBucket.replace('%', '').trim());
                    if (isNaN(unitPercentage)) return false;
                    // For ≤80% AMI: show units at 30%, 60%, or 80% AMI
                    // For ≤60% AMI: show units at 30% or 60% AMI
                    // For ≤30% AMI: show units at 30% AMI only
                    return unitPercentage <= selectedBucketNum;
                });
            }
        }
    }

    return complianceUnits;
}

/**
 * Gets bucket filter data for a building
 * @param {string} buildingId - Building ID
 * @param {string} selectedBucket - Selected bucket ('all' or percentage like '30', '60', '80')
 * @returns {Promise<Array>} Array of filtered compliance unit data
 */
async function getBucketFilterData(buildingId, selectedBucket) {
    const building = await Building.findById(buildingId);
    if (!building) {
        throw new Error('Building not found');
    }

    const unitFormula = building.regulatoryAgreement?.unitFormula || null;
    let amiData = null;
    if (unitFormula) {
        try {
            amiData = await getAMIDataForBuilding(building);
        } catch (amiError) {
            console.error('Error fetching AMI data for compliance export:', amiError);
        }
    }
    const formulaExecutor = buildingHelpers.buildFormulaExecutor(unitFormula);

    // Fetch all units
    const units = await Unit.find({ building: buildingId })
        .populate({
            path: 'currentTenant',
            select: '_id firstName lastName currentAnnualIncome currentMonthlyIncome householdSize currentHouseholdCount'
        })
        .sort({ unitNumber: 1 })
        .lean();

    const complianceUnits = units.map(unit => {
        const tenant = unit.currentTenant || {};
        const tenantName = unit.currentTenantName ||
            [tenant.firstName, tenant.lastName].filter(Boolean).join(' ').trim();

        let monthlyIncome = null;
        if (typeof tenant.currentMonthlyIncome === 'number') {
            monthlyIncome = tenant.currentMonthlyIncome;
        } else if (typeof tenant.currentAnnualIncome === 'number') {
            monthlyIncome = tenant.currentAnnualIncome / 12;
        }

        const householdSize = tenant.householdSize ??
            tenant.currentHouseholdCount ??
            unit.currentHouseholdCount ??
            null;

        let amiBucket = unit.unitAmiQualification?.regulatoryBucket ??
            unit.currentAmiBucket ??
            '';
        if (!amiBucket && formulaExecutor && amiData && amiData.length > 0) {
            const calculatedBucket = buildingHelpers.evaluateRegulatoryBucket(unit, formulaExecutor, amiData);
            if (calculatedBucket) {
                amiBucket = calculatedBucket;
            }
        }

        return {
            unitId: unit._id,
            unitNumber: unit.unitNumber,
            tenantId: tenant._id || '',
            tenantName: tenantName || '',
            householdSize,
            monthlyIncome,
            amiBucket
        };
    });

    let filteredUnits = complianceUnits;

    if (selectedBucket && selectedBucket !== 'all') {
        const selectedBucketNum = parseInt(selectedBucket);
        if (!isNaN(selectedBucketNum)) {
            filteredUnits = complianceUnits.filter(unit => {
                if (!unit.amiBucket) return false;
                // Extract percentage from bucket string (handles formats like "Extremely Low (ELI)  30%" or "Low  80%")
                const normalizedBucket = unit.amiBucket.replace(/\s+/g, ' ').trim();
                // Try to extract percentage from the bucket string
                const percentageMatch = normalizedBucket.match(/(\d+)%/);
                if (!percentageMatch) return false;
                const unitPercentage = parseInt(percentageMatch[1]);
                if (isNaN(unitPercentage)) return false;
                // Use hierarchical matching (≤) to match overview calculation
                return unitPercentage <= selectedBucketNum;
            });
        }
    }

    return filteredUnits;
}

/**
 * Calculates compliance status for a building (used in getBuildingsByDate)
 * @param {Object} building - Building document (may be partial)
 * @param {Date} targetDate - Date to check compliance for
 * @returns {Promise<Object|null>} Bucket compliance status or null
 */
async function calculateBuildingComplianceStatus(building, targetDate) {
    try {
        const fullBuilding = await Building.findById(building._id);
        if (fullBuilding && fullBuilding.regulatoryAgreement && fullBuilding.regulatoryAgreement.buildingLevelFormula) {
            const complianceResult = await fullBuilding.executeBuildingLevelFormula(targetDate);
            return complianceResult?.hierarchicalDistribution?.summary?.complianceStatus || null;
        }
    } catch (error) {
        console.error(`[BUILDINGS] Error calculating compliance for building ${building._id}:`, error);
    }
    return null;
}

/**
 * Gets income-based (bucket) compliance status for a building
 * @param {string} buildingId - Building ID
 * @param {Date} checkDate - Date to check compliance for
 * @returns {Promise<Object>} Income compliance data object
 */
async function getIncomeComplianceStatus(buildingId, checkDate) {
    const building = await Building.findById(buildingId);
    
    if (!building) {
        throw new Error('Building not found');
    }

    if (!building.regulatoryAgreement || !building.regulatoryAgreement.buildingLevelFormula) {
        return {
            incomeCompliance: {
                status: 'Unknown',
                error: 'No regulatory agreement or building-level formula configured',
                amiBuckets: [],
                summary: {},
                unitResults: []
            },
            incomeComplianceError: 'No regulatory agreement or building-level formula configured',
            checkDate: checkDate.toISOString().split('T')[0],
            note: null
        };
    }

    let incomeCompliance = null;
    let incomeComplianceError = null;
    try {
        const formulaResult = await building.executeBuildingLevelFormula(checkDate);
        
        // Extract income/bucket compliance from formula result
        incomeCompliance = {
            status: formulaResult.hierarchicalDistribution?.summary?.complianceStatus || 'Unknown',
            amiBuckets: formulaResult.hierarchicalDistribution?.amiBuckets || [],
            summary: formulaResult.hierarchicalDistribution?.summary || {},
            unitResults: formulaResult.unitResults || []
        };
    } catch (error) {
        console.error('Error calculating income compliance:', error);
        console.error('Error stack:', error.stack);
        incomeComplianceError = error.message;
    }

    return {
        incomeCompliance: incomeCompliance,
        incomeComplianceError: incomeComplianceError,
        checkDate: checkDate.toISOString().split('T')[0],
        note: checkDate ? 'Income compliance checked for specified date. Uses active leases and AMI data for that date.' : null
    };
}

/**
 * Gets rent-based compliance status for a building
 * @param {string} buildingId - Building ID
 * @param {Date} checkDate - Date to check compliance for
 * @returns {Promise<Object>} Rent compliance data object
 */
async function getRentComplianceStatus(buildingId, checkDate) {
    const building = await Building.findById(buildingId);
    
    if (!building) {
        throw new Error('Building not found');
    }

    if (!building.regulatoryAgreement || !building.regulatoryAgreement.buildingLevelFormula) {
        return {
            rentCompliance: {
                status: 'Unknown',
                error: 'No regulatory agreement or building-level formula configured',
                violations: [],
                summary: {}
            },
            rentComplianceError: 'No regulatory agreement or building-level formula configured',
            checkDate: checkDate.toISOString().split('T')[0],
            note: null
        };
    }

    let rentCompliance = null;
    let rentComplianceError = null;
    try {
        // Reuse the results from executeBuildingLevelFormula which already calculates rent compliance
        // This avoids duplicating all the unit processing, AMI data retrieval, and calculations
        const formulaResult = await building.executeBuildingLevelFormula(checkDate);
        
        // Extract rent compliance from the formula result
        // executeBuildingLevelFormula already calculates rentCompliance internally
        rentCompliance = formulaResult.rentCompliance;
        
        if (!rentCompliance) {
            throw new Error('Rent compliance calculation returned no results');
        }
    } catch (error) {
        console.error('Error calculating rent compliance:', error);
        console.error('Error stack:', error.stack);
        rentComplianceError = error.message;
    }

    return {
        rentCompliance: rentCompliance,
        rentComplianceError: rentComplianceError,
        checkDate: checkDate.toISOString().split('T')[0],
        note: checkDate ? 'Rent compliance checked for specified date. Uses active leases and AMI data for that date.' : null
    };
}

module.exports = {
    validateAndParseDate,
    getComplianceDataForUnit,
    getBuildingComplianceStatus,
    getIncomeComplianceStatus,
    getRentComplianceStatus,
    getBucketComplianceDetails,
    getComplianceExportData,
    getBucketFilterData,
    calculateBuildingComplianceStatus,
    filterUnitsByBucket,
    calculateBucketAggregations,
    formatComplianceDataForCSV
};
