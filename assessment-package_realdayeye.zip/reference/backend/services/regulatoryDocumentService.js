const AzureFormRecognizerService = require('./azureFormRecognizerService');
const { callAzureOpenAI } = require('./azureOpenAIService');
const fs = require('fs');

class RegulatoryDocumentService {
    constructor() {
        this.formRecognizer = AzureFormRecognizerService;
    }

    async processRegulatoryDocument(fileBuffer, fileName) {
        try {
            console.log('Starting regulatory document processing...');
            
            // Step 1: Extract text and structure using Azure Document Intelligence
            const analyzeResult = await this.formRecognizer.analyzeDocument(fileBuffer, 'application/pdf');
            
            // Step 2: Extract all text content from the document
            const extractedText = this.extractTextFromAnalyzeResult(analyzeResult);
            
            // Step 3: Generate description using Azure ChatGPT
            const description = await this.generateDescription(extractedText, fileName);
            
            // Step 4: Store the processed data
            const processedData = {
                fileName: fileName,
                extractedText: extractedText,
                description: description,
                analyzeResult: analyzeResult,
                processedAt: new Date()
            };
            
            return processedData;
        } catch (error) {
            console.error('Error processing regulatory document:', error);
            throw error;
        }
    }

    extractTextFromAnalyzeResult(analyzeResult) {
        let extractedText = '';
        
        // Extract text from paragraphs
        if (analyzeResult.paragraphs) {
            analyzeResult.paragraphs.forEach(paragraph => {
                extractedText += paragraph.content + '\n\n';
            });
        }
        
        // Extract text from tables
        if (analyzeResult.tables) {
            analyzeResult.tables.forEach((table, tableIndex) => {
                extractedText += `\n--- Table ${tableIndex + 1} ---\n`;
                
                // Group cells by row
                const rows = {};
                table.cells.forEach(cell => {
                    if (!rows[cell.rowIndex]) {
                        rows[cell.rowIndex] = [];
                    }
                    rows[cell.rowIndex][cell.columnIndex] = cell.content;
                });
                
                // Convert rows to text
                Object.keys(rows).forEach(rowIndex => {
                    const row = rows[rowIndex];
                    const rowText = row.map(cell => cell || '').join(' | ');
                    extractedText += rowText + '\n';
                });
                extractedText += '\n';
            });
        }
        
        return extractedText.trim();
    }

    async generateDescription(extractedText, fileName) {
        try {
            // Get the Unit and Building models for the prompt
            const Unit = require('../models/Unit');
            const Building = require('../models/Building');
            
                         const prompt = `You are an expert at analyzing regulatory agreements and legal documents. 
 
Please analyze the following regulatory agreement document and return a JSON response with the following structure:

{
  "description": "Provide a concise, professional summary of the key regulatory requirements, compliance obligations, and financial terms found in this document. Focus on actionable insights and critical compliance points.",
  "effectiveDate": "YYYY-MM-DD if found in document, otherwise null",
  "expirationDate": "YYYY-MM-DD if found in document, otherwise 2099-12-31",
  "amiAreaRaw": "Extract the EXACT text that mentions the geographic area/county/MSA for AMI calculations (e.g., 'Travis County, TX' or 'Austin-Round Rock MSA'). If not found, return null.",
  "calculationByUnit": "Formula or calculation logic that should be applied at the unit level based on the regulatory requirements",
  "formulaAtBuildingLevel": "Formula or calculation logic that should be applied at the building level based on the regulatory requirements", 
  "parameter": "Additional parameters needed (e.g., AMI table based on household count, income limits, etc.)"
}

**Unit Model Fields Available:**
- unitNumber, unitType, size, sizeUnit, bedrooms, bathrooms
- currentRentAmount, currentMarketRent, currentOccupancyStatus
- currentHouseholdCount, currentTotalDelinquent, currentNetBalance
- leaseId, reshId, tenantName, moveInDate, moveOutDate
- occupancySnapshots[], delinquencyHistory[]

**Building Model Fields Available:**
- name, address, city, state, country, zipCode
- buildingType, totalUnits, totalSquareFootage, yearBuilt, floors
- currentPurchasePrice, currentValue, currentCapRate, currentNoi
- currentOccupancyRate, buildingSnapshots[]

**Analysis Requirements:**
1. **Document Type**: What type of regulatory agreement is this?
2. **Key Parties**: Who are the main parties involved?
3. **Effective Period**: What are the effective dates and duration?
4. **Geographic Area**: What is the specific county, city, or MSA mentioned for AMI calculations? Extract the EXACT text.
5. **Key Requirements**: What are the main regulatory requirements or obligations?
6. **Compliance Status**: What is the current compliance status?
7. **Financial Terms**: Any important financial terms, rates, or payment requirements
8. **Calculation Requirements**: What calculations need to be performed at unit and building levels?
9. **Additional Parameters**: What additional data or parameters are needed?

**Important Notes:**
- Return ONLY valid JSON, no additional text
- For amiAreaRaw, extract the EXACT text mentioning the geographic area (county, MSA, or city)
- For calculations, provide clear formulas or logic
- For parameters, specify what additional data is needed and why
- If no effective date is found, use null
- Focus on actionable compliance requirements and calculations

Document Name: ${fileName}
Document Content:
${extractedText.substring(0, 6000)}${extractedText.length > 6000 ? '...' : ''}`;

                         const systemMessage = 'You are an expert legal document analyst specializing in regulatory agreements and compliance. Return ONLY valid JSON with the specified structure. For the description field, provide a concise, professional summary of the actual regulatory requirements, compliance obligations, and financial terms found in the document. Focus on actionable insights and critical compliance points that would be relevant for property management.';

            const response = await callAzureOpenAI(prompt, 1000, 0.3, systemMessage);
            
            // Try to parse the response as JSON
            try {
                const parsedResponse = JSON.parse(response.trim());
                return parsedResponse;
            } catch (parseError) {
                console.error('Error parsing JSON response:', parseError);
                console.log('Raw response:', response);
                                 // Return a fallback structure if JSON parsing fails
                    return {
                    description: response,
                    effectiveDate: null,
                    expirationDate: "2099-12-31",
                    amiAreaRaw: null,
                    calculationByUnit: "Unable to parse calculation requirements",
                    formulaAtBuildingLevel: "Unable to parse building-level requirements", 
                    parameter: "Unable to parse additional parameters"
                };
            }
        } catch (error) {
            console.error('Error generating description:', error);
                         return {
                 description: 'Unable to generate description due to processing error.',
                 effectiveDate: null,
                 expirationDate: "2099-12-31",
                 amiAreaRaw: null,
                 calculationByUnit: "Error in processing",
                 formulaAtBuildingLevel: "Error in processing",
                 parameter: "Error in processing"
             };
        }
    }
}

module.exports = new RegulatoryDocumentService(); 