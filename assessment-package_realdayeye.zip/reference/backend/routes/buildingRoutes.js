const express = require('express');
const router = express.Router();
const buildingController = require('../controllers/buildingController');
const pmsController = require('../controllers/pmsController');
const { authenticateToken } = require('../middleware/authMiddleware');
const { checkBuildingAccess, getAccessibleBuildingFilter, checkGroupMembershipForCreate } = require('../middleware/groupAccessMiddleware');
const multer = require('multer');

// Configure multer for file uploads - use memory storage to upload directly to blob storage
const upload = multer({ 
    storage: multer.memoryStorage(),
    limits: {
        fileSize: 100 * 1024 * 1024 // 100MB limit per file
    }
});

// Apply auth middleware to all routes
router.use(authenticateToken);

// Process regulatory document with Azure Document Intelligence
// POST /api/buildings/process-regulatory-document
router.post('/process-regulatory-document', 
    (req, res, next) => {
        console.log('Multer middleware processing...');
        upload.single('regulatoryDocument')(req, res, (err) => {
            if (err) {
                console.error('Multer error:', err);
                return res.status(400).json({
                    success: false,
                    message: 'File upload error: ' + err.message
                });
            }
            console.log('Multer processing complete');
            console.log('Files after multer:', req.files);
            console.log('File after multer:', req.file);
            next();
        });
    },
    buildingController.processRegulatoryDocument
);

// Get all buildings with metrics for a specific date
// GET /api/buildings?date=2024-01-31
// Note: Filtering by group is handled in the controller
router.get('/', buildingController.getBuildingsByDate);

// Get single building with metrics for a specific date
// GET /api/buildings/:buildingId?date=2024-01-31
router.get('/:buildingId', checkBuildingAccess, buildingController.getBuildingByDate);

// Create a new building
// POST /api/buildings
router.post('/', checkGroupMembershipForCreate, 
    upload.single('regulatoryDocument'),
    buildingController.createBuilding
);

// Update a building
// PUT /api/buildings/:buildingId
router.put('/:buildingId', 
    checkBuildingAccess,
    upload.single('regulatoryDocument'),
    buildingController.updateBuilding
);

// Delete a building
// DELETE /api/buildings/:buildingId
router.delete('/:buildingId', checkBuildingAccess, buildingController.deleteBuilding);

// Analyze building characteristics from URL
// POST /api/buildings/analyze-url
router.post('/analyze-url', buildingController.analyzeBuildingCharacteristicsFromUrl);

// Get building creation progress
// GET /api/buildings/:id/creation-progress
router.get('/:id/creation-progress', buildingController.getBuildingCreationProgress);

// Get fee extraction status and extracted fees
// GET /api/buildings/:id/fee-extraction-status
router.get('/:id/fee-extraction-status', checkBuildingAccess, buildingController.getFeeExtractionStatus);

// Extract building information from URL for building edit page
// POST /api/buildings/extract-from-url
// POST /api/buildings/:buildingId/extract-from-url (with buildingId for AMI linking)
router.post('/extract-from-url', buildingController.extractBuildingInfoFromUrl);
router.post('/:buildingId/extract-from-url', buildingController.extractBuildingInfoFromUrl);

// Geocode address and get location details
// POST /api/buildings/geocode-address
router.post('/geocode-address', buildingController.geocodeAddress);

// Search for address suggestions (from existing buildings or AMI locations)
// GET /api/buildings/address-suggestions?q=search
router.get('/address-suggestions', buildingController.getAddressSuggestions);

// Extract tenant and unit data from lease agreement PDF
// POST /api/buildings/extract-lease-agreement
router.post('/extract-lease-agreement', 
    upload.single('leaseAgreementPdf'),
    buildingController.extractLeaseAgreementData
);

// Extract multiple lease agreements in a single request
// POST /api/buildings/extract-lease-agreements
router.post('/extract-lease-agreements',
    (req, res, next) => {
        upload.array('leaseAgreementPdfs', 50)(req, res, (err) => {
            if (err) {
                console.error('Multer error in extract-lease-agreements:', err);
                if (err.code === 'LIMIT_FILE_COUNT') {
                    return res.status(400).json({
                        success: false,
                        message: `Too many files. Maximum 50 files allowed.`
                    });
                }
                if (err.code === 'LIMIT_FILE_SIZE') {
                    return res.status(400).json({
                        success: false,
                        message: `File too large. Maximum 100MB per file.`
                    });
                }
                return res.status(400).json({
                    success: false,
                    message: 'File upload error: ' + err.message
                });
            }
            next();
        });
    },
    buildingController.extractMultipleLeaseAgreements
);

// Extract lease agreements from a folder path
// POST /api/buildings/extract-lease-agreements-from-folder
router.post('/extract-lease-agreements-from-folder',
    buildingController.extractLeaseAgreementsFromFolder
);

// Extract lease agreements from uploaded ZIP file
// POST /api/buildings/extract-lease-agreements-from-zip
router.post('/extract-lease-agreements-from-zip',
    upload.single('zipFile'),
    buildingController.extractLeaseAgreementsFromZip
);

// Classify and cut PDFs from ZIP file
// POST /api/buildings/classify-and-cut-zip
router.post('/classify-and-cut-zip',
    upload.single('zipFile'),
    buildingController.classifyAndCutZip
);

// Extract lease agreements from uploaded archive file (ZIP, RAR, 7Z, TAR, etc.)
// POST /api/buildings/extract-lease-agreements-from-archive
router.post('/extract-lease-agreements-from-archive',
    upload.single('archiveFile'),
    buildingController.extractLeaseAgreementsFromArchive
);

// Get supported document types for URL analysis
// GET /api/buildings/supported-document-types
router.get('/supported-document-types', buildingController.getSupportedDocumentTypes);

// Classify and cut PDF by document types
// POST /api/buildings/classify-and-cut-pdf
router.post('/classify-and-cut-pdf',
    upload.single('pdfFile'),
    buildingController.classifyAndCutPdf
);

// Delete regulatory agreement from a building
// DELETE /api/buildings/:buildingId/regulatory-agreement
router.delete('/:buildingId/regulatory-agreement', buildingController.deleteRegulatoryAgreement);

// Get income-based compliance status (must come before general /compliance route)
// GET /api/buildings/:buildingId/compliance/income
router.get('/:buildingId/compliance/income', checkBuildingAccess, buildingController.getIncomeCompliance);
// Get rent-based compliance status (must come before general /compliance route)
// GET /api/buildings/:buildingId/compliance/rent
router.get('/:buildingId/compliance/rent', checkBuildingAccess, buildingController.getRentCompliance);
// Get building compliance status
// GET /api/buildings/:buildingId/compliance
router.get('/:buildingId/compliance', buildingController.getBuildingCompliance);
router.get('/:buildingId/bucket-compliance-details', checkBuildingAccess, buildingController.getBucketComplianceDetails);

// Process unit formula with ChatGPT
// POST /api/buildings/:buildingId/process-unit-formula
router.post('/:buildingId/process-unit-formula', buildingController.processUnitFormula);

// Get stored unit formula for a building
// GET /api/buildings/:buildingId/unit-formula
router.get('/:buildingId/unit-formula', buildingController.getUnitFormula);

// Get bucket limits JSON for a building
// GET /api/buildings/:buildingId/bucket-limits
router.get('/:buildingId/bucket-limits', buildingController.getBucketLimitsJson);

// Get all documents for a building (building, units, tenants)
// GET /api/buildings/:buildingId/all-documents
router.get('/:buildingId/all-documents', buildingController.getAllBuildingDocuments);

// Download a document
// GET /api/buildings/:buildingId/documents/:documentId/download
router.get('/:buildingId/documents/:documentId/download', buildingController.downloadBuildingDocument);

// Get AMI data for a building
// GET /api/buildings/:buildingId/ami
router.get('/:buildingId/ami', buildingController.getBuildingAMIData);

// Assign AMI data from regulatory document to building
// POST /api/buildings/:buildingId/ami-data/assign-from-regulatory
router.post('/:buildingId/ami-data/assign-from-regulatory', 
    checkBuildingAccess, 
    buildingController.assignAMIDataFromRegulatory
);

// Execute unit formula for a specific unit
// GET /api/buildings/:buildingId/units/:unitId/execute-formula
router.get('/:buildingId/units/:unitId/execute-formula', buildingController.executeUnitFormula);

// Execute unit formula for all units in a building
// GET /api/buildings/:buildingId/execute-formula-all-units
router.get('/:buildingId/execute-formula-all-units', buildingController.executeUnitFormulaForAllUnits);

// Get units for a building
// GET /api/buildings/:buildingId/units
router.get('/:buildingId/units', buildingController.getBuildingUnits);

// Create a new unit for a building
// POST /api/buildings/:buildingId/units
router.post('/:buildingId/units', checkBuildingAccess, buildingController.createUnit);

// Update a unit (e.g., lease dates)
// PUT /api/buildings/:buildingId/units/:unitId
router.put('/:buildingId/units/:unitId', checkBuildingAccess, buildingController.updateUnit);

// Get rent roll data for a building
// GET /api/buildings/:buildingId/rent-roll
router.get('/:buildingId/rent-roll', buildingController.getRentRollData);

// Compare building fees with leases
// GET /api/buildings/:buildingId/compare-fees-with-leases?date=2024-01-15
router.get('/:buildingId/compare-fees-with-leases', buildingController.compareBuildingFeesWithLeases);
// PATCH /api/buildings/:buildingId/leases/:leaseId/recurring-charges/:chargeId
router.patch('/:buildingId/leases/:leaseId/recurring-charges/:chargeId', 
    buildingController.updateLeaseRecurringCharge
);

// Compare lease with rent roll from ZIP
// POST /api/buildings/:buildingId/compare-lease-with-rentroll
router.post('/:buildingId/compare-lease-with-rentroll',
    upload.single('zipFile'),
    buildingController.compareLeaseWithRentRoll
);

router.post(
    '/:buildingId/leases/:leaseId/charges/:chargeIndex/confirm-fee-mapping',
    buildingController.confirmLeaseFeeMapping
);

// Compare extracted fees (from ZIP) with building fees
// POST /api/buildings/:buildingId/compare-extracted-fees
router.post('/:buildingId/compare-extracted-fees', buildingController.compareExtractedFeesWithBuilding);


router.get('/:buildingId/compliance-export', buildingController.getDataForComplianceExport);
router.get('/:buildingId/bucket-filter', buildingController.getBucketFilterData);
router.get('/:buildingId/compare-unit-fees', buildingController.compareUnitFees);
router.patch('/:buildingId/units/:unitId/fees/:feeId', buildingController.editRentRollFee);
router.patch('/:buildingId/units/:unitId/transactions/:transactionId', buildingController.updateUnitFee);

// Create building snapshot for a specific date
// POST /api/buildings/:buildingId/snapshot
router.post('/:buildingId/snapshot', buildingController.createBuildingSnapshot);

// Resolve unit type conflicts route
router.post('/:buildingId/resolve-unit-type-conflicts', checkBuildingAccess, buildingController.resolveUnitTypeConflicts);

// Resolve all unit type mismatches at once (DEPRECATED - use separate endpoints)
router.post('/:buildingId/resolve-all-mismatches', checkBuildingAccess, buildingController.resolveAllUnitTypeMismatches);

// Resolve only square footage mismatches
router.post('/:buildingId/resolve-square-footage-mismatches', checkBuildingAccess, buildingController.resolveSquareFootageMismatches);

// Resolve only floorplan mismatches
router.post('/:buildingId/resolve-floorplan-mismatches', checkBuildingAccess, buildingController.resolveFloorplanMismatches);

// Bulk upload route
router.post('/:buildingId/bulk-upload', 
    upload.fields([
        { name: 'characteristics', maxCount: 1 },
        { name: 'rentRoll', maxCount: 1 },
        { name: 'delinquency', maxCount: 1 }
    ]), 
    buildingController.bulkUploadBuildingData
);

// Dual file upload route (Rent Roll + Tenant Income)
router.post('/:buildingId/dual-upload', 
    upload.fields([
        { name: 'rentRoll', maxCount: 1 },
        { name: 'tenantIncome', maxCount: 1 }
    ]), 
    buildingController.dualUploadBuildingData
);

// Tenant Income Only Upload route (matches to existing tenants from Step 4)
router.post('/:buildingId/tenant-income-upload', 
    upload.fields([
        { name: 'tenantIncome', maxCount: 1 }
    ]), 
    buildingController.tenantIncomeOnlyUpload
);

// Validate and compare tenant income Excel file with database
// POST /api/buildings/:buildingId/validate-tenant-income
router.post('/:buildingId/validate-tenant-income',
    checkBuildingAccess,
    upload.fields([
        { name: 'tenantIncome', maxCount: 1 }
    ]),
    buildingController.validateTenantIncomeFile
);

// Building-level formula routes
// Process building-level formula with ChatGPT
// POST /api/buildings/:buildingId/process-building-level-formula
router.post('/:buildingId/process-building-level-formula', buildingController.processBuildingLevelFormula);

// Execute building-level formula for a building
// POST /api/buildings/:buildingId/execute-building-level-formula
router.post('/:buildingId/execute-building-level-formula', buildingController.executeBuildingLevelFormula);

// Get stored building-level formula for a building
// GET /api/buildings/:buildingId/building-level-formula
router.get('/:buildingId/building-level-formula', buildingController.getBuildingLevelFormula);

// Floorplan management routes
// Create a new floorplan for a building
// POST /api/buildings/:buildingId/floorplans
router.post('/:buildingId/floorplans', checkBuildingAccess, buildingController.createFloorplan);

// Get all floorplans for a building
// GET /api/buildings/:buildingId/floorplans
router.get('/:buildingId/floorplans', checkBuildingAccess, buildingController.getFloorplans);

// Get a specific floorplan by ID
// GET /api/buildings/:buildingId/floorplans/:floorplanId
router.get('/:buildingId/floorplans/:floorplanId', checkBuildingAccess, buildingController.getFloorplan);

// Update a floorplan
// PUT /api/buildings/:buildingId/floorplans/:floorplanId
router.put('/:buildingId/floorplans/:floorplanId', checkBuildingAccess, buildingController.updateFloorplan);

// Delete a floorplan
// DELETE /api/buildings/:buildingId/floorplans/:floorplanId?force=true
router.delete('/:buildingId/floorplans/:floorplanId', checkBuildingAccess, buildingController.deleteFloorplan);

// Create units from a floorplan
// POST /api/buildings/:buildingId/floorplans/:floorplanId/create-units
router.post('/:buildingId/floorplans/:floorplanId/create-units', checkBuildingAccess, buildingController.createUnitsFromFloorplan);

// Building PMS Sync routes
// GET /api/buildings/:buildingId/pms-sync/status
router.get('/:buildingId/pms-sync/status', checkBuildingAccess, pmsController.getBuildingPMSSyncStatus);

// POST /api/buildings/:buildingId/pms-sync/trigger
router.post('/:buildingId/pms-sync/trigger', checkBuildingAccess, pmsController.triggerBuildingPMSSync);

// GET /api/buildings/:buildingId/pms-sync/history
router.get('/:buildingId/pms-sync/history', checkBuildingAccess, pmsController.getBuildingPMSSyncHistory);

// GET /api/buildings/:buildingId/pms-sync/history/:syncId
router.get('/:buildingId/pms-sync/history/:syncId', checkBuildingAccess, pmsController.getBuildingPMSSyncDetails);

module.exports = router; 