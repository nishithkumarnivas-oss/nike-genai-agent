const mongoose = require('mongoose');
const { 
    calculateUnitRegulatoryBucket, 
    calculateBuildingLevelCompliance, 
    calculateLimits,
    calculateRentLimit,
    calculateRentCompliance,
    calculateOverallCompliance
} = require('../utils/regulatoryCalculations');

// Building snapshot schema for historical tracking
const buildingSnapshotSchema = new mongoose.Schema({
    snapshotDate: { type: Date, required: true },
    totalUnits: { type: Number, required: true },
    occupiedUnits: { type: Number, required: true },
    vacantUnits: { type: Number, required: true },
    delinquentUnits: { type: Number, required: true },
    totalRentalIncome: { type: Number, required: true },
    totalDelinquencyAmount: { type: Number, required: true },
    occupancyRate: { type: Number, required: true },
    averageRentPerUnit: { type: Number, required: true },
    totalHouseholds: { type: Number, required: true },
    
    // Rent roll metrics
    totalMarketRent: { type: Number, required: true },
    totalAdditionalCharges: { type: Number, required: true },
    totalMonthlyBilling: { type: Number, required: true },
    totalDepositsOnHand: { type: Number, required: true },
    totalOutstandingBalance: { type: Number, required: true },
    averageMarketRentPerUnit: { type: Number, required: true },
    
    notes: { type: String },
    createdAt: { type: Date, default: Date.now }
});

// Floorplan schema - embedded in Building
const floorplanSchema = new mongoose.Schema({
    name: { 
        type: String, 
        required: true,
        trim: true
    }, // e.g., "1BR", "2BR", "Studio", "A1", "20207A4"
    description: { 
        type: String 
    }, // Optional description
    
    // Unit characteristics
    bedrooms: { 
        type: Number, 
        required: true,
        min: 0
    },
    bathrooms: { 
        type: Number, 
        required: true,
        min: 0.5 // Allow half baths
    },
    averageSquareFootage: { 
        type: Number, 
        required: true,
        min: 0
    }, // Average size for this floorplan type
    squareFootageRange: {
        min: { type: Number },
        max: { type: Number }
    }, // Optional: min/max size range
    
    // Additional characteristics
    parkingSpaces: { 
        type: Number, 
        default: 0,
        min: 0
    },
    balcony: { 
        type: Boolean, 
        default: false 
    },
    furnished: { 
        type: Boolean, 
        default: false 
    },
    
    // Number of units with this floorplan
    numberOfUnits: { 
        type: Number, 
        required: true,
        min: 0 // Allow 0 units
    },
    
    // Optional: Regulatory/compliance characteristics
    typicalRentRange: {
        min: { type: Number },
        max: { type: Number }
    },
    typicalAMILevel: { 
        type: String 
    }, // e.g., "30%", "50%", "60%", "80%"
    
    // Metadata
    createdAt: { 
        type: Date, 
        default: Date.now 
    },
    updatedAt: { 
        type: Date, 
        default: Date.now 
    }
}, { _id: true }); // Include _id for referencing from Unit

const buildingSchema = new mongoose.Schema({
    name: { type: String, required: true },
    address: { type: String, required: true },
    city: { type: String, required: true },
    state: { type: String, required: true },
    county: { type: String },
    country: { type: String, required: true },
    zipCode: { type: String },
    latitude: { type: Number },
    longitude: { type: Number },
    
    // Building characteristics
    buildingType: {
        type: String,
        enum: ['Residential', 'Commercial', 'Industrial', 'Mixed Use'],
        required: true
    },
    totalUnits: { type: Number, required: true },
    totalSquareFootage: { type: Number, required: true },
    yearBuilt: { type: Number },
    floors: { type: Number },
    
    // Current financial metrics (latest snapshot)
    currentPurchasePrice: { type: Number },
    currentValue: { type: Number },
    currentCapRate: { type: Number },
    currentNoi: { type: Number },
    currentOccupancyRate: { type: Number },
    currentTotalRentalIncome: { type: Number },
    currentTotalDelinquencyAmount: { type: Number },
    currentAverageRentPerUnit: { type: Number },
    currentTotalHouseholds: { type: Number },
    
    // Current rent roll metrics
    currentTotalMarketRent: { type: Number },
    currentTotalAdditionalCharges: { type: Number },
    currentTotalMonthlyBilling: { type: Number },
    currentTotalDepositsOnHand: { type: Number },
    currentTotalOutstandingBalance: { type: Number },
    currentAverageMarketRentPerUnit: { type: Number },
    
    // Related deals
    deals: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Deal'
    }],
    
    // Building amenities
    amenities: [String],
    
    // Building logo (base64 encoded image)
    logo: { 
        type: String 
    }, // Base64 encoded image data (data:image/png;base64,...)
    
    // Floorplans - array of floorplan definitions
    floorplans: [floorplanSchema],
    
    // Regulatory Agreement
    regulatoryAgreement: {
        description: { type: String },
        document: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Document'
        },
        effectiveDate: { type: Date },
        expirationDate: { type: Date },
        status: {
            type: String,
            enum: ['Active', 'Expired', 'Terminated', 'Under Review'],
            default: 'Active'
        },
        complianceNotes: { type: String },
        lastReviewDate: { type: Date },
        nextReviewDate: { type: Date },
        // Formula fields for regulatory compliance
        calculationByUnit: { type: String },
        formulaAtBuildingLevel: { type: String },
        parameter: { type: String },
        // Unit formula fields generated by ChatGPT
        unitFormula: { type: String }, // JavaScript function code
        unitFormulaGeneratedAt: { type: Date },
        unitFormulaDescription: { type: String }, // Original description sent to ChatGPT
        
        // Building-level formula fields
        buildingLevelFormula: { type: String }, // JavaScript function code for building-level calculations
        buildingLevelFormulaGeneratedAt: { type: Date },
        buildingLevelFormulaDescription: { type: String }, // Original description for building-level calculations
        
        // Limits formula fields - calculates regulatory limits by AMI level
        limitsFormula: { type: String }, // JavaScript function code for calculating limits by AMI level
        limitsFormulaGeneratedAt: { type: Date },
        limitsFormulaDescription: { type: String }, // Original description for limits calculation
        
        // Bucket limits JSON structure - static limits configuration per AMI bucket
        bucketLimitsJson: { type: mongoose.Schema.Types.Mixed }, // JSON structure with bucket limits configuration
        bucketLimitsJsonGeneratedAt: { type: Date },
        
        // Affordability percentage - maximum rent as percentage of annual income limit (e.g., 30 = 30%, 35 = 35%)
        affordabilityPercentage: {
            type: Number,
            default: 35,
            min: 0,
            max: 100
        }
    },
    
    // AMI Data references
    amiData: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'AMI'
    }],
    
    // AMI Data Reference (new system)
    amiDataReference: {
        fips: String,
        fiscalYear: String,
        version: String,
        lastUpdated: Date,
        source: {
            type: String,
            enum: ['auto', 'manual', 'current', 'regulatory_agreement'],
            default: 'auto'
        },
        countyName: String,
        stateName: String,
        hudAreaName: String
    },

    metadata: {
        type: mongoose.Schema.Types.Mixed, // Flexible object to store any metadata
        default: {}
    },
    
    // Historical snapshots
    buildingSnapshots: [buildingSnapshotSchema],
    
    // Documents
    documents: [{
        name: { type: String, required: true },
        type: { type: String, required: true },
        url: { type: String, required: true },
        uploadDate: { type: Date, default: Date.now },
        uploadedBy: { type: String, required: true }
    }],
    
    // Group ownership - Buildings belong to groups
    group: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Group',
        required: true,
        index: true
    },
    
    // Created by user
    createdBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    
    // Creation status and progress tracking (for background URL analysis)
    creationStatus: {
        type: String,
        enum: ['draft', 'creating', 'analyzing', 'completed', 'failed'],
        default: 'draft'
    },
    creationProgress: {
        currentStep: { type: String },
        progressPercent: { type: Number, default: 0, min: 0, max: 100 },
        steps: [{
            step: { type: String, required: true },
            status: { 
                type: String, 
                enum: ['pending', 'in_progress', 'completed', 'failed'],
                default: 'pending'
            },
            message: { type: String },
            completedAt: { type: Date }
        }],
        startedAt: { type: Date },
        completedAt: { type: Date },
        error: { type: String }
    },
    
    // Fee extraction status and progress tracking (for background fee extraction)
    feeExtractionStatus: {
        type: String,
        enum: ['not_started', 'extracting', 'completed', 'failed'],
        default: 'not_started'
    },
    feeExtractionProgress: {
        startedAt: { type: Date },
        completedAt: { type: Date },
        error: { type: String },
        extractedFromUrl: { type: String }
    },
    
    // Wizard progress tracking (for building creation/edit wizard)
    wizardProgress: {
        currentStep: {
            type: Number,
            min: 1,
            max: 8,
            default: 1
        },
        isWizardComplete: {
            type: Boolean,
            default: false
        },
        completedSteps: [{
            step: { type: Number, required: true },
            completedAt: { type: Date, default: Date.now }
        }],
        lastUpdated: { type: Date, default: Date.now }
    },
    
    // PMS Integration - property management system integration settings
    pmsIntegration: {
        pmsId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'PMS',
            default: null
        },
        isManual: {
            type: Boolean,
            default: true  // If true, building is managed manually (no PMS sync)
        },
        buildingIdentifier: {
            type: String,
            default: null  // Identifier used to query this building in the PMS system
            // Validation: Any non-empty string (no format restrictions)
        },
        syncSettings: {
            syncRentRolls: {
                type: Boolean,
                default: false
            },
            syncLeaseDocuments: {
                type: Boolean,
                default: false
            },
            syncSchedule: {
                type: String,
                enum: ['daily', 'weekly', 'biweekly', 'monthly', 'quarterly', 'semiannually', 'yearly'],
                default: 'monthly'
            },
            lastSyncAt: {
                type: Date
            }, // Timestamp of last successful sync
            nextSyncAt: {
                type: Date
            }, // Calculated next sync time (calculated when sync is enabled)
            isSyncEnabled: {
                type: Boolean,
                default: false  // Master switch to enable/disable sync
            }
        },
        syncHistory: [{
            syncType: {
                type: String,
                enum: ['rentroll', 'lease_documents', 'full'],
                required: true
            },
            status: {
                type: String,
                enum: ['success', 'failed', 'partial'],
                required: true
            },
            startedAt: {
                type: Date
            },
            completedAt: {
                type: Date
            },
            recordsProcessed: {
                type: Number
            },
            recordsFailed: {
                type: Number
            },
            errorMessage: {
                type: String
            },
            errorDetails: {
                type: mongoose.Schema.Types.Mixed
            } // Detailed error info
        }]
    },
    
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

// Indexes for better query performance
buildingSchema.index({ name: 1 });
buildingSchema.index({ city: 1 });
buildingSchema.index({ state: 1 });
buildingSchema.index({ buildingType: 1 });
buildingSchema.index({ 'regulatoryAgreement.document': 1 });
buildingSchema.index({ 'regulatoryAgreement.status': 1 });
buildingSchema.index({ 'buildingSnapshots.snapshotDate': 1 });
buildingSchema.index({ group: 1 }); // Index for group-based queries
buildingSchema.index({ createdBy: 1 }); // Index for creator queries

// Method to get building snapshot for a specific date
buildingSchema.methods.getBuildingSnapshot = function(date) {
    if (!this.buildingSnapshots || this.buildingSnapshots.length === 0) {
        return null;
    }
    
    const snapshots = this.buildingSnapshots
        .filter(snapshot => snapshot.snapshotDate <= date)
        .sort((a, b) => b.snapshotDate - a.snapshotDate);
    
    return snapshots.length > 0 ? snapshots[0] : null;
};

// Method to calculate current metrics from units
buildingSchema.methods.calculateCurrentMetrics = async function() {
    const Unit = mongoose.model('Unit');
    const units = await Unit.find({ building: this._id });
    
    const currentMetrics = {
        totalUnits: units.length,
        occupiedUnits: units.filter(u => u.currentOccupancyStatus === 'Occupied').length,
        vacantUnits: units.filter(u => u.currentOccupancyStatus === 'Vacant').length,
        delinquentUnits: units.filter(u => u.currentOccupancyStatus === 'Delinquent').length,
        totalRentalIncome: units.reduce((sum, u) => sum + (u.currentRentAmount || 0), 0),
        totalDelinquencyAmount: units.reduce((sum, u) => sum + (u.currentTotalDelinquent || 0), 0),
        totalHouseholds: units.reduce((sum, u) => sum + (u.currentHouseholdCount || 0), 0),
        
        // Rent roll metrics
        totalMarketRent: units.reduce((sum, u) => sum + (u.currentMarketRent || 0), 0),
        totalAdditionalCharges: units.reduce((sum, u) => sum + (u.currentAdditionalCharges || 0), 0),
        totalMonthlyBilling: units.reduce((sum, u) => sum + (u.currentTotalMonthlyBilling || 0), 0),
        totalDepositsOnHand: units.reduce((sum, u) => sum + (u.currentDepositOnHand || 0), 0),
        totalOutstandingBalance: units.reduce((sum, u) => sum + (u.currentOutstandingBalance || 0), 0)
    };
    
    currentMetrics.occupancyRate = currentMetrics.totalUnits > 0 ? 
        (currentMetrics.occupiedUnits / currentMetrics.totalUnits) * 100 : 0;
    currentMetrics.averageRentPerUnit = currentMetrics.occupiedUnits > 0 ? 
        currentMetrics.totalRentalIncome / currentMetrics.occupiedUnits : 0;
    currentMetrics.averageMarketRentPerUnit = currentMetrics.occupiedUnits > 0 ? 
        currentMetrics.totalMarketRent / currentMetrics.occupiedUnits : 0;
    
    return currentMetrics;
};

// Method to create a snapshot for a specific date
buildingSchema.methods.createSnapshot = async function(date) {
    const Unit = mongoose.model('Unit');
    const units = await Unit.find({ building: this._id });
    
    const snapshot = {
        snapshotDate: date,
        totalUnits: units.length,
        occupiedUnits: 0,
        vacantUnits: 0,
        delinquentUnits: 0,
        totalRentalIncome: 0,
        totalDelinquencyAmount: 0,
        totalHouseholds: 0
    };
    
    for (const unit of units) {
        const unitSnapshot = unit.getOccupancySnapshot(date);
        if (unitSnapshot) {
            if (unitSnapshot.occupancyStatus === 'Occupied') {
                snapshot.occupiedUnits++;
                snapshot.totalRentalIncome += unitSnapshot.rentAmount || 0;
                snapshot.totalHouseholds += unitSnapshot.householdCount || 0;
            } else if (unitSnapshot.occupancyStatus === 'Vacant') {
                snapshot.vacantUnits++;
            } else if (unitSnapshot.occupancyStatus === 'Delinquent') {
                snapshot.delinquentUnits++;
                snapshot.totalDelinquencyAmount += unitSnapshot.delinquencyAmount || 0;
            }
        }
    }
    
    snapshot.occupancyRate = snapshot.totalUnits > 0 ? 
        (snapshot.occupiedUnits / snapshot.totalUnits) * 100 : 0;
    snapshot.averageRentPerUnit = snapshot.occupiedUnits > 0 ? 
        snapshot.totalRentalIncome / snapshot.occupiedUnits : 0;
    
    this.buildingSnapshots.push(snapshot);
    return snapshot;
};

// Method to check regulatory compliance
// @param {Date} date - Optional date to check compliance for (defaults to current date)
buildingSchema.methods.checkRegulatoryCompliance = function(date = new Date()) {
    if (!this.regulatoryAgreement) {
        return {
            compliant: false,
            reason: 'No regulatory agreement found',
            status: 'Non-Compliant'
        };
    }
    
    // Ensure date is a Date object
    let checkDate = date instanceof Date ? date : new Date(date);
    
    // Validate that date is valid (handle Invalid Date)
    if (isNaN(checkDate.getTime())) {
        checkDate = new Date(); // Fallback to current date if invalid
    }
    
    const agreement = this.regulatoryAgreement;
    
    // Check if agreement is active
    // NOTE: Uses current status (limitation of Option 1 - status may have changed over time)
    if (agreement.status !== 'Active') {
        return {
            compliant: false,
            reason: `Regulatory agreement status is ${agreement.status}`,
            status: 'Non-Compliant'
        };
    }
    
    // Check if agreement has expired (using provided date)
    // Handle MongoDB dates which might be Date objects or strings
    if (agreement.expirationDate) {
        const expirationDate = agreement.expirationDate instanceof Date 
            ? agreement.expirationDate 
            : new Date(agreement.expirationDate);
        
        // Only compare if expirationDate is valid
        if (!isNaN(expirationDate.getTime()) && expirationDate < checkDate) {
        return {
            compliant: false,
            reason: 'Regulatory agreement has expired',
            status: 'Non-Compliant'
        };
    }
    }
    
    // Check if review is overdue (using provided date)
    // NOTE: Uses current nextReviewDate (limitation of Option 1 - may have changed over time)
    // Handle MongoDB dates which might be Date objects or strings
    if (agreement.nextReviewDate) {
        const nextReviewDate = agreement.nextReviewDate instanceof Date 
            ? agreement.nextReviewDate 
            : new Date(agreement.nextReviewDate);
        
        // Only compare if nextReviewDate is valid
        if (!isNaN(nextReviewDate.getTime()) && nextReviewDate < checkDate) {
        return {
            compliant: false,
            reason: 'Regulatory agreement review is overdue',
            status: 'Review Required'
        };
        }
    }
    
    return {
        compliant: true,
        reason: 'Regulatory agreement is active',
        status: 'Compliant'
    };
};

// Placeholder method for Option 2 migration
// Returns null in Option 1 (uses current state), will be implemented in Option 2 to return historical state
buildingSchema.methods.getRegulatoryAgreementState = function(date) {
    // Option 1: Always returns null (uses current regulatoryAgreement)
    // Option 2: Will retrieve historical regulatory agreement state for the given date
    return null;
};

// Method to get regulatory agreement summary
buildingSchema.methods.getRegulatorySummary = function() {
    if (!this.regulatoryAgreement) {
        return null;
    }
    
    const compliance = this.checkRegulatoryCompliance();
    
    return {
        description: this.regulatoryAgreement.description,
        status: this.regulatoryAgreement.status,
        compliance: compliance,
        effectiveDate: this.regulatoryAgreement.effectiveDate,
        expirationDate: this.regulatoryAgreement.expirationDate,
        lastReviewDate: this.regulatoryAgreement.lastReviewDate,
        nextReviewDate: this.regulatoryAgreement.nextReviewDate,
        documentId: this.regulatoryAgreement.document
    };
};

// Method to execute building-level formula and calculate AMI bucket distribution
// @param {Date} checkDate - Optional date to check compliance for (defaults to current date)
buildingSchema.methods.executeBuildingLevelFormula = async function(checkDate = null) {
    try {
        console.log('🚀 ===== EXECUTE BUILDING LEVEL FORMULA CALLED =====');
        console.log('🚀 Building ID:', this._id);
        console.log('🚀 Building Name:', this.name);
        console.log('🚀 Check Date:', checkDate);
        console.log('🚀 Has regulatoryAgreement?', !!this.regulatoryAgreement);
        console.log('🚀 Has buildingLevelFormula?', !!(this.regulatoryAgreement && this.regulatoryAgreement.buildingLevelFormula));
        console.log('🚀 Has limitsFormula?', !!(this.regulatoryAgreement && this.regulatoryAgreement.limitsFormula));
    console.log('🏢 ===== BUILDING FORMULA EXECUTION STARTED =====');
    console.log('🏢 Building ID:', this._id);
    console.log('🏢 Building Name:', this.name);
    
        // Parse and validate checkDate
        let targetDate = null;
        if (checkDate) {
            targetDate = checkDate instanceof Date ? checkDate : new Date(checkDate);
            if (isNaN(targetDate.getTime())) {
                console.log('⚠️  Invalid date provided, using current date');
                targetDate = null;
            } else {
                console.log('📅 Checking compliance for date:', targetDate.toISOString().split('T')[0]);
            }
        }
        
        if (!this.regulatoryAgreement) {
            console.log('❌ No regulatory agreement found for this building');
            throw new Error('No regulatory agreement found for this building');
    }
    
    console.log('✅ Building-level formula found');
        console.log('📋 Formula length:', this.regulatoryAgreement.buildingLevelFormula?.length || 0, 'characters');
    
    // Get all units for this building with tenant data populated
    const Unit = mongoose.model('Unit');
        let units = await Unit.find({ building: this._id }).populate('currentTenant');
    console.log('🏠 Total units found:', units.length);
    
        // Filter units to only those active on the target date
        // This includes both occupied units (active leases) and vacant units
        if (targetDate) {
            const checkDateStart = new Date(targetDate);
            checkDateStart.setHours(0, 0, 0, 0);
            const checkDateEnd = new Date(targetDate);
            checkDateEnd.setHours(23, 59, 59, 999);
            
            const originalUnitCount = units.length;
            const Lease = mongoose.model('Lease');
            const filteredUnits = [];
            
            // Convert filter to async loop to support Lease queries
            for (const unit of units) {
                // Check if unit existed on the target date (occupied or vacant)
                const moveInDate = unit.currentMoveInDate ? new Date(unit.currentMoveInDate) : null;
                const moveOutDate = unit.currentMoveOutDate ? new Date(unit.currentMoveOutDate) : null;
                
                // If unit has move-in date, check if it was active on target date
                if (moveInDate && !isNaN(moveInDate.getTime())) {
                    // Unit was active if move-in date is on or before check date
                    // AND (no move-out date OR move-out date is after check date)
                    const wasActive = moveInDate <= checkDateEnd && (!moveOutDate || moveOutDate >= checkDateStart);
                    if (wasActive) {
                        filteredUnits.push(unit);
                    }
                    continue;
                }
                
                // If no move-in date, query Lease collection to check if unit had active lease on target date
                const unitLeasesOnDate = await Lease.find({
                    unit: unit._id,
                    startDate: { $lte: checkDateEnd },
                    $or: [
                        { endDate: { $gte: checkDateStart } },
                        { endDate: null }
                    ]
                }).limit(1);
                
                if (unitLeasesOnDate.length > 0) {
                    // Unit had active lease = was occupied, include it
                    filteredUnits.push(unit);
                    continue;
                }
                
                // Fallback: check occupancy snapshots for historical data
                const unitSnapshot = unit.getOccupancySnapshot(targetDate);
                if (unitSnapshot) {
                    // Unit had a snapshot = existed on this date
                    filteredUnits.push(unit);
                    continue;
                }
                
                // If no lease and no snapshot, exclude unit (it may not have existed yet)
            }
            
            units = filteredUnits;
            
            // Query all leases on target date for accurate breakdown logging
            const allLeasesOnDate = await Lease.find({
                building: this._id,
                startDate: { $lte: checkDateEnd },
                $or: [
                    { endDate: { $gte: checkDateStart } },
                    { endDate: null }
                ]
            }).select('unit');
            
            const unitsWithLeases = new Set(allLeasesOnDate.map(l => l.unit.toString()));
            const occupiedFromLeases = units.filter(u => unitsWithLeases.has(u._id.toString())).length;
            const vacantFromLeases = units.length - occupiedFromLeases;
            
            console.log(`📅 Filtered units: ${originalUnitCount} total → ${units.length} active on ${targetDate.toISOString().split('T')[0]}`);
            console.log(`📅 Breakdown (from Lease collection): ${occupiedFromLeases} occupied, ${vacantFromLeases} vacant`);
        }
        
    console.log('🏠 Units with tenant data:', units.filter(u => u.currentTenant).length);
    
    // Debug first few units to understand the data structure
    console.log('🔍 Debugging first 3 units:');
    units.slice(0, 3).forEach(unit => {
        console.log(`   Unit ${unit.unitNumber}:`);
        console.log(`     - Status: ${unit.currentOccupancyStatus}`);
        console.log(`     - Has tenant ref: ${!!unit.currentTenant}`);
        console.log(`     - Tenant data: ${unit.currentTenant ? JSON.stringify(unit.currentTenant, null, 2) : 'null'}`);
        console.log(`     - Household count: ${unit.currentHouseholdCount}`);
    });
    
        // Get AMI data for this building using new FIPS-based system
        // If targetDate is provided, use date-specific AMI data
        console.log('📊 Getting AMI data from new amidatas collection (FIPS-based system)...');
        const { getAMIDataForBuilding, getAMIDataForDate, convertAMIDataToAMIFormat } = require('../utils/amiDataHelper');
        let amiData = [];
        let amiDataDateInfo = null; // Store AMI data date information
        
        if (targetDate) {
            // Get AMI data for the specific date
            let fipsCode = null;
            if (this.amiDataReference && this.amiDataReference.fips) {
                fipsCode = this.amiDataReference.fips;
            } else if (this.fips) {
                fipsCode = this.fips.toString();
            }
            
            if (fipsCode) {
                console.log(`🔍 Attempting to fetch AMI data for date ${targetDate.toISOString().split('T')[0]} for FIPS ${fipsCode}`);
                const amiDataForDate = await getAMIDataForDate(fipsCode, targetDate);
                if (amiDataForDate) {
                    amiData = convertAMIDataToAMIFormat(amiDataForDate);
                    amiDataDateInfo = {
                        fiscalYear: amiDataForDate.fiscalYear,
                        version: amiDataForDate.version,
                        startDate: amiDataForDate.startDate,
                        endDate: amiDataForDate.endDate,
                        dateString: amiDataForDate.startDate ? amiDataForDate.startDate.toISOString().split('T')[0] : null
                    };
                    console.log(`✅ AMI data found for date ${targetDate.toISOString().split('T')[0]} (FY${amiDataForDate.fiscalYear}, v${amiDataForDate.version})`);
                } else {
                    console.log(`⚠️  No AMI data found for date ${targetDate.toISOString().split('T')[0]}, falling back to latest available`);
                    const latestAmiData = await getAMIDataForBuilding(this);
                    amiData = latestAmiData;
                }
            } else {
                console.log('⚠️  No FIPS code found, using latest available AMI data');
                amiData = await getAMIDataForBuilding(this);
            }
        } else {
            // Use latest available AMI data
            amiData = await getAMIDataForBuilding(this);
        }
        
    console.log('📊 AMI data entries found:', amiData.length);
    
    if (amiData.length === 0) {
        console.log('❌ No AMI data found for this building');
        throw new Error('No AMI data found for this building');
    }
    
        console.log('📊 AMI data details (from new system):');
        amiData.forEach(ami => {
            console.log(`   - ${ami.name}: ${ami.incomePercentage}%`);
        });
        
        // Create hierarchical structure for backward compatibility with building-level formulas
        // The new system returns flat AMI data, but building formulas may expect hierarchical structure
        // We'll create a simple hierarchy: 80% -> 60% -> 50% -> 30%
        console.log('📊 Creating hierarchical structure for building-level formula compatibility...');
        const amiMap = new Map();
        amiData.forEach((ami, index) => {
            amiMap.set(ami.incomePercentage, ami);
        });
        
        // Build hierarchical relationships (80% is root, others are children)
    amiData.forEach(ami => {
            if (ami.incomePercentage === 80) {
                ami.parent = null;
                ami.children = amiData.filter(a => a.incomePercentage < 80).map(a => a._id || a.incomePercentage);
            } else if (ami.incomePercentage === 60) {
                ami.parent = amiMap.get(80) ? (amiMap.get(80)._id || 80) : null;
                ami.children = amiData.filter(a => a.incomePercentage < 60).map(a => a._id || a.incomePercentage);
            } else if (ami.incomePercentage === 50) {
                ami.parent = amiMap.get(60) ? (amiMap.get(60)._id || 60) : null;
                ami.children = amiData.filter(a => a.incomePercentage < 50).map(a => a._id || a.incomePercentage);
            } else if (ami.incomePercentage === 30) {
                ami.parent = amiMap.get(50) ? (amiMap.get(50)._id || 50) : null;
                ami.children = [];
            }
            // Add hierarchy level
            if (ami.incomePercentage === 80) ami.hierarchyLevel = 0;
            else if (ami.incomePercentage === 60) ami.hierarchyLevel = 1;
            else if (ami.incomePercentage === 50) ami.hierarchyLevel = 2;
            else if (ami.incomePercentage === 30) ami.hierarchyLevel = 3;
        });
        
        console.log('✅ Hierarchical structure created for building-level formula compatibility');
        
        // Execute unit-level calculations using static function
        console.log('\n🔄 Starting unit-level calculation using static function...');
    const unitResults = [];
        console.log('✅ Using static calculateUnitRegulatoryBucket function, processing', units.length, 'units');
        
        // Import Lease and Household models for compliance data
        const Lease = mongoose.model('Lease');
        const Household = mongoose.model('Household');
        
        let processedCount = 0;
        let occupiedCount = 0;
        let vacantCount = 0;
        
        for (const unit of units) {
            let regulatoryBucket = 'Market  0%';
            
            // Get compliance data from lease/household (new approach) with fallback to unit.currentTenant (backward compatibility)
            let tenantIncome = null;
            let householdSize = null;
            
            // Query active leases for this unit
            let activeLeases = [];
            if (targetDate) {
                // For date-based checks, find leases active on that date
                // Note: We don't filter by status here because a lease that was active on the target date
                // might now be 'Expired' or 'Terminated' in the database. We determine if it was active
                // based on the date range (startDate <= targetDate and (endDate >= targetDate or endDate is null))
                const checkDateStart = new Date(targetDate);
                checkDateStart.setHours(0, 0, 0, 0);
                const checkDateEnd = new Date(targetDate);
                checkDateEnd.setHours(23, 59, 59, 999);
                
                activeLeases = await Lease.find({
                    unit: unit._id,
                    startDate: { $lte: checkDateEnd },
                    $or: [
                        { endDate: { $gte: checkDateStart } },
                        { endDate: null }
                    ]
                    // Removed status: 'Active' filter - for historical dates, we determine activity by date range only
                }).sort({ startDate: -1 }).limit(1); // Get most recent active lease
            } else {
                // For current compliance checks, find currently active leases
                activeLeases = await Lease.find({
                    unit: unit._id,
                    status: 'Active'
                }).sort({ startDate: -1 }).limit(1); // Get most recent active lease
            }
            
            // Priority 1: Query household data first (current household data)
            if (activeLeases.length > 0) {
                const lease = activeLeases[0];
                if (lease.household) {
                    const household = await Household.findById(lease.household);
                    if (household) {
                        if (household.currentTotalAnnualIncome !== null && household.currentTotalAnnualIncome !== undefined) {
                            tenantIncome = household.currentTotalAnnualIncome;
                        }
                        if (household.householdSize !== null && household.householdSize !== undefined) {
                            householdSize = household.householdSize;
                        }
                    }
                }
                
                // Priority 2: If household data is incomplete, use lease compliance data (snapshot at move-in)
                if (tenantIncome === null && lease.householdAnnualIncomeAtMoveIn !== null && lease.householdAnnualIncomeAtMoveIn !== undefined) {
                    tenantIncome = lease.householdAnnualIncomeAtMoveIn;
                }
                if (householdSize === null && lease.householdSizeAtMoveIn !== null && lease.householdSizeAtMoveIn !== undefined) {
                    householdSize = lease.householdSizeAtMoveIn;
                }
            }
            
            // Priority 3: Fallback to unit.currentTenant (backward compatibility for units without leases)
            if (tenantIncome === null) {
                tenantIncome = unit.currentTenant?.totalHouseholdIncome || 
                             unit.currentTenant?.currentAnnualIncome || 
                             unit.currentTenant?.income || null;
            }
            if (householdSize === null) {
                householdSize = unit.currentHouseholdCount || (unit.currentTenant?.householdSize || 1);
            }
            
            // Determine occupancy status for the target date
            // Use Lease collection as the PRIMARY source of truth for occupancy
            let occupancyStatusForDate;
            if (targetDate) {
                // For historical checks, use Lease collection as primary source
                if (activeLeases.length > 0) {
                    // Lease was active on this date = unit was occupied
                    occupancyStatusForDate = 'Occupied';
                } else {
                    // No active lease on this date = unit was vacant
                    occupancyStatusForDate = 'Vacant';
                }
                
                // Optional: Validate against snapshot for data quality checks
                const unitSnapshot = unit.getOccupancySnapshot(targetDate);
                if (unitSnapshot && unitSnapshot.occupancyStatus !== occupancyStatusForDate) {
                    // Log discrepancy for debugging/data quality monitoring
                    console.warn(`⚠️  Occupancy mismatch for unit ${unit.unitNumber} on ${targetDate.toISOString().split('T')[0]}: Lease says ${occupancyStatusForDate}, Snapshot says ${unitSnapshot.occupancyStatus}`);
                }
            } else {
                // For current checks, also use Lease collection (more accurate than currentOccupancyStatus)
                if (activeLeases.length > 0) {
                    occupancyStatusForDate = 'Occupied';
                } else {
                    // No active lease = vacant (fallback to currentOccupancyStatus only if needed for edge cases)
                    occupancyStatusForDate = unit.currentOccupancyStatus || 'Vacant';
                }
            }
            
            // Check if income is valid (not null, undefined, or 0)
            // Note: Income of 0 is technically valid but will always result in Market 0% bucket
            const hasValidIncome = tenantIncome !== null && tenantIncome !== undefined && tenantIncome > 0;
            
            if (occupancyStatusForDate === 'Occupied' && 
                hasValidIncome && 
                householdSize) {
                occupiedCount++;
                try {
                    console.log(`   📍 Processing Unit ${unit.unitNumber}: Income=$${tenantIncome}, HH Size=${householdSize}`);
                    console.log(`   🔍 AMI data sample:`, amiData.length > 0 ? {
                        name: amiData[0].name,
                        incomePercentage: amiData[0].incomePercentage,
                        hasHouseholdLimits: !!amiData[0].householdIncomeLimits,
                        limitKeys: amiData[0].householdIncomeLimits ? Object.keys(amiData[0].householdIncomeLimits) : [],
                        limitForHHSize: amiData[0].householdIncomeLimits ? amiData[0].householdIncomeLimits[householdSize] : undefined,
                        limitForHHSizeString: amiData[0].householdIncomeLimits ? amiData[0].householdIncomeLimits[String(householdSize)] : undefined
                    } : 'No AMI data');
                    
                    // Use static function instead of dynamic formula execution
                    regulatoryBucket = calculateUnitRegulatoryBucket(
                        tenantIncome, 
                        householdSize, 
                        amiData
                    );
                    
                    if (regulatoryBucket === undefined || regulatoryBucket === null) {
                        console.warn(`   ⚠️  Unit ${unit.unitNumber} calculation returned undefined/null, defaulting to Market`);
                        regulatoryBucket = 'Market  0%';
                    }
                    console.log(`   ✅ Unit ${unit.unitNumber} → ${regulatoryBucket}`);
                } catch (error) {
                    console.error(`   ❌ Error calculating regulatory bucket for unit ${unit.unitNumber}:`, error);
                    console.error(`   ❌ Error stack:`, error.stack);
                    regulatoryBucket = 'Market  0%';
                }
            } else if (occupancyStatusForDate === 'Vacant' || 
                       occupancyStatusForDate === 'Vacant-Leased') {
                vacantCount++;
                regulatoryBucket = 'Vacant';
                console.log(`   🏠 Unit ${unit.unitNumber} → Vacant`);
            } else {
                const debugInfo = [];
                if (occupancyStatusForDate !== 'Occupied') debugInfo.push(`status: ${occupancyStatusForDate}`);
                
                // Debug income and household size from lease/household or fallback
                if (tenantIncome === null || tenantIncome === undefined || tenantIncome === 0) {
                    debugInfo.push(`no income (lease: ${activeLeases.length > 0 ? 'found' : 'none'}, tenant: ${unit.currentTenant ? 'found' : 'none'})`);
                } else if (tenantIncome === 0) {
                    debugInfo.push(`income=0 (income too low for AMI calculation)`);
                }
                
                if (!householdSize || householdSize === 0) {
                    debugInfo.push('no household count');
                }
                
                console.log(`   ⚠️  Unit ${unit.unitNumber} → Market (${debugInfo.join(', ')})`);
            }

            const bucketParts = typeof regulatoryBucket === 'string' ? regulatoryBucket.split('  ') : [];
            const bucketNameOnly = bucketParts.length > 0 ? bucketParts[0]?.trim() : null;
            let bucketPercentage = null;
            if (bucketParts.length > 1) {
                const percentageStr = bucketParts[1].replace('%', '').trim();
                const parsedPercentage = parseFloat(percentageStr);
                if (!Number.isNaN(parsedPercentage)) {
                    bucketPercentage = parsedPercentage;
                }
            }

            let matchingAmiForUnit = null;
            if (bucketPercentage !== null) {
                matchingAmiForUnit = amiData.find(ami => ami.incomePercentage === bucketPercentage);
            }
            if (!matchingAmiForUnit && bucketNameOnly) {
                matchingAmiForUnit = amiData.find(ami => ami.name === bucketNameOnly);
            }

            const normalizedHouseholdSize = householdSize && householdSize > 0 ? householdSize : 1;
            const rawIncomeLimit = matchingAmiForUnit?.householdIncomeLimits
                ? (
                    matchingAmiForUnit.householdIncomeLimits[normalizedHouseholdSize] ??
                    matchingAmiForUnit.householdIncomeLimits[String(normalizedHouseholdSize)] ??
                    matchingAmiForUnit.householdIncomeLimits[householdSize] ??
                    matchingAmiForUnit.householdIncomeLimits[String(householdSize)]
                )
                : null;
            let incomeLimitForHousehold = null;
            if (rawIncomeLimit !== null && rawIncomeLimit !== undefined) {
                const parsedLimit = Number(rawIncomeLimit);
                if (!Number.isNaN(parsedLimit)) {
                    incomeLimitForHousehold = parsedLimit;
                }
            }

            // Calculate rent limit using Regulatory Agreement Calculator requirements
            // According to the agreement, rent limits must use:
            // - Imputed household size from unit bedrooms: "1 Person/1 Bedroom + 1"
            // - 35% of income limit divided by 12 (fixed, not configurable)
            // - Only calculate for Low Income Units (30%, 60%, or 80% AMI buckets)
            let allowedRent = null;
            let amiBucketMonthlyRent = null; // Rent limit for the tenant's assigned AMI bucket
            if (bucketPercentage !== null && (bucketPercentage === 30 || bucketPercentage === 60 || bucketPercentage === 80)) {
                // Use unit bedrooms to calculate imputed household size
                const unitBedrooms = unit.bedrooms !== null && unit.bedrooms !== undefined ? unit.bedrooms : 0;
                allowedRent = calculateRentLimit(unitBedrooms, bucketPercentage, amiData);
                amiBucketMonthlyRent = allowedRent; // Same calculation for the assigned bucket
            }
            // Note: For Market 0% units or units without valid bucket percentage, allowedRent remains null
            const currentRentAmount = typeof unit.currentTotalMonthlyBilling === 'number'
                ? unit.currentTotalMonthlyBilling
                : (typeof unit.currentRentAmount === 'number' ? unit.currentRentAmount : null);
            const marketRentAmount = typeof unit.currentMarketRent === 'number'
                ? unit.currentMarketRent
                : null;
            const delinquencyAmount = typeof unit.currentTotalDelinquent === 'number'
                ? unit.currentTotalDelinquent
                : (typeof unit.currentOutstandingBalance === 'number' ? unit.currentOutstandingBalance : 0);

            let incomeUtilization = null;
            if (
                incomeLimitForHousehold &&
                incomeLimitForHousehold > 0 &&
                tenantIncome !== null &&
                tenantIncome !== undefined
            ) {
                incomeUtilization = Number((tenantIncome / incomeLimitForHousehold).toFixed(4));
            }

            let eligibilityStatus = 'Unknown';
            if (incomeUtilization !== null) {
                if (incomeUtilization <= 0.7) {
                    eligibilityStatus = 'Safe';
                } else if (incomeUtilization <= 0.9) {
                    eligibilityStatus = 'Watch';
                } else {
                    eligibilityStatus = 'At Risk';
                }
            }

            const potentialRentGap = allowedRent !== null && currentRentAmount !== null
                ? Number((allowedRent - currentRentAmount).toFixed(2))
                : null;

            const tenantName =
                unit.currentTenantName ||
                unit.currentTenant?.fullName ||
                [unit.currentTenant?.firstName, unit.currentTenant?.lastName].filter(Boolean).join(' ').trim() ||
                null;
            const tenantId = unit.currentTenant?._id || null;
            const leaseId = unit.currentLeaseId || unit.currentTenant?.leaseId || null;
            
            // Get bathrooms from floorplan (priority) or fallback to unit.bathrooms
            let bathrooms = null;
            if (unit.floorplanId) {
                const floorplan = this.getFloorplan(unit.floorplanId);
                if (floorplan && floorplan.bathrooms !== null && floorplan.bathrooms !== undefined) {
                    bathrooms = floorplan.bathrooms;
                }
            }
            // If not found by ID, try matching by floorplan name
            if (bathrooms === null && unit.floorplan) {
                const normalizedFloorplanName = unit.floorplan.toString().trim().toLowerCase();
                const matchingFloorplan = this.floorplans.find(fp => 
                    fp.name && fp.name.toString().trim().toLowerCase() === normalizedFloorplanName
                );
                if (matchingFloorplan && matchingFloorplan.bathrooms !== null && matchingFloorplan.bathrooms !== undefined) {
                    bathrooms = matchingFloorplan.bathrooms;
                }
            }
            // Fallback to unit.bathrooms if floorplan lookup failed
            if (bathrooms === null) {
                bathrooms = unit.bathrooms !== null && unit.bathrooms !== undefined ? unit.bathrooms : null;
            }
            
            // Get bedrooms from floorplan (priority) or fallback to unit.bedrooms
            let unitBedrooms = null;
            if (unit.floorplanId) {
                const floorplan = this.getFloorplan(unit.floorplanId);
                if (floorplan && floorplan.bedrooms !== null && floorplan.bedrooms !== undefined) {
                    unitBedrooms = floorplan.bedrooms;
                }
            }
            // If not found by ID, try matching by floorplan name
            if (unitBedrooms === null && unit.floorplan) {
                const normalizedFloorplanName = unit.floorplan.toString().trim().toLowerCase();
                const matchingFloorplan = this.floorplans.find(fp => 
                    fp.name && fp.name.toString().trim().toLowerCase() === normalizedFloorplanName
                );
                if (matchingFloorplan && matchingFloorplan.bedrooms !== null && matchingFloorplan.bedrooms !== undefined) {
                    unitBedrooms = matchingFloorplan.bedrooms;
                }
            }
            // Fallback to unit.bedrooms if floorplan lookup failed
            if (unitBedrooms === null) {
                unitBedrooms = unit.bedrooms !== null && unit.bedrooms !== undefined ? unit.bedrooms : null;
            }
            
            unitResults.push({
                unitId: unit._id,
                unitNumber: unit.unitNumber,
                regulatoryBucket: regulatoryBucket,
                occupancyStatus: occupancyStatusForDate,
                tenantIncome: tenantIncome || null,
                householdCount: householdSize || null,
                bathrooms: bathrooms,
                bedrooms: unitBedrooms, // Bedrooms for rent limit calculation
                bucketName: bucketNameOnly || null,
                bucketPercentage,
                tenantName,
                tenantId,
                leaseId,
                currentRent: currentRentAmount,
                marketRent: marketRentAmount,
                delinquencyAmount,
                incomeLimit: incomeLimitForHousehold,
                incomeUtilization,
                incomeUtilizationPercent: incomeUtilization !== null ? Number((incomeUtilization * 100).toFixed(2)) : null,
                eligibilityStatus,
                maxAllowedRent: allowedRent,
                amiBucketMonthlyRent: amiBucketMonthlyRent, // Rent limit for the tenant's assigned AMI bucket
                potentialRentGap,
                householdSizeUsedForLimit: normalizedHouseholdSize
            });
            processedCount++;
        }
        
        console.log('📊 Unit processing summary:');
        console.log(`   - Total processed: ${processedCount}`);
        console.log(`   - Occupied with data: ${occupiedCount}`);
        console.log(`   - Vacant: ${vacantCount}`);
        console.log(`   - Market/Other: ${processedCount - occupiedCount - vacantCount}`);
        
        // Count units by status for debugging
        const statusCounts = {};
        units.forEach(unit => {
            statusCounts[unit.currentOccupancyStatus] = (statusCounts[unit.currentOccupancyStatus] || 0) + 1;
        });
        console.log('📊 Unit status breakdown:', statusCounts);
        
        // Count units with tenant references by status
        const occupiedWithTenant = units.filter(u => u.currentOccupancyStatus === 'Occupied' && u.currentTenant).length;
        const occupiedWithoutTenant = units.filter(u => u.currentOccupancyStatus === 'Occupied' && !u.currentTenant).length;
        console.log(`📊 Occupied units: ${occupiedWithTenant} with tenant, ${occupiedWithoutTenant} without tenant`);
    
    // Calculate hierarchical distribution for the building-level formula
    console.log('\n🔄 Calculating hierarchical distribution...');
    const hierarchicalDistribution = this.calculateHierarchicalDistribution(unitResults, amiData);
    console.log('✅ Hierarchical distribution calculated');
    console.log('📊 AMI buckets found:', hierarchicalDistribution.amiBuckets?.length || 0);
    if (hierarchicalDistribution.amiBuckets) {
        hierarchicalDistribution.amiBuckets.forEach(bucket => {
            console.log(`   - ${bucket.name}: ${bucket.numberOfUnits} units (${bucket.unitsPercentage})`);
        });
    }
    
        // Execute building-level calculation using static function
        console.log('\n🚀 Executing building-level calculation using static function...');
    console.log('📊 Input parameters:');
    console.log(`   - units: ${units.length} entries`);
    console.log(`   - unitResults: ${unitResults.length} entries`);
    console.log(`   - amiData: ${amiData.length} entries`);
    console.log(`   - hierarchicalData: ${hierarchicalDistribution.amiBuckets?.length || 0} buckets`);
    
        // Validate AMI data structure before passing to function
        console.log('🔍 Validating AMI data structure...');
        const validatedAmiData = amiData.map((item, index) => {
            if (!item) {
                console.warn(`⚠️  AMI data item at index ${index} is null or undefined`);
                return null;
            }
            if (typeof item.incomePercentage === 'undefined' || item.incomePercentage === null) {
                console.warn(`⚠️  AMI data item at index ${index} (${item.name || 'unnamed'}) has no incomePercentage`);
            }
            if (!item.name) {
                console.warn(`⚠️  AMI data item at index ${index} has no name`);
            }
            return item;
        }).filter(item => item !== null);
        
        if (validatedAmiData.length === 0) {
            throw new Error('No valid AMI data available for building-level calculation');
        }
        
        console.log(`✅ Validated AMI data: ${validatedAmiData.length} valid entries`);
        
        // Ensure all AMI data items have required properties before passing to function
        const sanitizedAmiData = validatedAmiData.map(item => ({
            name: item.name || 'Unknown',
            incomePercentage: item.incomePercentage || 0,
            householdIncomeLimits: item.householdIncomeLimits || {},
            description: item.description || `At least ${item.incomePercentage || 0}% of units must be at or below ${item.incomePercentage || 0}% AMI`,
            ...item // Include any other properties
        }));
        
        console.log('📊 Sanitized AMI data sample:', JSON.stringify(sanitizedAmiData.slice(0, 2), null, 2));
        console.log('📊 Sample unitResults (first 5):');
        unitResults.slice(0, 5).forEach(result => {
            console.log(`   Unit ${result.unitNumber}: ${result.regulatoryBucket} (${result.occupancyStatus}) - Income: ${result.tenantIncome}, HH: ${result.householdCount}`);
        });
        
        // Use static function instead of dynamic formula execution
        const buildingResult = calculateBuildingLevelCompliance(units, unitResults, sanitizedAmiData, hierarchicalDistribution);
        console.log('✅ Building-level calculation executed successfully');
        console.log('📊 Building result:', JSON.stringify(buildingResult, null, 2));
        
        // Calculate rent compliance using hierarchical bucket eligibility
        console.log('💰 ===== EXECUTING RENT COMPLIANCE CALCULATION =====');
        let rentComplianceResult = null;
        try {
            rentComplianceResult = calculateRentCompliance(unitResults, sanitizedAmiData, units);
            console.log('✅ Rent compliance calculation executed successfully');
            console.log('📊 Rent compliance result:', JSON.stringify(rentComplianceResult, null, 2));
        } catch (rentError) {
            console.error('❌ Error executing rent compliance calculation:', rentError);
            console.error('❌ Error stack:', rentError.stack);
            // Don't fail the entire process if rent compliance calculation fails
        }
        
        // Calculate overall compliance (combines income and rent)
        console.log('🎯 ===== EXECUTING OVERALL COMPLIANCE CALCULATION =====');
        let overallComplianceResult = null;
        try {
            if (buildingResult && rentComplianceResult) {
                overallComplianceResult = calculateOverallCompliance(buildingResult, rentComplianceResult);
                console.log('✅ Overall compliance calculation executed successfully');
                console.log('📊 Overall compliance result:', JSON.stringify(overallComplianceResult, null, 2));
            } else {
                console.log('⚠️  Cannot calculate overall compliance - missing income or rent compliance results');
            }
        } catch (overallError) {
            console.error('❌ Error executing overall compliance calculation:', overallError);
            console.error('❌ Error stack:', overallError.stack);
            // Don't fail the entire process if overall compliance calculation fails
        }
        
        // Execute limits calculation using static function
        console.log('📊 ===== EXECUTING LIMITS CALCULATION =====');
        let limitsResult = null;
        try {
            console.log('📊 Total units:', units.length);
            console.log('📊 AMI data count:', amiData.length);
            console.log('📊 AMI data:', JSON.stringify(amiData.map(a => ({ name: a.name, incomePercentage: a.incomePercentage })), null, 2));
            
            // Use static function instead of dynamic formula execution
            limitsResult = calculateLimits(units.length, sanitizedAmiData);
            
            console.log('✅ Limits calculation executed successfully');
            console.log('📊 Limits result type:', typeof limitsResult);
            console.log('📊 Limits result:', JSON.stringify(limitsResult, null, 2));
            
            if (limitsResult && limitsResult.amiLimits) {
                console.log('📊 Limits result has amiLimits array with', limitsResult.amiLimits.length, 'entries');
                limitsResult.amiLimits.forEach((limit, idx) => {
                    console.log(`   [${idx}] ${limit.name}: limitInUnits=${limit.limitInUnits}, limitInPercentage=${limit.limitInPercentage}`);
                });
            } else {
                console.log('⚠️  Limits result does NOT have amiLimits array!');
                console.log('⚠️  Limits result keys:', limitsResult ? Object.keys(limitsResult) : 'null');
            }
        } catch (limitsError) {
            console.error('❌ Error executing limits calculation:', limitsError);
            console.error('❌ Error stack:', limitsError.stack);
            console.error('❌ Error message:', limitsError.message);
            // Don't fail the entire process if limits calculation fails
        }
        
        // Merge building formula results with hierarchical distribution
        const enhancedHierarchicalDistribution = {
            ...hierarchicalDistribution,
            // Use building formula AMI buckets if available, otherwise keep hierarchical ones
            amiBuckets: buildingResult && buildingResult.amiBuckets ? buildingResult.amiBuckets : hierarchicalDistribution.amiBuckets,
            // Use building formula summary if available, otherwise keep hierarchical one
            summary: buildingResult && buildingResult.summary ? buildingResult.summary : hierarchicalDistribution.summary,
            // Include limits result if available
            limits: limitsResult
        };
        
        // Build bucket compliance SOLELY from limitsFormula output
        // The limitsFormula function executeLimitsFormula(totalUnits, amiData) returns amiLimits array
        // This is the ONLY source of truth - we only check compliance for buckets defined in limitsFormula
        console.log('🔗 ===== BUILDING BUCKET COMPLIANCE FROM LIMITS FORMULA =====');
        console.log('🔗 limitsResult exists?', !!limitsResult);
        console.log('🔗 limitsResult type:', typeof limitsResult);
        console.log('🔗 limitsResult:', limitsResult);
        console.log('🔗 limitsResult.amiLimits exists?', !!(limitsResult && limitsResult.amiLimits));
        
        if (limitsResult && limitsResult.amiLimits && Array.isArray(limitsResult.amiLimits)) {
            console.log('🔗 Creating bucket compliance entries from limitsFormula...');
            const totalUnits = units.length;
            const bucketComplianceEntries = [];
            
            // Create a map of actual buckets from hierarchical distribution for matching
            const actualBucketsMap = new Map();
            if (enhancedHierarchicalDistribution.amiBuckets) {
                enhancedHierarchicalDistribution.amiBuckets.forEach(bucket => {
                    // Store by base name (without percentage)
                    const baseName = bucket.name.split('  ')[0];
                    actualBucketsMap.set(baseName, bucket);
                    // Also store by full name
                    actualBucketsMap.set(bucket.name, bucket);
                    // Also store by percentage if available
                    if (bucket.percentage) {
                        const percentageNum = parseFloat(bucket.percentage.replace('%', ''));
                        actualBucketsMap.set(`percentage_${percentageNum}`, bucket);
                    }
                });
            }
            
            console.log('🔗 Actual buckets map keys:', Array.from(actualBucketsMap.keys()));
            
            // For each limit from limitsFormula, create a compliance entry
            limitsResult.amiLimits.forEach(limit => {
                console.log(`🔗 Processing limit: ${limit.name} (${limit.percentage})`);
                
                // Try to find matching actual bucket
                let matchingBucket = actualBucketsMap.get(limit.name);
                
                // If no exact match, try matching by base name (bucket names might include percentage like "LIHTC 60%")
                if (!matchingBucket) {
                    // Try to find a bucket whose name starts with the limit name
                    for (const [key, bucket] of actualBucketsMap.entries()) {
                        const bucketBaseName = bucket.name.split('  ')[0]; // Extract base name
                        if (bucketBaseName === limit.name || bucket.name.startsWith(limit.name + '  ')) {
                            console.log(`   ✅ Found match by base name: ${key} (base: ${bucketBaseName})`);
                            matchingBucket = bucket;
                            break;
                        }
                    }
                }
                
                // If still no match, try matching by percentage
                if (!matchingBucket && limit.percentage) {
                    const limitPercentageNum = parseFloat(limit.percentage.replace('%', ''));
                    matchingBucket = actualBucketsMap.get(`percentage_${limitPercentageNum}`);
                    
                    // Also try finding by matching percentage in bucket names
                    if (!matchingBucket) {
                        for (const [key, bucket] of actualBucketsMap.entries()) {
                            if (bucket.percentage) {
                                const bucketPercentageNum = parseFloat(bucket.percentage.replace('%', ''));
                                if (bucketPercentageNum === limitPercentageNum) {
                                    console.log(`   ✅ Found match by percentage: ${key} (${bucketPercentageNum}%)`);
                                    matchingBucket = bucket;
                                    break;
                                }
                            }
                        }
                    }
                }
                
                // Get actual unit count from matching bucket, or 0 if not found
                const actualUnits = matchingBucket ? (matchingBucket.numberOfUnits || matchingBucket.value || 0) : 0;
                const actualPercentageNum = totalUnits > 0 ? ((actualUnits / totalUnits) * 100) : 0;
                const actualPercentageStr = actualPercentageNum.toFixed(1) + '%';
                
                // Get limit values from limitsFormula output (this is the source of truth)
                // limitInUnits should be null (thresholds, not actual unit counts)
                const limitInUnits = null; // Always null - these are thresholds, not unit counts
                const limitInPercentageStr = limit.limitInPercentage || '0%';
                const limitInPercentageNum = parseFloat(limitInPercentageStr.replace('%', '')) || 0;
                
                console.log(`   📊 ${limit.name}:`);
                console.log(`      - Actual: ${actualUnits} units (${actualPercentageStr})`);
                console.log(`      - Limit: N/A (threshold: ${limitInPercentageStr})`);
                
                // Calculate compliance: for "at least X%" requirements, compliant if actual >= limit
                const isCompliant = actualPercentageNum >= limitInPercentageNum;
                
                console.log(`      - Compliance: ${actualPercentageNum} >= ${limitInPercentageNum} = ${isCompliant ? '✅ Compliant' : '❌ Not Compliant'}`);
                
                // Create bucket compliance entry from limitsFormula output
                bucketComplianceEntries.push({
                    name: limit.name,
                    percentage: limit.percentage,
                    numberOfUnits: actualUnits,
                    unitsPercentage: actualPercentageStr,
                    limitInUnits: limitInUnits, // Always null - thresholds, not unit counts
                    limitInPercentage: limitInPercentageStr,
                    complianceStatus: isCompliant ? 'Compliant' : 'Not Compliant'
                });
            });
            
            console.log('🔗 Created bucket compliance entries from limitsFormula:', JSON.stringify(bucketComplianceEntries, null, 2));
            
            // Replace enhancedHierarchicalDistribution.amiBuckets with compliance entries from limitsFormula
            // This ensures we ONLY show buckets that are defined in limitsFormula
            // The limitsFormula is the ONLY source of truth for which buckets to check
            enhancedHierarchicalDistribution.amiBuckets = bucketComplianceEntries;
            
            // Update overall compliance status
            const allCompliant = bucketComplianceEntries.length > 0 && 
                                 bucketComplianceEntries.every(entry => entry.complianceStatus === 'Compliant');
            if (enhancedHierarchicalDistribution.summary) {
                enhancedHierarchicalDistribution.summary.complianceStatus = allCompliant ? 'Compliant' : 'Not Compliant';
            }
            
            console.log(`✅ Bucket compliance built from limitsFormula. Overall: ${allCompliant ? 'Compliant' : 'Not Compliant'} (${bucketComplianceEntries.length} buckets checked)`);
        } else {
            if (!limitsResult) {
                console.log('⚠️  No limitsFormula output available - limitsResult is null/undefined');
            } else if (!limitsResult.amiLimits) {
                console.log('⚠️  limitsResult exists but does not have amiLimits property');
                console.log('⚠️  limitsResult keys:', Object.keys(limitsResult));
                console.log('⚠️  limitsResult:', JSON.stringify(limitsResult, null, 2));
            } else if (!Array.isArray(limitsResult.amiLimits)) {
                console.log('⚠️  limitsResult.amiLimits is not an array');
                console.log('⚠️  limitsResult.amiLimits type:', typeof limitsResult.amiLimits);
            }
            console.log('⚠️  Bucket compliance cannot be calculated without valid limitsFormula output');
        }
        
        console.log('🔗 Enhanced hierarchical distribution:', JSON.stringify(enhancedHierarchicalDistribution, null, 2));
        
        const finalResult = {
            buildingId: this._id,
            buildingName: this.name,
            totalUnits: units.length,
            unitResults: unitResults,
            hierarchicalDistribution: enhancedHierarchicalDistribution,
            buildingLevelResult: buildingResult,
            limitsResult: limitsResult,
            rentCompliance: rentComplianceResult,
            overallCompliance: overallComplianceResult,
            executedAt: new Date()
        };
        
        console.log('🏢 ===== BUILDING FORMULA EXECUTION COMPLETED =====');
        console.log('📊 Final result summary:');
        console.log(`   - Building: ${this.name} (${units.length} units)`);
        console.log(`   - Unit results: ${unitResults.length} entries`);
        console.log(`   - AMI buckets: ${enhancedHierarchicalDistribution.amiBuckets?.length || 0}`);
        console.log(`   - Execution time: ${new Date().toISOString()}`);
        
        return finalResult;
        
    } catch (error) {
        console.error('❌ Error executing building-level formula:', error);
        console.error('❌ Error message:', error.message);
        console.error('❌ Error stack:', error.stack);
        console.error('❌ Formula that failed:', this.regulatoryAgreement.buildingLevelFormula);
        
        // Provide more helpful error messages for common issues
        if (error.message && error.message.includes("Cannot read properties of undefined (reading 'match')")) {
            const helpfulMessage = 'The building-level formula is trying to access a property that is undefined. ' +
                'This usually happens when AMI data items are missing required fields (like incomePercentage or description). ' +
                'Please check that all AMI data items have the required properties.';
            console.error('💡 Helpful hint:', helpfulMessage);
            throw new Error(`${error.message}. ${helpfulMessage}`);
        }
        
        if (error.message && (error.message.includes('Unexpected token') || error.message.includes('SyntaxError'))) {
            const helpfulMessage = 'The building-level formula has a syntax error. ' +
                'This might be due to a premature function closure or missing return statement. ' +
                'Please regenerate the formula.';
            console.error('💡 Helpful hint:', helpfulMessage);
            throw new Error(`${error.message}. ${helpfulMessage}`);
        }
        
        throw error;
    }
};

// Method to calculate hierarchical AMI distribution at building level
buildingSchema.methods.calculateHierarchicalDistribution = function(unitResults, amiData) {
    const bucketCounts = {};
    const hierarchicalBuckets = {};
    const totalUnits = unitResults.length;
    const reservationRequirements = Array.isArray(this?.regulatoryAgreement?.reservationRequirements)
        ? this.regulatoryAgreement.reservationRequirements
        : [];
    const bucketLabelMap = new Map();
    reservationRequirements.forEach(requirement => {
        if (typeof requirement?.amiPercentage === 'number' && requirement.bucketName) {
            bucketLabelMap.set(requirement.amiPercentage, requirement.bucketName.trim());
        }
    });
    
    // Build AMI hierarchy map for easy lookup
    // Support both old system (with _id) and new system (with incomePercentage as key)
    const amiMap = new Map();
    amiData.forEach(ami => {
        // Use _id if available (old system), otherwise use incomePercentage (new system)
        const key = ami._id ? ami._id.toString() : `percentage_${ami.incomePercentage}`;
        amiMap.set(key, ami);
        // Also index by incomePercentage for easier lookup
        amiMap.set(`percentage_${ami.incomePercentage}`, ami);
    });
    
    // Count units in each bucket and track hierarchical relationships
    unitResults.forEach(unitResult => {
        const bucket = unitResult.regulatoryBucket;
        
        if (bucket && bucket !== 'No Formula' && bucket !== 'Unknown' && bucket !== 'Calculation Error') {
            // Count for flat distribution
            bucketCounts[bucket] = (bucketCounts[bucket] || 0) + 1;
            
            // For hierarchical distribution, count this unit for all parent AMI levels
            if (bucket !== 'Vacant' && bucket !== 'Market  0%') {
                // Parse the bucket to find the corresponding AMI data
                const bucketParts = bucket.split('  '); // Double space separator
                const bucketName = bucketParts[0];
                const bucketPercentage = bucketParts[1] ? parseInt(bucketParts[1].replace('%', '')) : null;
                
                // Find the AMI object that matches this bucket
                const matchingAMI = amiData.find(ami => 
                    ami.name === bucketName || 
                    (bucketPercentage && ami.incomePercentage === bucketPercentage)
                );
                
                if (matchingAMI) {
                    // Count this unit for the specific AMI level
                    const hierarchyKey = `${matchingAMI.name}  ${matchingAMI.incomePercentage}%`;
                    hierarchicalBuckets[hierarchyKey] = (hierarchicalBuckets[hierarchyKey] || 0) + 1;
                    
                    // Count this unit for all parent AMI levels (hierarchical inclusion)
                    let currentAMI = matchingAMI;
                    while (currentAMI.parent) {
                        // Support both old system (parent is ObjectId) and new system (parent is percentage or reference)
                        let parentAMI = null;
                        if (typeof currentAMI.parent === 'object' && currentAMI.parent.toString) {
                            // Old system: parent is ObjectId
                            parentAMI = amiMap.get(currentAMI.parent.toString());
                        } else if (typeof currentAMI.parent === 'number') {
                            // New system: parent is incomePercentage number
                            parentAMI = amiMap.get(`percentage_${currentAMI.parent}`);
                        } else if (typeof currentAMI.parent === 'string') {
                            // Try as ObjectId string or percentage string
                            parentAMI = amiMap.get(currentAMI.parent) || amiMap.get(`percentage_${currentAMI.parent}`);
                        }
                        
                        if (parentAMI) {
                            const parentKey = `${parentAMI.name}  ${parentAMI.incomePercentage}%`;
                            hierarchicalBuckets[parentKey] = (hierarchicalBuckets[parentKey] || 0) + 1;
                            currentAMI = parentAMI;
                        } else {
                            break;
                        }
                    }
                }
            }
        }
    });
    
    // Convert to structured format
    const amiBuckets = Object.entries(hierarchicalBuckets).map(([bucket, count]) => {
        const bucketParts = bucket.split('  ');
        const bucketName = bucketParts[0];
        const bucketPercentage = bucketParts[1] ? parseInt(bucketParts[1].replace('%', '')) : 0;
        const regulatoryLabel = bucketLabelMap.get(bucketPercentage);
        const displayName = regulatoryLabel || bucketName;
        
        return {
            name: displayName,
            rawName: bucketName,
            regulatoryBucketName: regulatoryLabel || null,
            percentage: bucketPercentage + '%',
            numberOfUnits: count,
            unitsPercentage: totalUnits > 0 ? ((count / totalUnits) * 100).toFixed(1) + '%' : '0.0%',
            limitInUnits: Math.floor(totalUnits * (bucketPercentage / 100)), // Basic calculation - can be overridden by formula
            limitInPercentage: bucketPercentage + '%'
        };
    });
    
    return {
        amiBuckets: amiBuckets,
        summary: {
            totalUnits: totalUnits,
            occupiedUnits: unitResults.filter(u => u.occupancyStatus === 'Occupied').length,
            vacantUnits: unitResults.filter(u => u.occupancyStatus === 'Vacant' || u.occupancyStatus === 'Vacant-Leased').length,
            complianceStatus: 'Calculated' // Can be overridden by building-level formula
        }
    };
};

// Method to add a floorplan and optionally create units
/**
 * @param {Object} floorplanData - Floorplan data object
 * @param {string} floorplanData.name - Floorplan name
 * @param {number} floorplanData.bedrooms - Number of bedrooms
 * @param {number} floorplanData.bathrooms - Number of bathrooms
 * @param {number} floorplanData.averageSquareFootage - Average square footage
 * @param {number} floorplanData.numberOfUnits - Number of units to create
 * @param {boolean} createUnits - Whether to create units immediately
 * @returns {Promise<Object>} Object with floorplan and unitsCreated count
 */
buildingSchema.methods.addFloorplan = async function(floorplanData, createUnits = false) {
    const Unit = mongoose.model('Unit');
    
    // Create floorplan
    const newFloorplan = {
        ...floorplanData,
        createdAt: new Date(),
        updatedAt: new Date()
    };
    
    this.floorplans.push(newFloorplan);
    await this.save();
    
    const savedFloorplan = this.floorplans[this.floorplans.length - 1];
    
    // Optionally create units for this floorplan
    if (createUnits && floorplanData.numberOfUnits > 0) {
        const units = [];
        for (let i = 1; i <= floorplanData.numberOfUnits; i++) {
            // Generate unit number (you may want a more sophisticated numbering scheme)
            const unitNumber = `${savedFloorplan.name}-${i}`;
            
            // Check if unit already exists
            const existingUnit = await Unit.findOne({
                building: this._id,
                unitNumber: unitNumber
            });
            
            if (!existingUnit) {
                const newUnit = new Unit({
                    building: this._id,
                    unitNumber: unitNumber,
                    unitType: savedFloorplan.name,
                    floorplanId: savedFloorplan._id,
                    floorplan: savedFloorplan.name,
                    squareFootage: savedFloorplan.averageSquareFootage,
                    size: savedFloorplan.averageSquareFootage,
                    sizeUnit: 'sqft',
                    bedrooms: savedFloorplan.bedrooms,
                    bathrooms: savedFloorplan.bathrooms,
                    parkingSpaces: savedFloorplan.parkingSpaces || 0,
                    balcony: savedFloorplan.balcony || false,
                    furnished: savedFloorplan.furnished || false,
                    currentOccupancyStatus: 'Vacant'
                });
                
                units.push(newUnit);
            }
        }
        
        if (units.length > 0) {
            await Unit.insertMany(units);
        }
        
        return {
            floorplan: savedFloorplan,
            unitsCreated: units.length
        };
    }
    
    return {
        floorplan: savedFloorplan,
        unitsCreated: 0
    };
};

// Method to get floorplan by ID
/**
 * @param {mongoose.Types.ObjectId} floorplanId - Floorplan ObjectId
 * @returns {Object|null} Floorplan subdocument or null
 */
buildingSchema.methods.getFloorplan = function(floorplanId) {
    return this.floorplans.id(floorplanId);
};

// Method to update floorplan
/**
 * @param {mongoose.Types.ObjectId} floorplanId - Floorplan ObjectId
 * @param {Object} updateData - Data to update
 * @param {boolean} updateUnits - Whether to update associated units
 * @returns {Promise<Object>} Updated floorplan
 */
buildingSchema.methods.updateFloorplan = async function(floorplanId, updateData, updateUnits = false) {
    const floorplan = this.floorplans.id(floorplanId);
    if (!floorplan) {
        throw new Error('Floorplan not found');
    }
    
    Object.assign(floorplan, updateData, { updatedAt: new Date() });
    await this.save();
    
    // Optionally update all units with this floorplan
    if (updateUnits) {
        const Unit = mongoose.model('Unit');
        const updateFields = {};
        
        // Always set floorplanId when updating units
        updateFields.floorplanId = floorplanId;
        
        if (updateData.name) {
            updateFields.unitType = updateData.name;
            updateFields.floorplan = updateData.name;
        } else {
            // If name not in updateData, use current floorplan name
            updateFields.unitType = floorplan.name;
            updateFields.floorplan = floorplan.name;
        }
        if (updateData.bedrooms !== undefined) {
            updateFields.bedrooms = updateData.bedrooms;
        }
        if (updateData.bathrooms !== undefined) {
            updateFields.bathrooms = updateData.bathrooms;
        }
        if (updateData.averageSquareFootage !== undefined) {
            updateFields.squareFootage = updateData.averageSquareFootage;
            updateFields.size = updateData.averageSquareFootage;
        }
        if (updateData.parkingSpaces !== undefined) {
            updateFields.parkingSpaces = updateData.parkingSpaces;
        }
        if (updateData.balcony !== undefined) {
            updateFields.balcony = updateData.balcony;
        }
        if (updateData.furnished !== undefined) {
            updateFields.furnished = updateData.furnished;
        }
        
        // Find units that should belong to this floorplan
        // Strategy 1: Units with unitType matching floorplan name (case-insensitive)
        // Strategy 2: Units that already have this floorplanId
        const floorplanName = updateData.name || floorplan.name;
        const floorplanNameEscaped = floorplanName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const unitsToUpdate = await Unit.find({
            building: this._id,
            $or: [
                { unitType: { $regex: new RegExp(`^${floorplanNameEscaped}$`, 'i') } },
                { floorplanId: floorplanId }
            ]
        });
        
        // Update these units to have correct unitType and floorplanId
        if (unitsToUpdate.length > 0) {
            await Unit.updateMany(
                { _id: { $in: unitsToUpdate.map(u => u._id) } },
                { $set: updateFields }
            );
        }
    }
    
    return floorplan;
};

// Method to delete floorplan
/**
 * @param {mongoose.Types.ObjectId} floorplanId - Floorplan ObjectId
 * @param {boolean} force - Force delete even if units exist
 * @returns {Promise<boolean>} True if deleted
 */
buildingSchema.methods.deleteFloorplan = async function(floorplanId, force = false) {
    const floorplan = this.floorplans.id(floorplanId);
    if (!floorplan) {
        throw new Error('Floorplan not found');
    }
    
    // Check if any units are using this floorplan
    const Unit = mongoose.model('Unit');
    const unitsWithFloorplan = await Unit.countDocuments({
        building: this._id,
        floorplanId: floorplanId
    });
    
    if (unitsWithFloorplan > 0 && !force) {
        throw new Error(`Cannot delete floorplan: ${unitsWithFloorplan} unit(s) are using this floorplan. Set force=true to delete anyway.`);
    }
    
    // If force delete, remove floorplanId from units
    if (force && unitsWithFloorplan > 0) {
        await Unit.updateMany(
            { building: this._id, floorplanId: floorplanId },
            { $unset: { floorplanId: '' } }
        );
    }
    
    // Remove the floorplan from the array using pull()
    this.floorplans.pull(floorplanId);
    await this.save();
    
    return true;
};

module.exports = mongoose.model('Building', buildingSchema); 