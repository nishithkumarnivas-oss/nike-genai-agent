const mongoose = require('mongoose');

// Rent roll transaction schema
const rentRollTransactionSchema = new mongoose.Schema({
    transCode: { type: String, required: true }, // e.g., "RENT", "Amenity Access Fee", "CARPORT"
    leaseRent: { type: Number, default: 0 }, // Amount specified in lease
    otherChargesCredits: { type: Number, default: 0 }, // Additional charges or credits
    totalBilling: { type: Number, default: 0 }, // Total amount billed
    description: { type: String }, // Description of the transaction
    createdAt: { type: Date, default: Date.now }
});

// Historical lease schema
const leaseHistorySchema = new mongoose.Schema({
    startDate: { type: Date, required: true },
    endDate: { type: Date },
    tenantName: { type: String, required: true },
    leaseId: { type: String },
    reshId: { type: String },
    
    // Contact information
    phoneNumber: { type: String },
    email: { type: String },
    
    // Move-in/out dates
    moveInDate: { type: Date },
    moveOutDate: { type: Date },
    
    // Lease terms
    marketRent: { type: Number }, // Market rent plus additional charges
    additionalCharges: { type: Number, default: 0 },
    totalMonthlyBilling: { type: Number }, // Total monthly billing amount
    
    // Rent roll transactions
    rentRollTransactions: [rentRollTransactionSchema],
    
    // Financial information
    rentAmount: { type: Number, required: true },
    rentCurrency: { type: String, default: 'USD' },
    rentFrequency: {
        type: String,
        enum: ['Monthly', 'Quarterly', 'Annually'],
        default: 'Monthly'
    },
    securityDeposit: { type: Number },
    depositOnHand: { type: Number, default: 0 },
    outstandingBalance: { type: Number, default: 0 },
    
    // Lease classification
    leaseType: {
        type: String,
        enum: ['Residential', 'Commercial', 'Industrial', 'Other']
    },
    status: {
        type: String,
        enum: ['Active', 'Expired', 'Terminated', 'Renewed'],
        default: 'Active'
    },
    
    // Documents
    documents: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Document'
    }],
    notes: { type: String },
    
    // Compliance/Income information (for historical compliance exports)
    tenantId: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'Tenant' 
    }, // Reference to the tenant
    tenantIncome: { type: Number }, // Monthly income of tenant during this lease
    tenantAnnualIncome: { type: Number }, // Annual income of tenant during this lease
    householdSize: { type: Number }, // Household size during this lease
    amiBucket: { type: String }, // AMI category calculated (e.g., "Extremely Low (ELI)  30%")
    
    createdAt: { type: Date, default: Date.now }
});

// Historical occupancy snapshot schema
const occupancySnapshotSchema = new mongoose.Schema({
    snapshotDate: { type: Date, required: true },
    occupancyStatus: {
        type: String,
        enum: ['Occupied', 'Vacant', 'Under Renovation', 'Reserved', 'Delinquent', 'Occupied-NTV', 'Vacant-Leased', 'Occupied-NTVL'],
        required: true
    },
    tenantName: { type: String },
    leaseId: { type: String },
    reshId: { type: String },
    
    // Contact information
    phoneNumber: { type: String },
    email: { type: String },
    
    // Move-in/out dates
    moveInDate: { type: Date },
    moveOutDate: { type: Date },
    tenantStatus: {
        type: String,
        enum: ['Current resident', 'Former resident', 'Prospective resident'],
        default: 'Current resident'
    },
    
    // Financial information
    rentAmount: { type: Number },
    rentCurrency: { type: String, default: 'USD' },
    rentFrequency: {
        type: String,
        enum: ['Monthly', 'Quarterly', 'Annually'],
        default: 'Monthly'
    },
    marketRent: { type: Number }, // Market rent plus additional charges
    additionalCharges: { type: Number, default: 0 },
    totalMonthlyBilling: { type: Number },
    depositOnHand: { type: Number, default: 0 },
    outstandingBalance: { type: Number, default: 0 },
    
    // Rent roll transactions for this snapshot
    rentRollTransactions: [rentRollTransactionSchema],
    
    // Detailed financial breakdown
    charges: {
        rent: {
            totalPrepaid: { type: Number, default: 0 },
            totalDelinquent: { type: Number, default: 0 },
            netBalance: { type: Number, default: 0 }
        },
        gasIncome: {
            totalPrepaid: { type: Number, default: 0 },
            totalDelinquent: { type: Number, default: 0 },
            netBalance: { type: Number, default: 0 }
        },
        trash: {
            totalPrepaid: { type: Number, default: 0 },
            totalDelinquent: { type: Number, default: 0 },
            netBalance: { type: Number, default: 0 }
        },
        utilityBillingFee: {
            totalPrepaid: { type: Number, default: 0 },
            totalDelinquent: { type: Number, default: 0 },
            netBalance: { type: Number, default: 0 }
        },
        water: {
            totalPrepaid: { type: Number, default: 0 },
            totalDelinquent: { type: Number, default: 0 },
            netBalance: { type: Number, default: 0 }
        },
        amenityAccessFee: {
            totalPrepaid: { type: Number, default: 0 },
            totalDelinquent: { type: Number, default: 0 },
            netBalance: { type: Number, default: 0 }
        },
        pestFee: {
            totalPrepaid: { type: Number, default: 0 },
            totalDelinquent: { type: Number, default: 0 },
            netBalance: { type: Number, default: 0 }
        }
    },
    
    // Summary totals
    totalPrepaid: { type: Number, default: 0 },
    totalDelinquent: { type: Number, default: 0 },
    netBalance: { type: Number, default: 0 },
    
    // Aging breakdown
    current: { type: Number, default: 0 },
    thirtyDays: { type: Number, default: 0 },
    sixtyDays: { type: Number, default: 0 },
    ninetyPlusDays: { type: Number, default: 0 },
    
    // Additional financial information
    prorateCredit: { type: Number, default: 0 },
    depositsHeld: { type: Number, default: 0 },
    outstandingDeposit: { type: Number, default: 0 },
    
    // Payment tracking
    latePayments: { type: Number, default: 0 },
    nsfPayments: { type: Number, default: 0 },
    
    // Dates
    lastRentPaymentDate: { type: Date },
    nextRentDueDate: { type: Date },
    
    // Household information
    householdCount: { type: Number, default: 0 }, // Number of people living in unit
    
    // Unit characteristics from rent roll (for mismatch detection with building characteristics)
    squareFootage: { type: Number }, // Square footage from rent roll (stored in snapshot)
    unitSize: { type: Number }, // Alternative size field from rent roll
    size: { type: Number }, // Another size field variant from rent roll
    // Compliance/Income information (for historical compliance exports)
    tenantId: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'Tenant' 
    }, // Reference to the tenant
    tenantIncome: { type: Number }, // Monthly income of tenant at snapshot date
    tenantAnnualIncome: { type: Number }, // Annual income of tenant at snapshot date
    amiBucket: { type: String }, // AMI category calculated (e.g., "Extremely Low (ELI)  30%")
    
    // Comments
    comments: { type: String },
    leasingAgent: { type: String },
    
    createdAt: { type: Date, default: Date.now }
});

// Delinquency tracking schema
const delinquencySchema = new mongoose.Schema({
    startDate: { type: Date, required: true },
    endDate: { type: Date },
    
    // Tenant information
    tenantName: { type: String, required: true },
    leaseId: { type: String },
    reshId: { type: String },
    
    // Contact information
    phoneNumber: { type: String },
    email: { type: String },
    
    // Move-in/out dates
    moveInDate: { type: Date },
    moveOutDate: { type: Date },
    status: {
        type: String,
        enum: ['Current resident', 'Former resident', 'Prospective resident', 'NTV'],
        default: 'Current resident'
    },
    
    // Detailed financial breakdown by category
    charges: {
        rent: {
            totalPrepaid: { type: Number, default: 0 },
            totalDelinquent: { type: Number, default: 0 },
            netBalance: { type: Number, default: 0 },
            current: { type: Number, default: 0 },
            thirtyDays: { type: Number, default: 0 },
            sixtyDays: { type: Number, default: 0 },
            ninetyPlusDays: { type: Number, default: 0 }
        },
        gasIncome: {
            totalPrepaid: { type: Number, default: 0 },
            totalDelinquent: { type: Number, default: 0 },
            netBalance: { type: Number, default: 0 },
            current: { type: Number, default: 0 },
            thirtyDays: { type: Number, default: 0 },
            sixtyDays: { type: Number, default: 0 },
            ninetyPlusDays: { type: Number, default: 0 }
        },
        trash: {
            totalPrepaid: { type: Number, default: 0 },
            totalDelinquent: { type: Number, default: 0 },
            netBalance: { type: Number, default: 0 },
            current: { type: Number, default: 0 },
            thirtyDays: { type: Number, default: 0 },
            sixtyDays: { type: Number, default: 0 },
            ninetyPlusDays: { type: Number, default: 0 }
        },
        utilityBillingFee: {
            totalPrepaid: { type: Number, default: 0 },
            totalDelinquent: { type: Number, default: 0 },
            netBalance: { type: Number, default: 0 },
            current: { type: Number, default: 0 },
            thirtyDays: { type: Number, default: 0 },
            sixtyDays: { type: Number, default: 0 },
            ninetyPlusDays: { type: Number, default: 0 }
        },
        water: {
            totalPrepaid: { type: Number, default: 0 },
            totalDelinquent: { type: Number, default: 0 },
            netBalance: { type: Number, default: 0 },
            current: { type: Number, default: 0 },
            thirtyDays: { type: Number, default: 0 },
            sixtyDays: { type: Number, default: 0 },
            ninetyPlusDays: { type: Number, default: 0 }
        },
        amenityAccessFee: {
            totalPrepaid: { type: Number, default: 0 },
            totalDelinquent: { type: Number, default: 0 },
            netBalance: { type: Number, default: 0 },
            current: { type: Number, default: 0 },
            thirtyDays: { type: Number, default: 0 },
            sixtyDays: { type: Number, default: 0 },
            ninetyPlusDays: { type: Number, default: 0 }
        },
        pestFee: {
            totalPrepaid: { type: Number, default: 0 },
            totalDelinquent: { type: Number, default: 0 },
            netBalance: { type: Number, default: 0 },
            current: { type: Number, default: 0 },
            thirtyDays: { type: Number, default: 0 },
            sixtyDays: { type: Number, default: 0 },
            ninetyPlusDays: { type: Number, default: 0 }
        }
    },
    
    // Summary totals
    totalPrepaid: { type: Number, default: 0 },
    totalDelinquent: { type: Number, default: 0 },
    netBalance: { type: Number, default: 0 },
    
    // Aging summary
    current: { type: Number, default: 0 },
    thirtyDays: { type: Number, default: 0 },
    sixtyDays: { type: Number, default: 0 },
    ninetyPlusDays: { type: Number, default: 0 },
    
    // Additional financial information
    prorateCredit: { type: Number, default: 0 },
    depositsHeld: { type: Number, default: 0 },
    outstandingDeposit: { type: Number, default: 0 },
    
    // Payment tracking
    latePayments: { type: Number, default: 0 },
    nsfPayments: { type: Number, default: 0 },
    
    // Delinquency status
    delinquencyStatus: {
        type: String,
        enum: ['Active', 'Resolved', 'Written Off', 'Payment Plan'],
        default: 'Active'
    },
    
    // Payment plan information
    paymentPlan: {
        hasPaymentPlan: { type: Boolean, default: false },
        monthlyAmount: { type: Number },
        startDate: { type: Date },
        endDate: { type: Date },
        totalAmount: { type: Number },
        remainingAmount: { type: Number }
    },
    
    // Comments and notes
    commentDate: { type: Date },
    comments: { type: String },
    leasingAgent: { type: String },
    
    // Documents
    documents: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Document'
    }],
    
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

const unitSchema = new mongoose.Schema({
    building: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Building',
        required: true
    },
    unitNumber: { type: String, required: true },
    unitType: { type: String, required: true }, // Free text instead of enum
    floorplan: { type: String }, // e.g., "20207A4" - kept for backward compatibility
    floorplanId: {
        type: mongoose.Schema.Types.ObjectId,
        index: true
    }, // Reference to floorplan in Building.floorplans array
    unitDesignation: { type: String }, // e.g., "N/A"
    squareFootage: { type: Number }, // e.g., 775
    
    // Current state (latest snapshot)
    currentOccupancyStatus: {
        type: String,
        enum: ['Occupied', 'Vacant', 'Under Renovation', 'Reserved', 'Delinquent', 'Occupied-NTV', 'Vacant-Leased', 'Occupied-NTVL'],
        default: 'Vacant'
    },
    currentTenantName: { type: String },
    currentTenantAnnualIncome: { type: Number, default: 0 },
    currentTenantMonthlyIncome: { type: Number, default: 0 },
    currentLeaseId: { type: String },
    currentReshId: { type: String },
    currentPhoneNumber: { type: String },
    currentEmail: { type: String },
    currentTenant: { type: mongoose.Schema.Types.ObjectId, ref: 'Tenant' },
    currentMoveInDate: { type: Date },
    currentMoveOutDate: { type: Date },
    currentTenantStatus: {
        type: String,
        enum: ['Current resident', 'Former resident', 'Prospective resident'],
        default: 'Current resident'
    },
    // Reference to current active lease - lease financial data should be read from Lease model
    currentLease: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'Lease',
        index: true
    },
    // DEPRECATED: These fields are being migrated to Lease model
    // TODO: Remove these fields after migration is complete
    // Use currentLease reference and read from Lease model instead
    currentLeaseId: { type: String }, // DEPRECATED: Use Lease.leaseId
    currentReshId: { type: String }, // DEPRECATED: Use Lease.reshId
    currentRentAmount: { type: Number }, // DEPRECATED: Use Lease.baseRent
    currentRentCurrency: { type: String, default: 'USD' }, // DEPRECATED: Use Lease.rentCurrency
    currentRentFrequency: {
        type: String,
        enum: ['Monthly', 'Quarterly', 'Annually'],
        default: 'Monthly'
    }, // DEPRECATED: Use Lease.rentFrequency
    currentMarketRent: { type: Number }, // DEPRECATED: Use Lease.marketRent
    currentAdditionalCharges: { type: Number, default: 0 }, // DEPRECATED: Use Lease.additionalCharges
    currentTotalMonthlyBilling: { type: Number }, // DEPRECATED: Use Lease.totalMonthlyBilling
    currentDepositOnHand: { type: Number, default: 0 }, // DEPRECATED: Use Lease.depositOnHand
    currentRequiredDeposit: { type: Number, default: 0 }, // DEPRECATED: Use Lease.securityDepositRequired
    currentOutstandingBalance: { type: Number, default: 0 }, // DEPRECATED: Use Lease.outstandingBalance
    currentHouseholdCount: { type: Number, default: 0 },
    currentTotalDelinquent: { type: Number, default: 0 },
    currentNetBalance: { type: Number, default: 0 },
    currentLatePayments: { type: Number, default: 0 },
    currentNsfPayments: { type: Number, default: 0 },
    
    // Size information
    size: { type: Number, required: true },
    sizeUnit: {
        type: String,
        enum: ['sqm', 'm2', 'sqft'],
        required: true
    },
    
    // Unit characteristics
    bedrooms: { type: Number },
    bathrooms: { type: Number },
    parkingSpaces: { type: Number },
    balcony: { type: Boolean, default: false },
    furnished: { type: Boolean, default: false },
    
    // Historical data (LEGACY - prefer using dedicated models like Lease, RentRollSnapshot, etc.)
    // TODO: Stop writing to these fields once all services are migrated, then remove them in a future migration.
    leaseHistory: [leaseHistorySchema],        // DEPRECATED: use Lease model instead
    occupancySnapshots: [occupancySnapshotSchema], // DEPRECATED: consider dedicated snapshot models
    delinquencyHistory: [delinquencySchema],   // DEPRECATED: consider dedicated delinquency models
    
    // Current rent roll transactions (PMS view; will be migrated to RentRollSnapshot + per-fee storage)
    currentRentRollTransactions: [rentRollTransactionSchema],
    
    // Documents
    documents: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Document'
    }],
    
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

// Indexes for better query performance
unitSchema.index({ building: 1 });
unitSchema.index({ unitNumber: 1 });
unitSchema.index({ unitType: 1 });
unitSchema.index({ floorplanId: 1 }); // Index for floorplan queries
unitSchema.index({ currentOccupancyStatus: 1 });
unitSchema.index({ 'occupancySnapshots.snapshotDate': 1 });
unitSchema.index({ 'leaseHistory.startDate': 1 });
unitSchema.index({ 'delinquencyHistory.startDate': 1 });

// Method to get occupancy snapshot for a specific date
unitSchema.methods.getOccupancySnapshot = function(date) {
    if (!this.occupancySnapshots || this.occupancySnapshots.length === 0) {
        return null;
    }
    
    const snapshots = this.occupancySnapshots
        .filter(snapshot => snapshot.snapshotDate <= date)
        .sort((a, b) => b.snapshotDate - a.snapshotDate);
    
    return snapshots.length > 0 ? snapshots[0] : null;
};

// Method to get building snapshot for a specific date
unitSchema.methods.getBuildingSnapshot = function(date) {
    return {
        unitNumber: this.unitNumber,
        unitType: this.unitType,
        occupancyStatus: this.getOccupancySnapshot(date)?.occupancyStatus || 'Vacant',
        tenantName: this.getOccupancySnapshot(date)?.tenantName,
        rentAmount: this.getOccupancySnapshot(date)?.rentAmount,
        householdCount: this.getOccupancySnapshot(date)?.householdCount || 0,
        daysDelinquent: this.getOccupancySnapshot(date)?.daysDelinquent || 0,
        delinquencyAmount: this.getOccupancySnapshot(date)?.delinquencyAmount || 0
    };
};

module.exports = mongoose.model('Unit', unitSchema); 