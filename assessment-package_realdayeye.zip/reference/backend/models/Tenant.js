const mongoose = require('mongoose');

// Income tracking schema by year
const tenantIncomeSchema = new mongoose.Schema({
    year: {
        type: Number,
        required: true
    },
    annualIncome: {
        type: Number,
        required: true,
        default: 0
    },
    monthlyIncome: {
        type: Number,
        default: 0
    },
    incomeSource: {
        type: String,
        enum: ['Employment', 'Self-Employment', 'Social Security', 'Disability', 'Pension', 'Investment', 'Other'],
        default: 'Employment'
    },
    employmentStatus: {
        type: String,
        enum: ['Full-Time', 'Part-Time', 'Unemployed', 'Retired', 'Student', 'Other'],
        default: 'Full-Time'
    },
    employer: {
        type: String,
        trim: true
    },
    jobTitle: {
        type: String,
        trim: true
    },
    incomeVerified: {
        type: Boolean,
        default: false
    },
    verificationDate: {
        type: Date
    },
    verificationMethod: {
        type: String,
        enum: ['Pay Stub', 'Tax Return', 'Bank Statement', 'Employer Verification', 'Other'],
        default: 'Pay Stub'
    },
    notes: {
        type: String,
        trim: true
    }
}, {
    timestamps: true
});

// Household member schema
const householdMemberSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    relationship: {
        type: String,
        enum: ['Spouse', 'Child', 'Parent', 'Sibling', 'Other'],
        required: true
    },
    dateOfBirth: {
        type: Date
    },
    socialSecurityNumber: {
        type: String,
        trim: true
    },
    isStudent: {
        type: Boolean,
        default: false
    },
    isDisabled: {
        type: Boolean,
        default: false
    },
    isFullTimeStudent: {
        type: Boolean,
        default: false
    },
    annualIncome: {
        type: Number,
        default: 0
    },
    employmentStatus: {
        type: String,
        enum: ['Full-Time', 'Part-Time', 'Unemployed', 'Retired', 'Student', 'Other'],
        default: 'Unemployed'
    },
    employer: {
        type: String,
        trim: true
    },
    jobTitle: {
        type: String,
        trim: true
    }
}, {
    timestamps: true
});

// Tenant schema
const tenantSchema = new mongoose.Schema({
    // Basic identification
    reshId: {
        type: String,
        required: true,
        // NOTE: unique: true removed - using compound unique index (reshId, building) instead
        // This allows same reshId in different buildings while preventing duplicates within same building
        trim: true
    },
    leaseId: {
        type: String,
        trim: true
    },
    
    // Personal information
    firstName: {
        type: String,
        required: true,
        trim: true
    },
    lastName: {
        type: String,
        required: true,
        trim: true
    },
    middleName: {
        type: String,
        trim: true
    },
    dateOfBirth: {
        type: Date
    },
    socialSecurityNumber: {
        type: String,
        trim: true
    },
    
    // Contact information
    email: {
        type: String,
        trim: true,
        lowercase: true
    },
    phoneNumber: {
        type: String,
        trim: true
    },
    alternatePhone: {
        type: String,
        trim: true
    },
    
    // Address information
    currentAddress: {
        street: { type: String, trim: true },
        city: { type: String, trim: true },
        state: { type: String, trim: true },
        zipCode: { type: String, trim: true },
        country: { type: String, trim: true, default: 'USA' }
    },
    
    // Emergency contact
    emergencyContact: {
        name: { type: String, trim: true },
        relationship: { type: String, trim: true },
        phoneNumber: { type: String, trim: true },
        email: { type: String, trim: true }
    },
    
    // Income and employment
    currentAnnualIncome: {
        type: Number,
        default: 0
    },
    currentMonthlyIncome: {
        type: Number,
        default: 0
    },
    incomeSource: {
        type: String,
        enum: ['Employment', 'Self-Employment', 'Social Security', 'Disability', 'Pension', 'Investment', 'Other'],
        default: 'Employment'
    },
    employmentStatus: {
        type: String,
        enum: ['Full-Time', 'Part-Time', 'Unemployed', 'Retired', 'Student', 'Other'],
        default: 'Full-Time'
    },
    employer: {
        type: String,
        trim: true
    },
    jobTitle: {
        type: String,
        trim: true
    },
    employerPhone: {
        type: String,
        trim: true
    },
    employerAddress: {
        street: { type: String, trim: true },
        city: { type: String, trim: true },
        state: { type: String, trim: true },
        zipCode: { type: String, trim: true }
    },
    
    // Household information
    householdSize: {
        type: Number,
        required: true,
        default: 1
    },
    householdMembers: [householdMemberSchema],
    totalHouseholdIncome: {
        type: Number,
        default: 0
    },
    
    // Income history by year
    incomeHistory: [tenantIncomeSchema],
    
    // AMI qualification tracking
    amiQualification: {
        currentAmiLevel: {
            type: String,
            enum: ['Extremely Low (ELI)', 'Very Low (VLI)', 'Low', 'LIHTC', 'Market Rate'],
            default: 'Market Rate'
        },
        currentAmiPercentage: {
            type: Number,
            default: 100
        },
        qualifiesForAmi: {
            type: Boolean,
            default: false
        },
        lastQualificationCheck: {
            type: Date
        },
        qualificationNotes: {
            type: String,
            trim: true
        }
    },
    
    // Application and screening
    applicationDate: {
        type: Date
    },
    screeningStatus: {
        type: String,
        enum: ['Pending', 'Approved', 'Denied', 'Conditional'],
        default: 'Pending'
    },
    screeningNotes: {
        type: String,
        trim: true
    },
    backgroundCheckCompleted: {
        type: Boolean,
        default: false
    },
    creditCheckCompleted: {
        type: Boolean,
        default: false
    },
    incomeVerificationCompleted: {
        type: Boolean,
        default: false
    },
    
    // Documents
    documents: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Document'
    }],
    
    // Status
    status: {
        type: String,
        enum: ['Active', 'Inactive', 'Former', 'Prospective'],
        default: 'Active'
    },

    // Optional building association (used when tenants are created from a specific building's upload workflow)
    building: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Building',
        index: true
    },

    // When lease extraction finds a tenant but cannot match the unit to this building's units,
    // we still create the tenant record and mark it as unassigned so it can be mapped later.
    unassignedUnit: {
        type: Boolean,
        default: false
    },
    /**
     * Original unit identifier coming from uploaded files (lease, rent roll, etc.)
     * when we could not match it to an actual Unit in this building.
     * Example: "2-12-1139", "1139A", etc.
     * This is important for later reconciliation and manual mapping.
     */
    unassignedUnitIdentifier: {
        type: String,
        trim: true
    },
    
    // Metadata
    createdBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    updatedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    notes: {
        type: String,
        trim: true
    }
}, {
    timestamps: true
});

// Indexes for efficient querying
tenantSchema.index({ reshId: 1 }); // Non-unique index for querying
// CRITICAL: Compound unique index on (reshId, building) - allows same reshId in different buildings
// but prevents duplicate reshId within the same building
// sparse: true means this index only applies when building field exists (not null)
tenantSchema.index({ reshId: 1, building: 1 }, { unique: true, sparse: true });
tenantSchema.index({ leaseId: 1 });
tenantSchema.index({ lastName: 1, firstName: 1 });
tenantSchema.index({ 'currentAddress.city': 1, 'currentAddress.state': 1 });
tenantSchema.index({ currentAnnualIncome: 1 });
tenantSchema.index({ 'amiQualification.currentAmiLevel': 1 });
tenantSchema.index({ status: 1 });

// Virtual for full name
tenantSchema.virtual('fullName').get(function() {
    return `${this.firstName} ${this.lastName}`.trim();
});

// Virtual for display name
tenantSchema.virtual('displayName').get(function() {
    return `${this.firstName} ${this.lastName} (${this.reshId})`.trim();
});

// Virtual for income (alias to currentAnnualIncome for compatibility with Building.js)
// This ensures unit.currentTenant.income works when tenant is populated
tenantSchema.virtual('income').get(function() {
    return this.currentAnnualIncome || 0;
});

// Ensure virtuals are included when converting to JSON
tenantSchema.set('toJSON', { virtuals: true });
tenantSchema.set('toObject', { virtuals: true });

// Method to get current income for a specific year
tenantSchema.methods.getIncomeForYear = function(year) {
    const incomeRecord = this.incomeHistory.find(record => record.year === year);
    return incomeRecord || null;
};

// Method to add or update income for a year
tenantSchema.methods.setIncomeForYear = function(year, annualIncome, monthlyIncome = null) {
    const existingRecord = this.incomeHistory.find(record => record.year === year);
    
    if (existingRecord) {
        existingRecord.annualIncome = annualIncome;
        if (monthlyIncome !== null) {
            existingRecord.monthlyIncome = monthlyIncome;
        }
    } else {
        this.incomeHistory.push({
            year: year,
            annualIncome: annualIncome,
            monthlyIncome: monthlyIncome || (annualIncome / 12)
        });
    }
    
    // Update current income if this is the current year
    const currentYear = new Date().getFullYear();
    if (year === currentYear) {
        this.currentAnnualIncome = annualIncome;
        this.currentMonthlyIncome = monthlyIncome || (annualIncome / 12);
    }
};

// Method to calculate total household income
tenantSchema.methods.calculateTotalHouseholdIncome = function() {
    let total = this.currentAnnualIncome || 0;
    
    // Add income from household members
    this.householdMembers.forEach(member => {
        total += member.annualIncome || 0;
    });
    
    this.totalHouseholdIncome = total;
    return total;
};

// Method to check AMI qualification
tenantSchema.methods.checkAmiQualification = function(amiData) {
    if (!amiData) return false;
    
    const totalIncome = this.calculateTotalHouseholdIncome();
    const householdSize = this.householdSize;
    
    // Get income limit for this household size
    const incomeLimit = amiData.getIncomeLimit(householdSize);
    
    const qualifies = totalIncome <= incomeLimit;
    
    // Update qualification status
    this.amiQualification = {
        currentAmiLevel: amiData.name,
        currentAmiPercentage: amiData.incomePercentage,
        qualifiesForAmi: qualifies,
        lastQualificationCheck: new Date(),
        qualificationNotes: qualifies 
            ? `Qualifies for ${amiData.name} (${amiData.incomePercentage}%)` 
            : `Income $${totalIncome.toLocaleString()} exceeds limit $${incomeLimit.toLocaleString()}`
    };
    
    return qualifies;
};

// Static method to find tenants by AMI level
tenantSchema.statics.findByAmiLevel = function(amiLevel, buildingId = null) {
    const query = {
        'amiQualification.currentAmiLevel': amiLevel
    };
    // CRITICAL: If buildingId is provided, scope query to that building only
    if (buildingId) {
        query.building = buildingId;
    }
    return this.find(query);
};

// Static method to find tenants by income range
tenantSchema.statics.findByIncomeRange = function(minIncome, maxIncome, buildingId = null) {
    const query = {
        currentAnnualIncome: {
            $gte: minIncome,
            $lte: maxIncome
        }
    };
    // CRITICAL: If buildingId is provided, scope query to that building only
    if (buildingId) {
        query.building = buildingId;
    }
    return this.find(query);
};

// Static method to find tenants by household size
tenantSchema.statics.findByHouseholdSize = function(size) {
    return this.find({
        householdSize: size
    });
};

// Pre-save middleware to update household size
tenantSchema.pre('save', function(next) {
    // Only recalculate household size if householdMembers array was modified
    // This preserves manually set householdSize values (e.g., from income uploads)
    // when householdMembers array is empty or not populated
    if (this.isModified('householdMembers')) {
        // Update household size based on household members + primary tenant
        this.householdSize = (this.householdMembers?.length || 0) + 1;
    } else if (!this.householdSize || this.householdSize === 0) {
        // Only set default if householdSize is not set and householdMembers wasn't modified
        // This handles the case where householdSize is explicitly set to 0 or null
        this.householdSize = (this.householdMembers?.length || 0) + 1;
    }
    // If householdSize is already set and householdMembers wasn't modified, preserve the existing value
    
    // Calculate total household income
    this.calculateTotalHouseholdIncome();
    
    next();
});

module.exports = mongoose.model('Tenant', tenantSchema); 