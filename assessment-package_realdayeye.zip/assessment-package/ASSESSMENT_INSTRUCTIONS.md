# Technical Assessment - RealComply Platform

## Welcome!

Thank you for taking the time to complete this technical assessment. This assessment is designed to evaluate your skills in database design, TypeScript architecture, compliance domain knowledge, AI integration, and modern development practices.

**Time Estimate:** ~5 hours

**Assessment Focus Areas:**
1. Database Design (MongoDB)
2. TypeScript Code Organization & Design Patterns
3. Texas-Specific Compliance Implementation
4. AI Data Extraction
5. AI-Assisted Programming

---

## Getting Started

1. **Read this entire document** before starting
2. **Review the project structure** - familiarize yourself with the codebase
3. **Set up your environment** (see SETUP_GUIDE.md)
4. **Complete all tasks** in order
5. **Document your work** in ASSESSMENT_SUBMISSION.md

---

## Assessment Structure

### Time Allocation (~5 hours total)

- **Task 1: Database Design** - 1 hour
- **Task 2: TypeScript & Design Patterns** - 1-1.5 hours  
- **Task 3: Texas Compliance Implementation** - 1.5 hours
- **Task 4: AI Data Extraction** - 0.75-1 hour
- **Task 5: AI-Assisted Programming** - 0.5 hours
- **Documentation & Submission** - 0.5 hours

---

## Important Notes

### What You CAN Use
- ✅ **AI coding assistants** (GitHub Copilot, ChatGPT, Cursor, etc.) - **ENCOURAGED**
- ✅ Google, Stack Overflow, documentation
- ✅ Any npm packages you need
- ✅ Any approach that follows project patterns

### What You CANNOT Do
- ❌ Ask for help with implementation (clarifying questions about requirements are OK)
- ❌ Copy code from other projects without understanding
- ❌ Submit incomplete work without explanation

### Questions?
Feel free to ask clarifying questions about:
- Requirements that are unclear
- Existing codebase patterns
- Business logic you don't understand
- Texas compliance regulations
- Technical constraints

---

## Submission

1. **Complete all tasks** in the provided workspace structure
2. **Fill out ASSESSMENT_SUBMISSION.md** (template provided) - rename it to `ASSESSMENT_SUBMISSION.md`
3. **Create a zip file** containing:
   - Your `backend/` directory with all implementation files
   - Your `typescript-services/` directory with all implementation files
   - Your `ASSESSMENT_SUBMISSION.md` file
4. **Submit the zip file** to your contact
5. **Notify your contact** when complete

---

## Evaluation

You will be evaluated on:
- **Technical Skills** (40%): Database design, TypeScript, compliance knowledge
- **Code Quality** (25%): Architecture, code style, documentation
- **Problem Solving** (20%): Compliance logic, edge cases
- **AI Integration** (10%): AI extraction, AI-assisted programming
- **Communication** (5%): Documentation quality

**Scoring:**
- 90-100 points: Exceptional - Strong hire
- 75-89 points: Good - Solid hire with mentoring
- 60-74 points: Acceptable - Hire with significant mentoring
- Below 60: Not recommended

---

## Good Luck!

Take your time, write clean code, and document your decisions. We're looking for quality over speed.
