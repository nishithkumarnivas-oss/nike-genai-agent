# RealComply Technical Assessment Package

This package contains all the materials you need to complete the technical assessment for the RealComply platform.

## 📦 Package Contents

1. **ASSESSMENT_INSTRUCTIONS.md** - Start here! Overview and getting started guide
2. **ASSESSMENT_TASKS.md** - Complete task descriptions and requirements
3. **SETUP_GUIDE.md** - Environment setup and configuration instructions
4. **ASSESSMENT_SUBMISSION_TEMPLATE.md** - Template for your submission document
5. **QUICK_REFERENCE.md** - Quick reference for project structure and common patterns
6. **TEXAS_COMPLIANCE_QUICK_REFERENCE.md** - Quick reference for Texas compliance rules (Task 3)
7. **README.md** - This file

### Additional Resources

- **sample-data/** - Sample JSON files (building, AMI, units, tenants) for testing your implementations
- **typescript-services-template/** - Pre-configured TypeScript project template for Task 2
- **reference/** - Reference code examples demonstrating project patterns

## 🚀 Getting Started

1. **Read ASSESSMENT_INSTRUCTIONS.md first** - This gives you the overview
2. **Follow SETUP_GUIDE.md** - Set up your development environment
3. **Review ASSESSMENT_TASKS.md** - Understand all the tasks
4. **Use QUICK_REFERENCE.md** - As a reference while coding
5. **Fill out ASSESSMENT_SUBMISSION_TEMPLATE.md** - Document your work

## ⏱️ Time Estimate

**Total Time: ~5 hours**

- Task 1: Database Design - 1 hour
- Task 2: TypeScript & Design Patterns - 1-1.5 hours
- Task 3: Texas Compliance - 1.5 hours
- Task 4: AI Data Extraction - 0.75-1 hour
- Task 5: AI-Assisted Programming - 0.5 hours
- Documentation - 0.5 hours

## 📋 Assessment Focus Areas

1. **Database Design** - MongoDB schema design and data modeling
2. **TypeScript Architecture** - Code organization, design patterns
3. **Texas Compliance** - Understanding and implementing Texas regulations
4. **AI Data Extraction** - Working with Azure AI services
5. **AI-Assisted Programming** - Effective use of AI coding assistants

## ✅ Checklist

Before starting:
- [ ] Read ASSESSMENT_INSTRUCTIONS.md
- [ ] Read ASSESSMENT_TASKS.md
- [ ] Set up environment (SETUP_GUIDE.md)
- [ ] Review reference files in `reference/` directory
- [ ] Review TEXAS_COMPLIANCE_QUICK_REFERENCE.md (for Task 3)
- [ ] Review sample data in `sample-data/` directory (for Tasks 1 and 3)
- [ ] Set up TypeScript template if doing Task 2 (see SETUP_GUIDE.md)
- [ ] Have Azure credentials (if provided)
- [ ] Have MongoDB connection string (if provided)

## 📝 Submission

1. Complete all tasks in the workspace directories
2. Fill out ASSESSMENT_SUBMISSION.md (use template, rename to ASSESSMENT_SUBMISSION.md)
3. Create a zip file with your `backend/` and `typescript-services/` implementations
4. Include your ASSESSMENT_SUBMISSION.md in the zip
5. Submit the zip file to your contact

## ❓ Questions?

Feel free to ask clarifying questions about:
- Requirements
- Codebase patterns
- Texas compliance regulations
- Technical setup

## 🎯 Good Luck!

Take your time, write clean code, and document your decisions. Quality over speed!

---

**Note:** Using AI coding assistants (GitHub Copilot, ChatGPT, Cursor, etc.) is **encouraged** and expected. Task 5 specifically evaluates your ability to use them effectively.
