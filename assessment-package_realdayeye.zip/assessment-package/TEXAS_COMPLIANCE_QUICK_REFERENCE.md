# Texas Compliance Quick Reference

This document provides a quick reference for key Texas affordable housing compliance rules needed for Task 3. This is not exhaustive documentation but covers the essential rules you'll need to implement.

---

## LIHTC Set-Aside Requirements

**Typical Requirements:**
- **20% at 50% AMI** OR **40% at 60% AMI** (most common)
- Set-asides specify the minimum percentage of units that must be occupied by households at or below specific AMI levels
- Example: A building with 50 units and a 40% at 60% AMI set-aside must have at least 20 units occupied by households at ≤60% AMI

**Building-Level Compliance Thresholds:**
- **≤80% AMI (Low Income Units)**: At least **50% of total units** must be occupied by households at ≤80% AMI
- **≤60% AMI**: At least **10% of Low Income Units** (LIUs) must be at ≤60% AMI
- **≤30% AMI**: At least **2% of Low Income Units** (LIUs) must be at ≤30% AMI

**Note:** These thresholds are hierarchical - a unit at 30% AMI also counts toward 60% and 80% requirements.

---

## Income Limits & AMI Buckets

**AMI Percentages:**
- **30% AMI** - Extremely Low Income (ELI)
- **60% AMI** - Very Low Income (VLI) / LIHTC
- **80% AMI** - Low Income

**Income Qualification (Hierarchical):**
- Income limits are based on **household size** (1-8 people)
- If a household qualifies for 30% AMI, they also qualify for 60% and 80% AMI
- If a household qualifies for 60% AMI, they also qualify for 80% AMI
- Income must be **≤** the limit for the AMI percentage

**Example:**
- 4-person household with $50,000 annual income
- 30% AMI limit for 4-person: $28,380 → **Does NOT qualify**
- 60% AMI limit for 4-person: $56,760 → **Qualifies for 60% and 80% AMI**
- 80% AMI limit for 4-person: $75,680 → **Qualifies for 80% AMI**

---

## Rent Limits

**Two Calculation Methods:**

### Method 1: Regulatory Agreement Formula (35% Rule)
Used for regulatory compliance calculations:
```
Max Rent = 0.35 × (Income Limit / 12)
```

**Imputed Household Size:**
- Formula: `bedrooms + 1` (minimum 1 person)
- 0BR = 1 person, 1BR = 2 people, 2BR = 3 people, etc.

**Example:**
- 2BR unit, 60% AMI
- Imputed household size = 2 + 1 = 3 people
- 60% AMI income limit for 3-person: $51,060
- Max rent = 0.35 × ($51,060 / 12) = $1,489.25/month

### Method 2: Tenant Income-Based (30% Rule)
Used for tenant-specific rent limits:
```
Max Rent = min(30% of monthly income, AMI-based rent limit + utility allowance)
```

**Calculation:**
- Monthly income = Annual income / 12
- 30% of monthly income = Monthly income × 0.30
- AMI-based rent limit = calculated using Method 1
- **Use whichever is lower** (30% of income OR AMI-based limit)

**Example:**
- Tenant annual income: $40,000
- Monthly income: $3,333.33
- 30% of monthly income: $1,000
- AMI-based rent limit (from Method 1): $1,489.25
- **Max rent = $1,000** (the lower of the two)

---

## Key Formulas Summary

### Income Qualification
```
if (householdIncome <= ami30Limit) → Qualifies for 30%, 60%, 80%
else if (householdIncome <= ami60Limit) → Qualifies for 60%, 80%
else if (householdIncome <= ami80Limit) → Qualifies for 80%
else → Market rate (no AMI restrictions)
```

### Rent Limit (Regulatory)
```
imputedHouseholdSize = max(1, bedrooms + 1)
incomeLimit = amiData[amiPercentage].householdIncomeLimits[imputedHouseholdSize]
maxRent = 0.35 × (incomeLimit / 12)
```

### Rent Limit (Tenant-Specific)
```
monthlyIncome = annualIncome / 12
thirtyPercentOfIncome = monthlyIncome × 0.30
amiRentLimit = calculateRentLimit(bedrooms, amiPercentage, amiData)
maxRent = min(thirtyPercentOfIncome, amiRentLimit + utilityAllowance)
```

### Set-Aside Compliance
```
required80 = ceil(totalUnits × 0.50)  // 50% of total units
required60 = ceil(lowIncomeUnits × 0.10)  // 10% of LIUs
required30 = ceil(lowIncomeUnits × 0.02)  // 2% of LIUs
```

---

## Texas-Specific Considerations

1. **Utility Allowances**: Added to rent limits in tenant-specific calculations
2. **Income Adjustments**: Texas may have specific income adjustment rules (check regulatory agreement)
3. **Multiple Programs**: A property may have multiple compliance programs (LIHTC + Section 8)
4. **Geographic Areas**: AMI data varies by Texas county/MSA (FIPS codes)
5. **Effective Dates**: Compliance rules may change over time - use date-based lookups

---

## Common Compliance Violations

1. **Set-Aside Violation**: Not enough units at required AMI levels
2. **Income Over Limit**: Tenant income exceeds AMI limit for their household size
3. **Rent Over Limit**: Current rent exceeds maximum allowed rent
4. **Tenant Qualification**: Income not verified or missing

---

## Resources

- **TDHCA** (Texas Department of Housing and Community Affairs): Primary regulatory body
- **HUD Guidelines**: Federal guidelines applicable to Texas properties
- **LIHTC Compliance Guides**: Program-specific requirements

---

**Note:** This is a quick reference. For complete implementation details, refer to the existing codebase patterns in `backend/services/texasComplianceService.js` and `backend/utils/regulatoryCalculations.js`.
