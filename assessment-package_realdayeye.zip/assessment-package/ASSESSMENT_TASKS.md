# Technical Assessment Tasks - RealComply Platform

## Overview

This assessment evaluates your skills in:
1. **Database Design** - MongoDB schema design and data modeling
2. **TypeScript Architecture** - Code organization, design patterns, and TypeScript best practices
3. **Texas Compliance** - Understanding and implementing Texas-specific affordable housing compliance regulations
4. **AI Data Extraction** - Working with Azure AI services to extract structured data from documents
5. **AI-Assisted Programming** - Effective use of modern AI coding assistants

**Total Time:** ~5 hours

---

## Task 1: Database Design - Texas Compliance Audit System (1 hour)

### Objective

Assess database design skills, MongoDB schema modeling, and understanding of compliance data relationships.

### Requirements

Design and implement a database schema for tracking **Texas Affordable Housing Compliance Audits**. This system needs to track compliance audits, findings, corrective actions, and regulatory references specific to Texas affordable housing programs.

1. **Design the Database Schema** - Create Mongoose models with proper relationships:

**Primary Model: `TexasComplianceAudit`** (`backend/models/TexasComplianceAudit.js`):
- Design fields to track:
  - Audit metadata (audit date, auditor, audit type, building reference)
  - Texas-specific program information (LIHTC, Section 8, state programs)
  - Audit findings and violations
  - Compliance status per Texas regulations
  - Effective dates and expiration dates for compliance requirements
  - References to regulatory documents
  - Historical tracking (audit history over time)
- Consider:
  - What fields need to be indexed for efficient queries?
  - How to handle relationships with Building, Unit, Tenant models?
  - How to track changes over time (audit history)?
  - What data types are appropriate for each field?
  - How to handle Texas-specific compliance requirements (e.g., set-asides, income limits, rent limits)?

**Supporting Models** (optional - create one if time permits):
- `TexasComplianceFinding` - Individual findings within an audit
- OR `TexasRegulatoryRequirement` - Texas-specific regulatory requirements

**Note:** Focus on the primary model. Supporting models are optional and can be simple.

2. **Schema Design Considerations**:
- Include proper validation (required fields, enums, min/max values)
- Add appropriate indexes for common query patterns
- Design for efficient querying (e.g., "find all audits for a building in 2024", "find all critical violations")
- Consider data relationships (embedded vs referenced)
- Include JSDoc comments explaining design decisions
- Follow existing model patterns in the codebase

3. **Write Brief Design Notes** (in comments):
- Explain key schema design decisions
- Justify your choice of embedded vs referenced documents
- Explain your indexing strategy
- Brief note on how the schema supports Texas compliance requirements

### Deliverables

- Complete Mongoose model with proper schema design (primary model required, supporting models optional)
- Index definitions with brief explanations
- Design notes in comments explaining key decisions
- Brief explanation of how this schema supports Texas compliance tracking

### Evaluation Criteria

- **Schema Design (40%):** Appropriate data types, relationships, normalization, supports compliance use cases
- **Indexing Strategy (25%):** Proper indexes for efficient queries, understanding of query patterns
- **Data Modeling (20%):** Embedded vs referenced decisions, historical tracking approach
- **Documentation (15%):** Clear explanations of design decisions, JSDoc comments

---

## Task 2: TypeScript Code Organization & Design Patterns (1-1.5 hours)

### Objective

Assess TypeScript skills, code organization, design patterns, and architectural decision-making.

### Requirements

Create a **standalone TypeScript module** for Texas compliance calculations using proper design patterns.

1. **Create a TypeScript Service** (`typescript-services/src/services/TexasComplianceService.ts`):
- Implement a service class using the **Service/Repository pattern**
- Create interfaces/types for:
  - `TexasComplianceRule` - Interface for Texas compliance rules
  - `ComplianceCalculationResult` - Result of compliance calculations
  - `TexasAMIData` - Texas-specific AMI data structure
- Implement methods (at least 2 of the 3):
  - `calculateRentCompliance(unitData: UnitData, amiData: TexasAMIData): ComplianceCalculationResult` (required)
  - `validateSetAside(buildingData: BuildingData): boolean` (required) (Note: The interface method is `validateSetAside`, but your service can have a public method like `validateTexasSetAside` that calls the strategy's `validateSetAside`)
  - `calculateIncomeCompliance(tenantData: TenantData, amiData: TexasAMIData): ComplianceCalculationResult` (optional)
- Use proper TypeScript types (no `any` types)
- Include JSDoc comments with type information

2. **Apply Design Patterns**:
- **Strategy Pattern** (required): Create different calculation strategies for different Texas programs (LIHTC, Section 8, etc.)
- **Repository Pattern** (required): Create a repository interface for data access (mock/stub implementation is acceptable)
- **Factory Pattern** (optional): Create a factory for generating appropriate compliance calculators based on program type - implement if time permits
- Organize code into proper folder structure:
  ```
  typescript-services/src/
  ├── services/
  │   ├── TexasComplianceService.ts
  │   └── interfaces/
  │       ├── IComplianceCalculator.ts
  │       └── ITexasComplianceRepository.ts
  ├── strategies/
  │   ├── LIHTCComplianceStrategy.ts
  │   └── Section8ComplianceStrategy.ts
  └── factories/ (optional)
      └── ComplianceCalculatorFactory.ts
  ```

3. **Code Organization Requirements**:
- Follow SOLID principles (especially Single Responsibility and Dependency Inversion)
- Use dependency injection where appropriate
- Create proper abstractions (interfaces) for testability
- Keep functions small and focused
- Use TypeScript's advanced features (generics, utility types, etc.) where appropriate

4. **Error Handling**:
- Create custom error types for compliance-specific errors
- Implement proper error handling with typed errors
- Use Result/Either pattern if time permits (optional)

### Deliverables

- Complete TypeScript service with proper types
- Design pattern implementations (Strategy and Repository required, Factory optional)
- Proper folder structure and code organization
- Brief explanation of design pattern choices and architectural decisions

### Evaluation Criteria

- **TypeScript Usage (30%):** Proper types, no `any`, good use of TypeScript features
- **Design Patterns (30%):** Correct implementation of patterns, appropriate use cases
- **Code Organization (25%):** Proper structure, separation of concerns, SOLID principles
- **Code Quality (15%):** Clean code, good abstractions, maintainable

---

## Task 3: Texas-Specific Compliance Implementation (1.5 hours)

### Objective

Assess understanding of Texas-specific affordable housing compliance regulations and ability to implement compliance logic correctly.

### Requirements

Implement **Texas-specific compliance validation** based on Texas affordable housing regulations. You'll need to research and understand Texas compliance requirements.

1. **Research Texas Compliance Requirements** (brief research summary):
- Research Texas LIHTC (Low-Income Housing Tax Credit) compliance requirements
- Understand Texas-specific set-aside requirements
- Research Texas income limits and rent limits
- Document key Texas compliance rules you'll implement (brief summary)
- **Resources to consider:** 
  - **TEXAS_COMPLIANCE_QUICK_REFERENCE.md** - Quick reference guide with key Texas compliance rules (provided in assessment package)
  - Texas Department of Housing and Community Affairs (TDHCA)
  - HUD guidelines for Texas
  - LIHTC compliance guides

2. **Create Texas Compliance Service** (`backend/services/texasComplianceService.js`):
- Implement at least 2 of the 3 methods:

**Required Method 1: `validateTexasLIHTCCompliance(buildingId, checkDate = null)`**
  - Check Texas LIHTC set-aside requirements (e.g., minimum units at specific AMI levels)
  - Validate Texas-specific income limits
  - Check Texas rent limits (typically 30% of adjusted income or AMI-based limits)
  - Return compliance report with:
    - Overall compliance status
    - Set-aside compliance (actual vs required units per AMI bucket)
    - Unit-level compliance issues

**Required Method 2: `calculateTexasRentLimit(tenantIncome, householdSize, amiData, unitBedrooms)`**
  - Calculate maximum allowed rent per Texas regulations
  - Consider: 30% of adjusted income OR AMI-based limits (whichever is lower)
  - Handle Texas-specific adjustments (utility allowances, etc.)

**Optional Method 3: `validateTexasSetAside(buildingData, regulatoryAgreement)`** (implement if time permits)
  - Check if building meets Texas set-aside requirements
  - Compare actual unit distribution to required set-asides
  - Return set-aside compliance status

3. **Use Existing Utilities**:
- Leverage existing AMI calculation functions
- Use existing regulatory calculation utilities
- Follow repository pattern for data access
- Integrate with existing compliance models
- **Test Data**: Use sample data files in `sample-data/` directory to test your implementation (building-example.json, ami-data-example.json, units-example.json, tenants-example.json)

4. **Handle Texas-Specific Edge Cases**:
Handle at least 2-3 key Texas-specific edge cases, such as:
- Texas-specific AMI areas (counties, MSAs)
- Texas utility allowance calculations
- Texas-specific income adjustments
- Multiple Texas programs on same property
- Historical compliance (different rules over time)

5. **Create API Endpoint**:
- `POST /api/buildings/:buildingId/validate-texas-compliance`
- Request body: `{ checkDate: string (ISO date, optional), programType: 'LIHTC' | 'SECTION_8' | 'STATE_PROGRAM' }`
- Return Texas-specific compliance validation result

6. **Documentation**:
- Brief summary of the Texas compliance rules you implemented
- Explain any key assumptions made
- Reference sources for Texas regulations (brief list)

### Deliverables

- Complete service file with Texas compliance logic (at least 2 methods)
- API endpoint for Texas compliance validation
- Brief research summary of Texas compliance requirements
- Brief explanation of implementation decisions and any assumptions

### Evaluation Criteria

- **Compliance Understanding (40%):** Demonstrates understanding of Texas regulations, implements rules correctly
- **Implementation Quality (30%):** Clean code, proper calculations, handles edge cases
- **Research & Documentation (20%):** Good research, clear documentation of rules and assumptions
- **Integration (10%):** Properly integrates with existing codebase, uses existing utilities

---

## Task 4: AI Data Extraction from Compliance Documents (0.75-1 hour)

### Objective

Assess ability to work with AI services, craft effective prompts, and extract structured data from compliance documents.

### Requirements

Create an **AI-powered document extraction service** that extracts Texas compliance requirements from regulatory documents:

1. **Create Extraction Service** (`backend/services/texasComplianceDocumentExtractionService.js`):
- Method `extractTexasComplianceRequirements(fileBuffer, fileName, mimeType)`:
  - Use Azure Document Intelligence (via `azureFormRecognizerService`) to extract text from PDF
  - Use Azure OpenAI (via `azureOpenAIService`) with a well-crafted prompt to extract:
    - **Texas Program Type**: LIHTC, Section 8, State program, etc.
    - **Set-Aside Requirements**: Required units at each AMI level (30%, 60%, 80%)
    - **Income Limits**: Texas-specific income limits by household size
    - **Rent Limits**: Maximum rent calculations per Texas regulations
    - **Effective Dates**: When the compliance requirements take effect
    - **Geographic Area**: Texas county, MSA, or area for AMI calculations
    - **Utility Allowances**: Texas-specific utility allowance information
  - Return structured data with confidence scores for each field

2. **Craft Effective AI Prompts**:
- Create a detailed, structured prompt for Azure OpenAI
- The prompt should:
  - Clearly specify the output format (JSON)
  - Provide examples of Texas compliance requirements
  - Instruct the AI to extract Texas-specific information
  - Handle edge cases (missing data, ambiguous text)
- Document your prompt strategy and explain why you structured it this way

3. **Create API Endpoint**:
- `POST /api/compliance/extract-texas-requirements`
- Accept multipart/form-data file upload (PDF)
- Return extracted Texas compliance requirements with confidence scores
- Include validation of extracted data

4. **Error Handling & Validation**:
- Handle unsupported file types
- Basic error handling for Azure service failures (simple retry logic acceptable)
- Basic validation of extracted data structure
- Flag low-confidence extractions (< 0.7) for manual review (optional)
- Provide meaningful error messages

5. **Integration**:
- Follow existing AI extraction patterns (check `regulatoryDocumentService.js`, `leaseAgreementExtractionService.js`)
- Use existing Azure service wrappers
- Store extraction results appropriately

### Deliverables

- Complete extraction service with Texas-focused extraction
- Well-crafted AI prompt with brief documentation
- API endpoint for document upload and extraction
- Basic error handling and validation
- Brief explanation of prompt strategy and extraction approach

### Evaluation Criteria

- **AI Prompt Design (35%):** Well-structured prompt, clear instructions, handles edge cases
- **Data Extraction Quality (30%):** Extracts Texas compliance requirements accurately
- **Error Handling (20%):** Basic error handling, graceful degradation, validation
- **Code Quality (15%):** Follows existing patterns, clean code, good integration

---

## Task 5: AI-Assisted Programming Assessment (0.5 hours)

### Objective

Assess ability to effectively use AI coding assistants (like GitHub Copilot, ChatGPT, Cursor) for development tasks.

### Requirements

You are allowed and **encouraged** to use AI coding assistants throughout this assessment. This task evaluates your ability to use them effectively.

1. **Document Your AI Usage**:
- In your `ASSESSMENT_SUBMISSION.md`, create a section "AI-Assisted Programming"
- Document:
  - Which AI tools you used (e.g., GitHub Copilot, ChatGPT, Cursor, etc.)
  - How you used them (e.g., "Used Copilot for boilerplate code", "Used ChatGPT to understand Texas compliance rules", "Used Cursor for refactoring")
  - What you learned from AI suggestions
  - Any cases where you rejected AI suggestions and why

2. **Answer These Questions**:
- **Question 1**: Describe a situation during this assessment where an AI assistant suggested code that was incorrect or inappropriate. How did you identify it was wrong, and what did you do?
- **Question 2**: Give an example of how you used an AI assistant to learn about a concept (e.g., TypeScript design patterns, Texas compliance rules, MongoDB indexing) rather than just generating code.
- **Question 3**: How do you verify that AI-generated code is correct and follows best practices? What's your process?
- **Question 4**: Describe how you would use AI assistants in a team environment. What are best practices for AI-assisted development in a collaborative setting?

### Deliverables

- Documentation of AI tool usage in `ASSESSMENT_SUBMISSION.md`
- Answers to the 4 questions above
- Brief reflection on AI-assisted programming practices

### Evaluation Criteria

- **Critical Thinking (40%):** Demonstrates ability to evaluate AI suggestions, identifies incorrect code
- **Effective Usage (30%):** Uses AI tools effectively, not just copy-pasting, understands when to use AI
- **Learning Approach (20%):** Uses AI to learn concepts, not just generate code
- **Team Practices (10%):** Understands collaborative AI usage, best practices

**Note:** Using AI assistants is not only allowed but expected. This task evaluates your ability to use them as a tool effectively, not whether you used them.

---

## Submission Requirements

### Code Submission

1. **Complete all tasks** in the provided workspace structure
2. **Create your implementation files** in the `backend/` and `typescript-services/` directories
3. **Organize your code** following the patterns shown in reference files
4. **Package your submission** as a zip file containing:
   - Your `backend/` implementation directory
   - Your `typescript-services/` implementation directory
   - Your completed `ASSESSMENT_SUBMISSION.md` file

### Documentation

Create a `ASSESSMENT_SUBMISSION.md` file (use the provided template) with:
1. **Overview**: Brief summary of what was implemented
2. **Design Decisions**: Explain key architectural and implementation choices
3. **Texas Compliance Research**: Summary of Texas compliance requirements you researched
4. **Challenges**: What was difficult and how you solved it
5. **AI-Assisted Programming**: Documentation of AI tool usage
6. **Improvements**: What you would improve given more time
7. **Questions**: Any questions about the codebase or requirements

### Time Tracking

Include a brief log of time spent on each task (honor system).

---

## Evaluation Rubric

### Overall Assessment (100 points)

#### Technical Skills (40 points)
- **Database Design (15 points):** MongoDB schema design, relationships, indexing, data modeling
- **TypeScript & Design Patterns (15 points):** TypeScript usage, design patterns, code organization
- **Compliance Domain Knowledge (10 points):** Understanding of Texas compliance requirements, implementation accuracy

#### Code Quality (25 points)
- **Architecture (10 points):** Follows project patterns, proper separation of concerns
- **Code Style (8 points):** Clean, readable, maintainable code
- **Documentation (7 points):** JSDoc, comments, submission documentation

#### Problem Solving (20 points)
- **Compliance Logic (10 points):** Correct implementation of Texas compliance requirements, understanding of regulations
- **Edge Cases (10 points):** Handles edge cases and error scenarios, considers compliance implications

#### AI Integration & Usage (10 points)
- **AI Data Extraction (5 points):** Effective use of AI services, good prompt design, accurate extraction
- **AI-Assisted Programming (5 points):** Effective use of AI coding assistants, critical evaluation of suggestions

#### Communication (5 points)
- **Documentation Quality (3 points):** Clear, comprehensive documentation
- **Code Comments (2 points):** Helpful comments where needed

### Scoring Guide
- **90-100 points:** Exceptional - Strong hire, can work independently
- **75-89 points:** Good - Solid hire with some mentoring
- **60-74 points:** Acceptable - Hire with significant mentoring needed
- **Below 60 points:** Not recommended - Significant gaps in required skills

---

## Important Notes

### What You CAN Use
- ✅ **AI coding assistants** (GitHub Copilot, ChatGPT, Cursor, etc.) - **ENCOURAGED**
- ✅ Google, Stack Overflow, documentation
- ✅ Any npm packages you need
- ✅ Any approach that follows project patterns

### What You CANNOT Do
- ❌ Ask for help with implementation (clarifying questions about requirements are OK)
- ❌ Copy code from other projects without understanding
- ❌ Submit incomplete work without explanation

### Questions?
Feel free to ask clarifying questions about:
- Requirements that are unclear
- Existing codebase patterns
- Business logic you don't understand
- Texas compliance regulations
- Technical constraints

---

Good luck! Take your time, write clean code, and document your decisions.
