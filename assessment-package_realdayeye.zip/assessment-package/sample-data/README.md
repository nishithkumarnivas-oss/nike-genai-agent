# Sample Test Data

This directory contains sample JSON data files that you can use to test your implementations for Tasks 1 and 3.

## Files

### `building-example.json`
Example building data for a Texas affordable housing property (Heights 2121). Includes:
- Building metadata (name, address, total units)
- Regulatory agreement with LIHTC set-aside requirements (40% at 60% AMI)
- AMI data reference (Harris County, TX)

**Use for:** Task 1 (database design), Task 3 (compliance validation)

### `ami-data-example.json`
Array of 3 AMI (Area Median Income) data objects for Houston, TX area:
- **30% AMI** - Extremely Low Income (ELI)
- **60% AMI** - Very Low Income (VLI) / LIHTC
- **80% AMI** - Low Income

Each AMI object includes income limits for household sizes 1-8.

**Use for:** Task 3 (compliance calculations, rent limit calculations)

### `units-example.json`
Array of 8 unit objects representing different unit types:
- Mix of occupied and vacant units
- Various bedroom counts (Studio, 1BR, 2BR, 3BR)
- Current rent amounts and occupancy status
- References to building and tenants

**Use for:** Task 1 (database relationships), Task 3 (unit-level compliance checks)

### `tenants-example.json`
Array of 5 tenant objects matching the occupied units:
- Personal information and contact details
- Annual income and household size
- AMI qualification status (30%, 60%, or 80% AMI)
- Mix of income levels for testing different scenarios

**Use for:** Task 1 (database relationships), Task 3 (income compliance, rent calculations)

## How to Use

### For Task 1 (Database Design)
- Use these files to understand the data structure and relationships
- Reference the field names and types when designing your Mongoose schemas
- Note the relationships: Building → Units → Tenants, Building → AMI Data

### For Task 3 (Texas Compliance Implementation)
- Import these JSON files into your test scripts or MongoDB
- Use them to test your compliance validation functions:
  - `validateTexasLIHTCCompliance()` - Test with building-example.json
  - `calculateTexasRentLimit()` - Test with tenant and AMI data
  - `validateTexasSetAside()` - Test set-aside compliance

### Example Usage (Node.js)
```javascript
const buildingData = require('./sample-data/building-example.json');
const amiData = require('./sample-data/ami-data-example.json');
const units = require('./sample-data/units-example.json');
const tenants = require('./sample-data/tenants-example.json');

// Use in your test functions
const maxRent = calculateTexasRentLimit(
  tenants[0].currentTotalAnnualIncome,
  tenants[0].householdSize,
  amiData,
  units[0].bedrooms
);
```

## Important Notes

1. **IDs are Example Values**: The `_id` fields are example MongoDB ObjectIds. Replace them with actual ObjectIds when importing into MongoDB.

2. **Data Relationships**: 
   - Units reference Building via `building` field
   - Units reference Tenants via `currentTenant` field
   - Building references AMI data via `amiDataReference.fips`

3. **Realistic but Simplified**: This data is realistic but simplified for testing. Real production data would have more fields and complexity.

4. **Income Limits**: The AMI income limits are based on 2024 Houston, TX area data. For historical compliance checks, you may need different effective dates.

5. **Compliance Testing**: 
   - Some units/tenants are intentionally set up to test compliance scenarios
   - Unit 101: 60% AMI tenant, rent $850
   - Unit 102: 60% AMI tenant, rent $1,100
   - Unit 103: 30% AMI tenant, rent $800
   - Use these to verify your compliance calculations

## Data Validation

When using this data, ensure:
- Building has 50 total units (matches regulatory agreement requirements)
- Set-aside requires 40% at 60% AMI = 20 units minimum
- Tenant incomes match their AMI qualification levels
- Unit rents are within calculated limits (or intentionally over for testing violations)
