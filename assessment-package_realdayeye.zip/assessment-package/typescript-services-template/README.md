# TypeScript Services Template

This is a minimal TypeScript project template for Task 2 of the assessment.

## Quick Start

1. **Copy this template** to `typescript-services/` directory in your assessment workspace
2. **Install dependencies:**
   ```bash
   npm install
   ```
3. **Create your implementation** in the `src/` directory following the structure:
   ```
   src/
   ├── services/
   │   ├── TexasComplianceService.ts
   │   └── interfaces/
   │       ├── IComplianceCalculator.ts
   │       └── ITexasComplianceRepository.ts
   ├── strategies/
   │   ├── LIHTCComplianceStrategy.ts
   │   └── Section8ComplianceStrategy.ts
   └── factories/ (optional)
       └── ComplianceCalculatorFactory.ts
   ```
4. **Build the project:**
   ```bash
   npm run build
   ```
5. **Type check without building:**
   ```bash
   npm run type-check
   ```

## Project Structure

```
typescript-services-template/
├── package.json          # Dependencies and scripts
├── tsconfig.json         # TypeScript configuration
├── README.md            # This file
└── src/                 # Your TypeScript source files (create this)
    └── (your implementation files)
```

## TypeScript Configuration

The `tsconfig.json` is configured with:
- **Target**: ES2020
- **Strict mode**: Enabled (recommended for production code)
- **Module system**: ESNext
- **Path mappings**: Configured for `@services/*`, `@interfaces/*`, `@strategies/*`, `@types/*`
- **Output**: Compiled to `dist/` directory

## Dependencies

**Minimal dependencies included:**
- `typescript` - TypeScript compiler
- `@types/node` - Node.js type definitions

**You may add additional dependencies** as needed for your implementation (e.g., for testing, utilities, etc.)

## Building

The project uses the TypeScript compiler directly (no bundler required for this assessment).

- **Build**: `npm run build` - Compiles TypeScript to JavaScript in `dist/`
- **Type Check**: `npm run type-check` - Checks types without emitting files
- **Clean**: `npm run clean` - Removes the `dist/` directory

## Notes

- This is a **template** - customize it as needed for your implementation
- The `src/` directory is empty - create your files according to Task 2 requirements
- Path mappings are configured but optional - use them for cleaner imports
- Strict mode is enabled - this helps catch errors early

## Reference Files

See `reference/typescript-services/` for example TypeScript patterns:
- Service class structure
- Interface definitions
- Dependency injection patterns
