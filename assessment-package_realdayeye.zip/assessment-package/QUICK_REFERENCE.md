# Quick Reference Guide

## Project Structure

```
RealdAI/
├── backend/              # Node.js backend
│   ├── models/         # Mongoose models
│   ├── services/       # Business logic services
│   ├── controllers/    # Route controllers
│   ├── routes/         # API routes
│   └── repositories/   # Data access layer
├── frontend/           # React frontend (optional - not required for assessment)
├── typescript-services/ # TypeScript compliance services (Task 2)
└── shared/            # Shared utilities
```

## Key Files to Reference

### Database Models
- `backend/models/Building.js` - Building model example
- `backend/models/Unit.js` - Unit model example
- `backend/models/Tenant.js` - Tenant model example

### Services
- `backend/services/regulatoryDocumentService.js` - AI document extraction example
- `backend/services/leaseAgreementExtractionService.js` - Document extraction pattern
- `backend/utils/regulatoryCalculations.js` - Compliance calculation utilities
- `backend/utils/amiDataHelper.js` - AMI data helpers

### TypeScript Examples (Reference Files)
- `reference/typescript-services/src/services/ExampleService.ts` - Service pattern example
- `reference/typescript-services/src/services/interfaces/IExampleCalculator.ts` - Interface pattern example

These demonstrate TypeScript patterns including service structure, interfaces, dependency injection, and type safety. For Task 2, create your TypeScript implementation in the `typescript-services/` directory.

## Common Patterns

### Mongoose Model Pattern
```javascript
const mongoose = require('mongoose');

const schema = new mongoose.Schema({
  // fields
}, {
  timestamps: true
});

// Indexes
schema.index({ field1: 1, field2: -1 });

module.exports = mongoose.model('ModelName', schema);
```

### Repository Pattern
```javascript
// Use repositories, not direct model access
const { buildingRepository } = require('../repositories');

const building = await buildingRepository.findById(buildingId);
```

### TypeScript Service Pattern
```typescript
interface IService {
  method(): Promise<Result>;
}

class Service implements IService {
  async method(): Promise<Result> {
    // implementation
  }
}
```

## API Endpoint Pattern

```javascript
// routes/example.js
const express = require('express');
const router = express.Router();
const controller = require('../controllers/exampleController');

router.get('/example', controller.getExample);
router.post('/example', controller.createExample);

module.exports = router;
```

## Texas Compliance Resources

- **TEXAS_COMPLIANCE_QUICK_REFERENCE.md** - Quick reference guide with key Texas compliance rules, formulas, and requirements (see assessment-package directory)
- **TDHCA**: Texas Department of Housing and Community Affairs
- **HUD**: U.S. Department of Housing and Urban Development
- **LIHTC**: Low-Income Housing Tax Credit program
- **AMI**: Area Median Income

## Sample Test Data

The assessment package includes sample data files in the `sample-data/` directory:
- `building-example.json` - Example building with LIHTC set-aside requirements
- `ami-data-example.json` - AMI data for 30%, 60%, and 80% levels (Houston, TX)
- `units-example.json` - Example units (occupied and vacant)
- `tenants-example.json` - Example tenants with different income levels

Use these files to test your implementations for Tasks 1 and 3. See `sample-data/README.md` for usage instructions.

## Common Commands

```bash
# Install dependencies
npm install

# Start development
npm run dev

# Run tests
npm test

# Lint code
npm run lint

# TypeScript setup (Task 2)
# Option 1: Use the provided template
cp -r typescript-services-template typescript-services
cd typescript-services
npm install
npm run build

# Option 2: Set up manually
cd typescript-services
npm init -y
npm install --save-dev typescript @types/node
npx tsc --init
```

## Submission Workflow

```bash
# Work on your implementations in the workspace directories
# backend/models/, backend/services/, etc.
# typescript-services/src/services/, etc.

# When complete, create a zip file with:
# - Your backend/ directory
# - Your typescript-services/ directory  
# - Your ASSESSMENT_SUBMISSION.md file
```

## Helpful Tips

1. **Read existing code** - Follow patterns you see in the codebase
2. **Use AI assistants** - They're encouraged! Use them effectively
3. **Ask questions** - Clarifying questions are always welcome
4. **Document decisions** - Explain your design choices
5. **Test your code** - Make sure it works before submitting

## Need Help?

- Check existing code for patterns
- Review documentation in `/docs` folder
- Ask clarifying questions about requirements
- Use AI assistants for learning concepts
