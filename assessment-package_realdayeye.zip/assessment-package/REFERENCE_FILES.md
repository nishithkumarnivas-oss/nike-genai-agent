# Reference Files Guide

This document explains the reference files included in this assessment package and how to use them.

## Purpose

Since you won't have access to the full codebase repository, we've included key reference files that demonstrate:
- Existing code patterns you should follow
- Model structures and relationships
- Service patterns and architecture
- API route structures

## Reference Files Included

### Backend Models (Reference)
- `reference/backend/models/Building.js` - Example Mongoose model showing schema patterns
- `reference/backend/models/Unit.js` - Example Unit model
- `reference/backend/models/Tenant.js` - Example Tenant model

### Backend Services (Reference)
- `reference/backend/services/complianceService.js` - Example compliance service pattern
- `reference/backend/services/regulatoryDocumentService.js` - Example AI extraction service pattern

### Backend Routes (Reference)
- `reference/backend/routes/buildingRoutes.js` - Example route structure (shows how controllers are used)

### TypeScript Services (Reference)
- `reference/typescript-services/src/services/ExampleService.ts` - Example TypeScript service pattern
- `reference/typescript-services/src/services/interfaces/IExampleCalculator.ts` - Example interface pattern

These files demonstrate TypeScript patterns including:
- Service class structure with dependency injection
- Interface definitions for strategy pattern
- Type safety and error handling
- Code organization best practices

You'll create your implementation in the `typescript-services/` directory following these patterns.

## Your Implementation Files

You'll create your implementations in these locations:

### Task 1: Database Design
- `backend/models/TexasComplianceAudit.js` - **Create this file**
- `backend/models/TexasComplianceFinding.js` - **Create this file**

### Task 2: TypeScript Services
- `typescript-services/src/services/TexasComplianceService.ts` - **Create this file**
- `typescript-services/src/services/interfaces/IComplianceCalculator.ts` - **Create this file**
- `typescript-services/src/services/interfaces/ITexasComplianceRepository.ts` - **Create this file**
- `typescript-services/src/services/types/TexasComplianceTypes.ts` - **Create this file**
- `typescript-services/src/strategies/LIHTCComplianceStrategy.ts` - **Create this file**
- `typescript-services/src/strategies/Section8ComplianceStrategy.ts` - **Create this file**
- `typescript-services/src/factories/ComplianceCalculatorFactory.ts` - **Create this file**

### Task 3: Texas Compliance Service
- `backend/services/texasComplianceService.js` - **Create this file**
- `backend/routes/buildingRoutes.js` - **Add route to this file** (or create new)
- `backend/controllers/buildingController.js` - **Add controller method** (or create new)

### Task 4: AI Extraction Service
- `backend/services/texasComplianceDocumentExtractionService.js` - **Create this file**
- `backend/routes/complianceRoutes.js` - **Create this file**
- `backend/controllers/complianceController.js` - **Create this file**

## How to Use Reference Files

1. **Study the patterns** - Look at how existing models, services, and controllers are structured
2. **Follow conventions** - Use the same naming, organization, and coding patterns
3. **Match the style** - Pay attention to JSDoc comments, error handling, and validation patterns
4. **Understand relationships** - See how models reference each other and how services interact

## Important Notes

- Reference files are **read-only examples** - don't modify them
- Your implementation files should follow the same patterns but implement the specific requirements
- If a reference file shows a pattern you need, adapt it to your specific task requirements
- All reference files are from the actual codebase and represent real patterns used in production

## Additional Resources

The assessment package includes additional resources to help you complete the tasks:

### Texas Compliance Quick Reference
- `TEXAS_COMPLIANCE_QUICK_REFERENCE.md` - Quick reference guide with key Texas compliance rules, formulas, and requirements
- Essential for Task 3 (Texas Compliance Implementation)
- Includes LIHTC set-aside requirements, income limits, rent limit formulas, and compliance thresholds

### Sample Test Data
- `sample-data/` directory contains example JSON files:
  - `building-example.json` - Example building with LIHTC set-aside requirements
  - `ami-data-example.json` - AMI data for 30%, 60%, and 80% levels (Houston, TX)
  - `units-example.json` - Example units (occupied and vacant)
  - `tenants-example.json` - Example tenants with different income levels
- Use these files to test your implementations for Tasks 1 and 3
- See `sample-data/README.md` for detailed usage instructions

### TypeScript Project Template
- `typescript-services-template/` directory contains a pre-configured TypeScript project
- Includes `package.json`, `tsconfig.json`, and setup instructions
- Use this template for Task 2 to get started quickly
- See `typescript-services-template/README.md` for setup instructions

## Project Structure

```
assessment-workspace/
├── assessment-package/          # Assessment documentation
│   ├── README.md
│   ├── ASSESSMENT_INSTRUCTIONS.md
│   ├── ASSESSMENT_TASKS.md
│   ├── SETUP_GUIDE.md
│   ├── ASSESSMENT_SUBMISSION_TEMPLATE.md
│   ├── QUICK_REFERENCE.md
│   ├── REFERENCE_FILES.md       # This file
│   ├── TEXAS_COMPLIANCE_QUICK_REFERENCE.md
│   ├── sample-data/             # Sample test data files
│   │   ├── building-example.json
│   │   ├── ami-data-example.json
│   │   ├── units-example.json
│   │   ├── tenants-example.json
│   │   └── README.md
│   └── typescript-services-template/  # TypeScript project template
│       ├── package.json
│       ├── tsconfig.json
│       ├── README.md
│       └── src/
├── reference/                    # Reference code files (read-only)
│   ├── backend/
│   └── typescript-services/      # TypeScript pattern examples
├── backend/                      # Your implementation (create files here)
│   ├── models/
│   ├── services/
│   ├── routes/
│   └── controllers/
└── typescript-services/          # Your TypeScript implementation (create files here)
    └── src/
        ├── services/
        ├── strategies/
        ├── factories/
        └── types/
```

## Getting Started

1. Read `ASSESSMENT_INSTRUCTIONS.md` first
2. Review `ASSESSMENT_TASKS.md` for detailed requirements
3. Study reference files to understand patterns
4. Start implementing tasks in order
5. Document your work in `ASSESSMENT_SUBMISSION.md`

Good luck!
