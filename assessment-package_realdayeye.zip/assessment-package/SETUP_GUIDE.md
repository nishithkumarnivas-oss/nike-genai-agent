# Environment Setup Guide

## Prerequisites

Before starting the assessment, ensure you have:

- **Node.js** 16+ installed
- **npm** or **yarn** package manager
- **Git** for version control
- **MongoDB** (local or connection string provided)
- **Code Editor** (VS Code, Cursor, etc.)
- **Azure Account** (credentials will be provided)

---

## Step 1: Extract the Assessment Package

1. **Extract the zip file** you received to a location on your computer
2. **Navigate to the extracted folder** - you should see the `assessment-workspace` directory

```bash
cd assessment-workspace
```

---

## Step 2: Install Dependencies

**Note:** Since this is a standalone assessment package, you'll need to set up a minimal Node.js project structure. You can either:
- Work directly in the provided workspace structure
- Set up a minimal project with just the dependencies you need

For the assessment, you'll primarily need:
- MongoDB connection (local or provided connection string)
- Azure credentials (will be provided)
- Node.js and npm

You don't need to install all project dependencies - just what's needed to test your implementations.

### Root Dependencies
```bash
npm install
```

### Backend Dependencies
```bash
cd backend
npm install
```

### Frontend Dependencies (Optional)
**Note:** Frontend setup is optional - no frontend tasks are required for this assessment. You may set it up if you want to test API endpoints visually.

```bash
cd ../frontend
npm install
```

### TypeScript Services Setup (Optional)
For Task 2, you'll create a standalone TypeScript module. 

**Option 1: Use the provided template (Recommended)**
```bash
# Copy the template to your workspace
cp -r typescript-services-template typescript-services
cd typescript-services
npm install
```

**Option 2: Set up manually**
```bash
cd ../typescript-services
npm init -y
npm install --save-dev typescript @types/node
npx tsc --init
```

The template includes a pre-configured `tsconfig.json` and `package.json` with the necessary dependencies and scripts.

---

## Step 3: Environment Configuration

### Backend Environment Variables

Create `backend/.env` file with the following:

```env
# Database
MONGO_URI=mongodb://localhost:27017/realcomply-test
# Or use provided test database connection string

# JWT
JWT_SECRET=assessment-test-secret-key

# Azure Services (credentials will be provided)
AZURE_OPENAI_ENDPOINT=your-azure-openai-endpoint
AZURE_OPENAI_API_KEY=your-azure-openai-key
AZURE_OPENAI_DEPLOYMENT_NAME=your-deployment-name

# Azure Document Intelligence
AZURE_FORM_RECOGNIZER_ENDPOINT=your-form-recognizer-endpoint
AZURE_FORM_RECOGNIZER_API_KEY=your-form-recognizer-key

# Azure Blob Storage
AZURE_STORAGE_CONNECTION_STRING=your-storage-connection-string
```

### Frontend Environment Variables (Optional)

If you set up the frontend, create `frontend/.env` file:

```env
VITE_API_BASE_URL=http://localhost:3000
VITE_FRONTEND_URL=http://localhost:5173
```

---

## Step 4: Start Development Servers

### Option 1: Start All Services (Recommended)
From the root directory:
```bash
npm run dev
```

This starts:
- Backend server on port 3000
- Frontend server on port 5173 (optional - only if frontend is set up)

### Option 2: Start Individually

**Backend:**
```bash
cd backend
npm run dev
```

**Frontend (Optional):**
```bash
cd frontend
npm run dev
```

---

## Step 5: Verify Setup

1. **Check Backend**: Visit `http://localhost:3000/api/health` (if available)
2. **Check Frontend** (if set up): Visit `http://localhost:5173`
3. **Check MongoDB**: Ensure MongoDB is running and accessible

---

## Step 6: Set Up Your Workspace

1. **Review the workspace structure** in the `assessment-workspace` directory
2. **Study the reference files** in the `reference/` directory to understand patterns
3. **Review sample data** in the `sample-data/` directory (useful for testing Tasks 1 and 3)
4. **Review Texas compliance quick reference** in `TEXAS_COMPLIANCE_QUICK_REFERENCE.md` (helpful for Task 3)
5. **Create your implementation files** in the `backend/` and `typescript-services/` directories as specified in the tasks

---

## Troubleshooting

### MongoDB Connection Issues
- Ensure MongoDB is running: `mongod` or check your MongoDB service
- Verify connection string format
- Check firewall settings if using remote MongoDB

### Port Already in Use
- Backend (3000): Change port in `backend/index.js` or kill existing process
- Frontend (5173, optional): Change port in `frontend/vite.config.js` (if frontend is set up)

### Dependency Installation Issues
- Clear npm cache: `npm cache clean --force`
- Delete `node_modules` and `package-lock.json`, then reinstall
- Check Node.js version: `node --version` (should be 16+)

### Azure Service Issues
- Verify credentials are correct
- Check Azure service status
- Ensure API keys have proper permissions

---

## Need Help?

If you encounter setup issues:
1. Check the error message carefully
2. Review the project README.md
3. Check existing documentation in `/docs` folder
4. Ask clarifying questions (setup questions are always welcome!)

---

## Ready to Start?

Once everything is set up:
1. ✅ You've extracted the assessment package
2. ✅ You have Node.js and MongoDB available (or connection string)
3. ✅ You've reviewed the reference files
4. ✅ You've read ASSESSMENT_INSTRUCTIONS.md

**You're ready to begin!** Start with Task 1 in the main assessment document.
