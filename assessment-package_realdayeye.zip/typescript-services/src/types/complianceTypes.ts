/**
 * Shared type definitions for Texas compliance calculations.
 *
 * These types are intentionally backend-agnostic so this module can be used
 * from Node services, tests, or other tools.
 */

/** Texas program types supported by this module. */
export type TexasProgramType =
  | 'LIHTC'
  | 'SECTION_8'
  | 'STATE_PROGRAM'
  | 'HOME'
  | 'OTHER';

/** Basic AMI record for a specific percentage level (e.g. 30%, 60%). */
export interface TexasAMIRecord {
  /** AMI percentage, e.g. 30 for 30% AMI. */
  percentage: number;
  /** Income limits by household size (1–8+). */
  incomeLimitsByHouseholdSize: Record<number, number>;
  /** Optional rent limits by bedroom count (0 = studio). */
  rentLimitsByBedrooms?: Record<number, number>;
}

/**
 * Texas-specific AMI data structure.
 * This is simplified compared to the backend AMI models but captures what
 * the calculator needs.
 */
export interface TexasAMIData {
  /** Geographic descriptor (county, MSA, etc.). */
  areaName: string;
  /** FIPS or similar code that anchors this AMI dataset. */
  areaCode: string;
  /** Fiscal year, e.g. 2024. */
  fiscalYear: number;
  /** List of AMI levels (30%, 60%, 80%, etc.). */
  levels: TexasAMIRecord[];
}

/** Minimal unit data needed for rent compliance checks. */
export interface UnitData {
  id: string;
  unitNumber: string;
  bedrooms: number;
  /** Current contract rent (base rent + required fees) per month. */
  currentRent: number;
  /** Utility allowance for the unit (if applicable) per month. */
  utilityAllowance?: number;
  /** AMI bucket assigned to this unit, e.g. 30, 60, 80 (percentage). */
  targetAmiPercentage?: number;
}

/** Minimal building-level data needed for set-aside validation. */
export interface BuildingData {
  id: string;
  name: string;
  totalUnits: number;
  /** All units in the building used for set-aside checks. */
  units: UnitData[];
  /**
   * Required set-aside configuration, expressed as required units per AMI %
   * e.g. { 30: 5, 60: 40 } => at least 5 units at 30% AMI, 40 units at 60% AMI.
   */
  requiredSetAsides: Record<number, number>;
  /** Texas program type the building is operating under (LIHTC, Section 8, etc.). */
  programType: TexasProgramType;
}

/** Minimal tenant data needed for income compliance checks. */
export interface TenantData {
  id: string;
  fullName: string;
  householdSize: number;
  /** Total annual household income in USD. */
  annualHouseholdIncome: number;
  /** Assigned AMI percentage for this household (e.g. 60 for 60% AMI). */
  targetAmiPercentage?: number;
}

/** Interface representing a single Texas compliance rule. */
export interface TexasComplianceRule {
  /** Short code for the rule, e.g. "LIHTC_RENT_LIMIT". */
  code: string;
  /** Human-readable description of the rule. */
  description: string;
  /** Program this rule applies to. */
  program: TexasProgramType;
}

/** Detailed result of a compliance calculation. */
export interface ComplianceCalculationResult {
  /**
   * Whether the checked object (unit, tenant, building) is compliant.
   * Note: some strategies may mark overall `isCompliant: false` while still
   * providing granular details about which sub-rules passed or failed.
   */
  isCompliant: boolean;
  /** Code(s) for violated rules, if any. */
  violatedRules: string[];
  /** Additional human-readable messages or explanations. */
  messages: string[];
  /**
   * Arbitrary, strongly-typed extra data the UI or callers can use
   * (e.g. computed rent limit, required units vs actual).
   */
  details?: Record<string, unknown>;
}


