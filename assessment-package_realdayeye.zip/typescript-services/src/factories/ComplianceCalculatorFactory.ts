import { IComplianceCalculator } from '../services/interfaces/IComplianceCalculator';
import { TexasProgramType } from '../types/complianceTypes';
import { LIHTCComplianceStrategy } from '../strategies/LIHTCComplianceStrategy';
import { Section8ComplianceStrategy } from '../strategies/Section8ComplianceStrategy';

/**
 * Factory responsible for constructing IComplianceCalculator instances
 * for supported Texas program types.
 *
 * This keeps program-specific wiring in one place and allows the service
 * to depend only on the abstraction (IComplianceCalculator).
 */
export class ComplianceCalculatorFactory {
  /**
   * Create a calculator for the given program.
   *
   * @param program - Texas program type (LIHTC, Section 8, etc.)
   */
  static createCalculator(program: TexasProgramType): IComplianceCalculator {
    switch (program) {
      case 'LIHTC':
        return new LIHTCComplianceStrategy();
      case 'SECTION_8':
        return new Section8ComplianceStrategy();
      default:
        // Fallback to LIHTC for this assessment; in a real system we might
        // throw or have dedicated strategies for each program.
        return new LIHTCComplianceStrategy();
    }
  }

  /**
   * Convenience to create all built-in calculators at once.
   */
  static createAllCalculators(): IComplianceCalculator[] {
    return [new LIHTCComplianceStrategy(), new Section8ComplianceStrategy()];
  }
}


