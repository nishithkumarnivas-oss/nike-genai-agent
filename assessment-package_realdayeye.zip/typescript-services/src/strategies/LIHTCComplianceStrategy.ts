import {
  BuildingData,
  ComplianceCalculationResult,
  TenantData,
  TexasAMIData,
  TexasProgramType,
  UnitData,
} from '../types/complianceTypes';
import { IComplianceCalculator } from '../services/interfaces/IComplianceCalculator';

/**
 * Helper to find the AMI record matching a given percentage.
 */
function findAmiRecord(
  amiData: TexasAMIData,
  percentage: number
): TexasAMIData['levels'][number] | undefined {
  return amiData.levels.find((level) => level.percentage === percentage);
}

/**
 * LIHTC-specific compliance calculator.
 *
 * Assumptions (simplified for assessment purposes):
 * - Rent limit for a unit is the AMI rent limit for its target AMI bucket
 *   and bedroom count, minus any utility allowance.
 * - Income limit is based on household size and AMI income limits.
 * - Set-aside requirements are expressed as required units per AMI %, and a
 *   unit is counted towards an AMI bucket based on its `targetAmiPercentage`.
 */
export class LIHTCComplianceStrategy implements IComplianceCalculator {
  public readonly program: TexasProgramType = 'LIHTC';

  calculateRentCompliance(
    unitData: UnitData,
    amiData: TexasAMIData
  ): ComplianceCalculationResult {
    const messages: string[] = [];
    const violatedRules: string[] = [];

    if (unitData.targetAmiPercentage == null) {
      messages.push(
        'Unit has no target AMI percentage; treating as non-LIHTC for rent compliance.'
      );
      return {
        isCompliant: true,
        violatedRules,
        messages,
        details: { skipped: true },
      };
    }

    const amiRecord = findAmiRecord(amiData, unitData.targetAmiPercentage);
    if (!amiRecord || !amiRecord.rentLimitsByBedrooms) {
      messages.push(
        `No LIHTC rent limits configured for ${unitData.targetAmiPercentage}% AMI.`
      );
      return {
        isCompliant: false,
        violatedRules: ['LIHTC_RENT_LIMIT_CONFIG_MISSING'],
        messages,
      };
    }

    const baseRentLimit =
      amiRecord.rentLimitsByBedrooms[unitData.bedrooms] ??
      amiRecord.rentLimitsByBedrooms[0];

    if (baseRentLimit == null) {
      messages.push(
        `No rent limit found for ${unitData.bedrooms}BR at ${unitData.targetAmiPercentage}% AMI.`
      );
      return {
        isCompliant: false,
        violatedRules: ['LIHTC_RENT_LIMIT_CONFIG_MISSING'],
        messages,
      };
    }

    const utilityAllowance = unitData.utilityAllowance ?? 0;
    const maxAllowedRent = baseRentLimit - utilityAllowance;

    if (unitData.currentRent <= maxAllowedRent) {
      messages.push(
        `Unit rent $${unitData.currentRent.toFixed(
          2
        )} is within LIHTC limit $${maxAllowedRent.toFixed(2)}.`
      );
      return {
        isCompliant: true,
        violatedRules,
        messages,
        details: {
          maxAllowedRent,
          baseRentLimit,
          utilityAllowance,
        },
      };
    }

    violatedRules.push('LIHTC_RENT_LIMIT_EXCEEDED');
    messages.push(
      `Unit rent $${unitData.currentRent.toFixed(
        2
      )} exceeds LIHTC limit $${maxAllowedRent.toFixed(2)}.`
    );

    return {
      isCompliant: false,
      violatedRules,
      messages,
      details: {
        maxAllowedRent,
        baseRentLimit,
        utilityAllowance,
        overage: unitData.currentRent - maxAllowedRent,
      },
    };
  }

  validateSetAside(buildingData: BuildingData): boolean {
    const countsByAmi: Record<number, number> = {};

    for (const unit of buildingData.units) {
      if (unit.targetAmiPercentage == null) continue;
      countsByAmi[unit.targetAmiPercentage] =
        (countsByAmi[unit.targetAmiPercentage] ?? 0) + 1;
    }

    for (const [amiStr, requiredUnits] of Object.entries(
      buildingData.requiredSetAsides
    )) {
      const ami = Number(amiStr);
      const actualUnits = countsByAmi[ami] ?? 0;
      if (actualUnits < requiredUnits) {
        return false;
      }
    }

    return true;
  }

  calculateIncomeCompliance(
    tenantData: TenantData,
    amiData: TexasAMIData
  ): ComplianceCalculationResult {
    const messages: string[] = [];
    const violatedRules: string[] = [];

    if (tenantData.targetAmiPercentage == null) {
      messages.push(
        'Tenant has no target AMI percentage; skipping LIHTC income check.'
      );
      return {
        isCompliant: true,
        violatedRules,
        messages,
        details: { skipped: true },
      };
    }

    const amiRecord = findAmiRecord(amiData, tenantData.targetAmiPercentage);
    if (!amiRecord) {
      messages.push(
        `No income limits configured for ${tenantData.targetAmiPercentage}% AMI.`
      );
      return {
        isCompliant: false,
        violatedRules: ['LIHTC_INCOME_LIMIT_CONFIG_MISSING'],
        messages,
      };
    }

    const limit =
      amiRecord.incomeLimitsByHouseholdSize[tenantData.householdSize] ??
      amiRecord.incomeLimitsByHouseholdSize[1];

    if (limit == null) {
      messages.push(
        `No income limit for household size ${tenantData.householdSize}.`
      );
      return {
        isCompliant: false,
        violatedRules: ['LIHTC_INCOME_LIMIT_CONFIG_MISSING'],
        messages,
      };
    }

    if (tenantData.annualHouseholdIncome <= limit) {
      messages.push(
        `Household income $${tenantData.annualHouseholdIncome.toFixed(
          2
        )} is within LIHTC income limit $${limit.toFixed(2)}.`
      );
      return {
        isCompliant: true,
        violatedRules,
        messages,
        details: {
          incomeLimit: limit,
        },
      };
    }

    violatedRules.push('LIHTC_INCOME_LIMIT_EXCEEDED');
    messages.push(
      `Household income $${tenantData.annualHouseholdIncome.toFixed(
        2
      )} exceeds LIHTC income limit $${limit.toFixed(2)}.`
    );

    return {
      isCompliant: false,
      violatedRules,
      messages,
      details: {
        incomeLimit: limit,
        overage: tenantData.annualHouseholdIncome - limit,
      },
    };
  }
}


