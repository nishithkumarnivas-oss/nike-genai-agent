import {
  BuildingData,
  ComplianceCalculationResult,
  TenantData,
  TexasAMIData,
  TexasProgramType,
  UnitData,
} from '../types/complianceTypes';
import { IComplianceCalculator } from '../services/interfaces/IComplianceCalculator';

/**
 * Section 8-specific compliance calculator.
 *
 * Simplified assumptions:
 * - Rent compliance focuses on the tenant portion of rent relative to income
 *   (e.g. 30% of adjusted income). This implementation demonstrates structure
 *   but does not attempt to fully model HUD rules.
 * - Set-aside logic is usually less central for Section 8, so we implement a
 *   simple pass-through that always returns true unless a building explicitly
 *   requires minimum Section 8 units.
 */
export class Section8ComplianceStrategy implements IComplianceCalculator {
  public readonly program: TexasProgramType = 'SECTION_8';

  calculateRentCompliance(
    unitData: UnitData,
    _amiData: TexasAMIData
  ): ComplianceCalculationResult {
    // In a real implementation, we would need tenant share vs subsidy.
    // Here we treat Section 8 rent as compliant by default and rely on
    // upstream systems to enforce HUD-specific rent caps.
    return {
      isCompliant: true,
      violatedRules: [],
      messages: ['Section 8 rent compliance is assumed handled by HUD subsidy.'],
      details: {
        note: 'Simplified Section 8 logic for assessment purposes.',
      },
    };
  }

  validateSetAside(buildingData: BuildingData): boolean {
    // For Section 8, we simply check if the building has at least the required
    // number of Section 8 units, if such a requirement is expressed via
    // requiredSetAsides[0] (convention used just for demonstration).
    const requiredSection8Units = buildingData.requiredSetAsides[0] ?? 0;
    if (requiredSection8Units === 0) {
      return true;
    }

    const actualSection8Units = buildingData.units.filter(
      (unit) => unit.targetAmiPercentage === 0
    ).length;

    return actualSection8Units >= requiredSection8Units;
  }

  calculateIncomeCompliance(
    tenantData: TenantData,
    _amiData: TexasAMIData
  ): ComplianceCalculationResult {
    // Simplified: Section 8 income eligibility is complex; we simply return
    // a placeholder result indicating that detailed checks are not modeled.
    return {
      isCompliant: true,
      violatedRules: [],
      messages: [
        'Section 8 income compliance not fully modeled; assumed handled by PHA.',
      ],
      details: {
        tenantId: tenantData.id,
        note: 'Simplified Section 8 income logic for assessment purposes.',
      },
    };
  }
}


