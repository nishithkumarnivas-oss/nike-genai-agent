import {
  BuildingData,
  TenantData,
  TexasAMIData,
  TexasProgramType,
  UnitData,
} from '../types/complianceTypes';
import { ITexasComplianceRepository } from './interfaces/ITexasComplianceRepository';

/**
 * Simple in-memory implementation of ITexasComplianceRepository.
 *
 * This is sufficient for demonstrating the Repository pattern in the
 * assessment without requiring a real database or HTTP integration.
 */
export class MockTexasComplianceRepository implements ITexasComplianceRepository {
  private readonly amiDataStore: Map<string, TexasAMIData> = new Map();
  private readonly buildings: Map<string, BuildingData> = new Map();
  private readonly tenants: Map<string, TenantData> = new Map();

  constructor(seed?: {
    amiData?: TexasAMIData[];
    buildings?: BuildingData[];
    tenants?: TenantData[];
  }) {
    if (seed?.amiData) {
      for (const ami of seed.amiData) {
        const key = this.getAmiKey(ami.areaCode, ami.fiscalYear);
        this.amiDataStore.set(key, ami);
      }
    }
    if (seed?.buildings) {
      for (const b of seed.buildings) {
        this.buildings.set(b.id, b);
      }
    }
    if (seed?.tenants) {
      for (const t of seed.tenants) {
        this.tenants.set(t.id, t);
      }
    }
  }

  async getTexasAmiData(
    areaCode: string,
    fiscalYear: number
  ): Promise<TexasAMIData> {
    const key = this.getAmiKey(areaCode, fiscalYear);
    const data = this.amiDataStore.get(key);
    if (!data) {
      throw new Error(
        `Texas AMI data not found for areaCode=${areaCode}, fiscalYear=${fiscalYear}`
      );
    }
    return data;
  }

  async getBuildingData(buildingId: string): Promise<BuildingData> {
    const building = this.buildings.get(buildingId);
    if (!building) {
      throw new Error(`Building not found: ${buildingId}`);
    }
    return building;
  }

  async getTenantData(tenantId: string): Promise<TenantData> {
    const tenant = this.tenants.get(tenantId);
    if (!tenant) {
      throw new Error(`Tenant not found: ${tenantId}`);
    }
    return tenant;
  }

  async getUnitsForProgram(
    buildingId: string,
    programType: TexasProgramType
  ): Promise<UnitData[]> {
    const building = await this.getBuildingData(buildingId);
    if (building.programType !== programType) {
      return [];
    }
    return building.units;
  }

  private getAmiKey(areaCode: string, fiscalYear: number): string {
    return `${areaCode}:${fiscalYear}`;
  }
}


