import {
  BuildingData,
  ComplianceCalculationResult,
  TenantData,
  TexasAMIData,
  TexasProgramType,
  UnitData,
} from '../types/complianceTypes';
import { IComplianceCalculator } from './interfaces/IComplianceCalculator';
import { ITexasComplianceRepository } from './interfaces/ITexasComplianceRepository';

/**
 * Public interface for the TexasComplianceService.
 *
 * This matches the assessment requirements and acts as a façade over
 * strategy-specific calculators (LIHTC, Section 8, etc.).
 */
export interface ITexasComplianceService {
  calculateRentCompliance(
    unitData: UnitData,
    amiData: TexasAMIData
  ): ComplianceCalculationResult;

  /**
   * Interface method name as required by the assessment.
   * Implementations may expose a more specific public name that delegates here.
   */
  validateSetAside(buildingData: BuildingData): boolean;

  calculateIncomeCompliance(
    tenantData: TenantData,
    amiData: TexasAMIData
  ): ComplianceCalculationResult;
}

/**
 * Service class implementing Texas compliance calculations.
 *
 * Responsibilities:
 * - Select the correct strategy (calculator) based on program type.
 * - Coordinate with the Repository to load building/tenant/AMI data
 *   when needed (for a real system; here we mostly accept data as
 *   parameters for simplicity).
 * - Provide a clean, typed API for callers.
 *
 * This follows the Service/Repository pattern:
 * - TexasComplianceService: orchestration + business logic.
 * - ITexasComplianceRepository: data access abstraction.
 * - IComplianceCalculator: Strategy pattern for program-specific rules.
 */
export class TexasComplianceService implements ITexasComplianceService {
  private readonly repository: ITexasComplianceRepository;
  private readonly calculatorsByProgram: Map<TexasProgramType, IComplianceCalculator>;

  /**
   * @param repository - Data access abstraction for buildings/tenants/AMI
   * @param calculators - One or more program-specific calculators (strategies)
   */
  constructor(
    repository: ITexasComplianceRepository,
    calculators: IComplianceCalculator[]
  ) {
    this.repository = repository;
    this.calculatorsByProgram = new Map(
      calculators.map((calc) => [calc.program, calc])
    );
  }

  /**
   * Determine which calculator to use for the given program type.
   * If no calculator is registered, throw a typed error so callers
   * can distinguish configuration issues from data issues.
   */
  private getCalculator(program: TexasProgramType): IComplianceCalculator {
    const calculator = this.calculatorsByProgram.get(program);
    if (!calculator) {
      throw new UnknownProgramError(program);
    }
    return calculator;
  }

  /**
   * Calculate rent compliance for a unit.
   *
   * NOTE: The service itself does not try to infer program type from
   * other sources; the caller should provide the correct program for
   * clarity. In a real system, this could be inferred from BuildingData.
   */
  calculateRentCompliance(
    unitData: UnitData & { programType?: TexasProgramType },
    amiData: TexasAMIData
  ): ComplianceCalculationResult {
    const program =
      unitData.programType ??
      (('programType' in amiData ? (amiData as any).programType : undefined) as
        | TexasProgramType
        | undefined) ??
      'LIHTC';

    const calculator = this.getCalculator(program);
    return calculator.calculateRentCompliance(unitData, amiData);
  }

  /**
   * Validate building-level set-aside requirements.
   *
   * This implements the interface method name `validateSetAside` required
   * by the assessment. A convenience alias `validateTexasSetAside` is
   * also provided if you prefer a more explicit name.
   */
  validateSetAside(buildingData: BuildingData): boolean {
    const calculator = this.getCalculator(buildingData.programType);
    return calculator.validateSetAside(buildingData);
  }

  /**
   * Convenience alias that clearly indicates Texas-specific logic and
   * delegates to the required `validateSetAside` interface method.
   */
  validateTexasSetAside(buildingData: BuildingData): boolean {
    return this.validateSetAside(buildingData);
  }

  /**
   * Calculate income compliance for a tenant under a given program.
   *
   * If the selected calculator does not implement income compliance,
   * the service returns a neutral result with `details.skipped = true`.
   */
  calculateIncomeCompliance(
    tenantData: TenantData & { programType?: TexasProgramType },
    amiData: TexasAMIData
  ): ComplianceCalculationResult {
    const program =
      tenantData.programType ??
      (('programType' in amiData ? (amiData as any).programType : undefined) as
        | TexasProgramType
        | undefined) ??
      'LIHTC';

    const calculator = this.getCalculator(program);

    if (!calculator.calculateIncomeCompliance) {
      return {
        isCompliant: true,
        violatedRules: [],
        messages: ['Income compliance not implemented for this program.'],
        details: { skipped: true },
      };
    }

    return calculator.calculateIncomeCompliance(tenantData, amiData);
  }
}

/**
 * Custom error type for unknown/unsupported Texas program types.
 */
export class UnknownProgramError extends Error {
  public readonly program: TexasProgramType;

  constructor(program: TexasProgramType) {
    super(`No compliance calculator registered for program: ${program}`);
    this.name = 'UnknownProgramError';
    this.program = program;
  }
}


