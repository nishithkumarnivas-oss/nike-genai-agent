import {
  BuildingData,
  TenantData,
  TexasAMIData,
  TexasProgramType,
  UnitData,
} from '../../types/complianceTypes';

/**
 * Repository interface for accessing Texas compliance-related data.
 *
 * The concrete implementation can talk to a database, an HTTP API,
 * or simply use in-memory test data. For this assessment, a mock/stub
 * implementation is sufficient as long as this abstraction exists.
 */
export interface ITexasComplianceRepository {
  /**
   * Load AMI data for a given geographic area/program context.
   *
   * @param areaCode - FIPS or similar area identifier
   * @param fiscalYear - Year of AMI limits (e.g. 2024)
   */
  getTexasAmiData(areaCode: string, fiscalYear: number): Promise<TexasAMIData>;

  /**
   * Load building data and its units for compliance validation.
   *
   * @param buildingId - Identifier of the building
   */
  getBuildingData(buildingId: string): Promise<BuildingData>;

  /**
   * Load tenant data for income compliance checks.
   *
   * @param tenantId - Identifier of the tenant
   */
  getTenantData(tenantId: string): Promise<TenantData>;

  /**
   * Optionally fetch all units for a building and program type.
   */
  getUnitsForProgram(
    buildingId: string,
    programType: TexasProgramType
  ): Promise<UnitData[]>;
}


