import {
  BuildingData,
  ComplianceCalculationResult,
  TenantData,
  TexasAMIData,
  TexasProgramType,
  UnitData,
} from '../../types/complianceTypes';

/**
 * Interface for Texas compliance calculator implementations.
 *
 * This follows the Strategy Pattern: different implementations can be swapped
 * at runtime based on the Texas program (LIHTC, Section 8, etc.).
 */
export interface IComplianceCalculator {
  /**
   * Program this calculator is responsible for (e.g. LIHTC, SECTION_8).
   */
  readonly program: TexasProgramType;

  /**
   * Calculate rent compliance for a single unit under this program.
   *
   * @param unitData - Minimal unit information (bedrooms, current rent, etc.)
   * @param amiData - Texas AMI limits for the relevant area/fiscal year
   */
  calculateRentCompliance(
    unitData: UnitData,
    amiData: TexasAMIData
  ): ComplianceCalculationResult;

  /**
   * Validate that the building meets required Texas set-aside requirements
   * for this program (e.g. LIHTC minimum units per AMI bucket).
   *
   * @param buildingData - Building and unit distribution by AMI buckets
   */
  validateSetAside(buildingData: BuildingData): boolean;

  /**
   * Optionally calculate income compliance for a tenant under this program.
   *
   * @param tenantData - Household size and income
   * @param amiData - Texas AMI limits for the relevant area/fiscal year
   */
  calculateIncomeCompliance?(
    tenantData: TenantData,
    amiData: TexasAMIData
  ): ComplianceCalculationResult;
}


